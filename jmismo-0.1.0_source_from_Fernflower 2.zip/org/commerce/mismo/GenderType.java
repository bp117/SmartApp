package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class GenderType extends Enum {

   public static final GenderType FEMALE = new GenderType("Female");
   public static final GenderType NOT_PROVIDED = new GenderType("InformationNotProvidedUnknown");
   public static final GenderType MALE = new GenderType("Male");
   static Class class$org$commerce$mismo$GenderType;


   private GenderType(String name) {
      super(name);
   }

   public static GenderType getEnum(String type) {
      return (GenderType)getEnum(class$org$commerce$mismo$GenderType == null?(class$org$commerce$mismo$GenderType = class$("org.commerce.mismo.GenderType")):class$org$commerce$mismo$GenderType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$GenderType == null?(class$org$commerce$mismo$GenderType = class$("org.commerce.mismo.GenderType")):class$org$commerce$mismo$GenderType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$GenderType == null?(class$org$commerce$mismo$GenderType = class$("org.commerce.mismo.GenderType")):class$org$commerce$mismo$GenderType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$GenderType == null?(class$org$commerce$mismo$GenderType = class$("org.commerce.mismo.GenderType")):class$org$commerce$mismo$GenderType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
