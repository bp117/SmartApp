package org.commerce.mismo;

import org.commerce.mismo.ARM;
import org.commerce.mismo.LoanFeatures;

public interface LoanProductData {

   ARM getARM();

   LoanFeatures getLoanFeatures();
}
