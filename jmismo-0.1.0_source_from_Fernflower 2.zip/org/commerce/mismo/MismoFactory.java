package org.commerce.mismo;

import org.commerce.mismo.Asset;
import org.commerce.mismo.Liability;
import org.commerce.mismo.LoanApplication;

public interface MismoFactory {

   LoanApplication createLoanApplication();

   Asset createAsset();

   Liability createLiability();
}
