package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class BorrowerResidencyType extends Enum {

   public static final BorrowerResidencyType CURRENT = new BorrowerResidencyType("Current");
   public static final BorrowerResidencyType PRIOR = new BorrowerResidencyType("Prior");
   static Class class$org$commerce$mismo$BorrowerResidencyType;


   private BorrowerResidencyType(String name) {
      super(name);
   }

   public static BorrowerResidencyType getEnum(String type) {
      return (BorrowerResidencyType)getEnum(class$org$commerce$mismo$BorrowerResidencyType == null?(class$org$commerce$mismo$BorrowerResidencyType = class$("org.commerce.mismo.BorrowerResidencyType")):class$org$commerce$mismo$BorrowerResidencyType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$BorrowerResidencyType == null?(class$org$commerce$mismo$BorrowerResidencyType = class$("org.commerce.mismo.BorrowerResidencyType")):class$org$commerce$mismo$BorrowerResidencyType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$BorrowerResidencyType == null?(class$org$commerce$mismo$BorrowerResidencyType = class$("org.commerce.mismo.BorrowerResidencyType")):class$org$commerce$mismo$BorrowerResidencyType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$BorrowerResidencyType == null?(class$org$commerce$mismo$BorrowerResidencyType = class$("org.commerce.mismo.BorrowerResidencyType")):class$org$commerce$mismo$BorrowerResidencyType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
