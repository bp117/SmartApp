package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class LiabilityType extends Enum {

   public static final LiabilityType ALIMONY = new LiabilityType("Alimony");
   public static final LiabilityType CHILD_CARE = new LiabilityType("ChildCare");
   public static final LiabilityType CHILD_SUPPORT = new LiabilityType("ChildSupport");
   public static final LiabilityType COLLECTION_JUDGEMENTS_AND_LIENS = new LiabilityType("CollectionsJudgementsAndLiens");
   public static final LiabilityType HELOC = new LiabilityType("HELOC");
   public static final LiabilityType INSTALLMENT = new LiabilityType("Installment");
   public static final LiabilityType JOB_RELATED_EXPENSES = new LiabilityType("JobRelatedExpenses");
   public static final LiabilityType LEASE_PAYMENTS = new LiabilityType("LeasePayments");
   public static final LiabilityType MORTGAGE_LOAN = new LiabilityType("MortgageLoan");
   public static final LiabilityType OPEN_30_DAY_CHARGE_ACCOUNT = new LiabilityType("Open30DayChargeAccount");
   public static final LiabilityType OTHER_LIABILITY = new LiabilityType("OtherLiability");
   public static final LiabilityType REVOLVING = new LiabilityType("Revolving");
   public static final LiabilityType SEPARATE_MAINTENCE_EXPENSE = new LiabilityType("SeparateMaintenanceExpense");
   public static final LiabilityType OTHER_EXPENSE = new LiabilityType("OtherExpense");
   public static final LiabilityType TAXES = new LiabilityType("Taxes");
   static Class class$org$commerce$mismo$LiabilityType;


   private LiabilityType(String name) {
      super(name);
   }

   public static LiabilityType getEnum(String color) {
      return (LiabilityType)getEnum(class$org$commerce$mismo$LiabilityType == null?(class$org$commerce$mismo$LiabilityType = class$("org.commerce.mismo.LiabilityType")):class$org$commerce$mismo$LiabilityType, color);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$LiabilityType == null?(class$org$commerce$mismo$LiabilityType = class$("org.commerce.mismo.LiabilityType")):class$org$commerce$mismo$LiabilityType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$LiabilityType == null?(class$org$commerce$mismo$LiabilityType = class$("org.commerce.mismo.LiabilityType")):class$org$commerce$mismo$LiabilityType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$LiabilityType == null?(class$org$commerce$mismo$LiabilityType = class$("org.commerce.mismo.LiabilityType")):class$org$commerce$mismo$LiabilityType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
