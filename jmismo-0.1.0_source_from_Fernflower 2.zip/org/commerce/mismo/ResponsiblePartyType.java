package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class ResponsiblePartyType extends Enum {

   public static final ResponsiblePartyType BUYER = new ResponsiblePartyType("Buyer");
   public static final ResponsiblePartyType SELLER = new ResponsiblePartyType("Seller");
   static Class class$org$commerce$mismo$ResponsiblePartyType;


   private ResponsiblePartyType(String name) {
      super(name);
   }

   public static ResponsiblePartyType getEnum(String type) {
      return (ResponsiblePartyType)getEnum(class$org$commerce$mismo$ResponsiblePartyType == null?(class$org$commerce$mismo$ResponsiblePartyType = class$("org.commerce.mismo.ResponsiblePartyType")):class$org$commerce$mismo$ResponsiblePartyType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$ResponsiblePartyType == null?(class$org$commerce$mismo$ResponsiblePartyType = class$("org.commerce.mismo.ResponsiblePartyType")):class$org$commerce$mismo$ResponsiblePartyType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$ResponsiblePartyType == null?(class$org$commerce$mismo$ResponsiblePartyType = class$("org.commerce.mismo.ResponsiblePartyType")):class$org$commerce$mismo$ResponsiblePartyType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$ResponsiblePartyType == null?(class$org$commerce$mismo$ResponsiblePartyType = class$("org.commerce.mismo.ResponsiblePartyType")):class$org$commerce$mismo$ResponsiblePartyType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
