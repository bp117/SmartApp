package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class PropertyUsageType extends Enum {

   public static final PropertyUsageType INVESTOR = new PropertyUsageType("Investor");
   public static final PropertyUsageType PRIMARY_RESIDENCE = new PropertyUsageType("PrimaryResidence");
   public static final PropertyUsageType SECOND_HOME = new PropertyUsageType("SecondHome");
   static Class class$org$commerce$mismo$PropertyUsageType;


   private PropertyUsageType(String name) {
      super(name);
   }

   public static PropertyUsageType getEnum(String type) {
      return (PropertyUsageType)getEnum(class$org$commerce$mismo$PropertyUsageType == null?(class$org$commerce$mismo$PropertyUsageType = class$("org.commerce.mismo.PropertyUsageType")):class$org$commerce$mismo$PropertyUsageType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$PropertyUsageType == null?(class$org$commerce$mismo$PropertyUsageType = class$("org.commerce.mismo.PropertyUsageType")):class$org$commerce$mismo$PropertyUsageType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$PropertyUsageType == null?(class$org$commerce$mismo$PropertyUsageType = class$("org.commerce.mismo.PropertyUsageType")):class$org$commerce$mismo$PropertyUsageType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$PropertyUsageType == null?(class$org$commerce$mismo$PropertyUsageType = class$("org.commerce.mismo.PropertyUsageType")):class$org$commerce$mismo$PropertyUsageType);
   }

   public String toString() {
      return this.getName();
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
