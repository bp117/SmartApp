package org.commerce.mismo;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public class HMDAEthnicityType extends Enum implements Serializable {

   static final long serialVersionUID = 8684279522509468615L;
   public static final String HISPANIC_OR_LATINO_DESCRIPTION = "HispanicOrLatino";
   public static final String NOT_HISPANIC_OR_LATINO_DESCRIPTION = "NotHispanicOrLatino";
   public static final String INFO_NOT_PROVIDED_IN_MAIL_INTERNET_OR_PHONE_DESCRIPTION = "InformationNotProvidedByApplicantInMailInternetOrTelephoneApplication";
   public static final String NOT_APPLICABLE_DESCRIPTION = "NotApplicable";
   public static final HMDAEthnicityType HISPANIC_OR_LATINO = new HMDAEthnicityType("HispanicOrLatino");
   public static final HMDAEthnicityType NOT_HISPANIC_OR_LATINO = new HMDAEthnicityType("NotHispanicOrLatino");
   public static final HMDAEthnicityType INFO_NOT_PROVIDED_IN_MAIL_INTERNET_OR_PHONE = new HMDAEthnicityType("InformationNotProvidedByApplicantInMailInternetOrTelephoneApplication");
   public static final HMDAEthnicityType NOT_APPLICABLE = new HMDAEthnicityType("NotApplicable");
   static Class class$org$commerce$mismo$HMDAEthnicityType;


   private HMDAEthnicityType(String name) {
      super(name);
   }

   public static HMDAEthnicityType getEnum(String type) {
      return (HMDAEthnicityType)getEnum(class$org$commerce$mismo$HMDAEthnicityType == null?(class$org$commerce$mismo$HMDAEthnicityType = class$("org.commerce.mismo.HMDAEthnicityType")):class$org$commerce$mismo$HMDAEthnicityType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$HMDAEthnicityType == null?(class$org$commerce$mismo$HMDAEthnicityType = class$("org.commerce.mismo.HMDAEthnicityType")):class$org$commerce$mismo$HMDAEthnicityType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$HMDAEthnicityType == null?(class$org$commerce$mismo$HMDAEthnicityType = class$("org.commerce.mismo.HMDAEthnicityType")):class$org$commerce$mismo$HMDAEthnicityType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$HMDAEthnicityType == null?(class$org$commerce$mismo$HMDAEthnicityType = class$("org.commerce.mismo.HMDAEthnicityType")):class$org$commerce$mismo$HMDAEthnicityType);
   }

   public static HMDAEthnicityType getEthnicityType(String name) {
      return (HMDAEthnicityType)Enum.getEnum(class$org$commerce$mismo$HMDAEthnicityType == null?(class$org$commerce$mismo$HMDAEthnicityType = class$("org.commerce.mismo.HMDAEthnicityType")):class$org$commerce$mismo$HMDAEthnicityType, name);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
