package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class HousingExpenseType extends Enum {

   public static final HousingExpenseType FIRST_MORTGAGE_PRINCIPAL_AND_INTEREST = new HousingExpenseType("FirstMortgagePrincipalAndInterest");
   public static final HousingExpenseType HAZARD_INSURANCE = new HousingExpenseType("HazardInsurance");
   public static final HousingExpenseType HOMEOWNERS_ASSOCIATION_DUES_AND_CONDO_FEES = new HousingExpenseType("HomeownersAssociationDuesAndCondominiumFees");
   public static final HousingExpenseType MORTGAGE_INSURANCE = new HousingExpenseType("MI");
   public static final HousingExpenseType OTHER_HOUSING_EXPENSE = new HousingExpenseType("OtherHousingExpense");
   public static final HousingExpenseType OTHER_MORTGAGE_LOAN_PRINCIPAL_AND_INTEREST = new HousingExpenseType("OtherMortgageLoanPrincipalAndInterest");
   public static final HousingExpenseType REAL_ESTATE_TAX = new HousingExpenseType("RealEstateTax");
   public static final HousingExpenseType RENT = new HousingExpenseType("Rent");
   static Class class$org$commerce$mismo$HousingExpenseType;


   private HousingExpenseType(String name) {
      super(name);
   }

   public static HousingExpenseType getEnum(String type) {
      return (HousingExpenseType)getEnum(class$org$commerce$mismo$HousingExpenseType == null?(class$org$commerce$mismo$HousingExpenseType = class$("org.commerce.mismo.HousingExpenseType")):class$org$commerce$mismo$HousingExpenseType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$HousingExpenseType == null?(class$org$commerce$mismo$HousingExpenseType = class$("org.commerce.mismo.HousingExpenseType")):class$org$commerce$mismo$HousingExpenseType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$HousingExpenseType == null?(class$org$commerce$mismo$HousingExpenseType = class$("org.commerce.mismo.HousingExpenseType")):class$org$commerce$mismo$HousingExpenseType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$HousingExpenseType == null?(class$org$commerce$mismo$HousingExpenseType = class$("org.commerce.mismo.HousingExpenseType")):class$org$commerce$mismo$HousingExpenseType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
