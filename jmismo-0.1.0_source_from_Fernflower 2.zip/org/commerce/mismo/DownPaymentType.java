package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class DownPaymentType extends Enum {

   public static final DownPaymentType BRIDGE_LOAN = new DownPaymentType("BridgeLoan");
   public static final DownPaymentType CASH_ON_HAND = new DownPaymentType("CashOnHand");
   public static final DownPaymentType CHECKING_SAVINGS = new DownPaymentType("CheckingSavings");
   public static final DownPaymentType DEPOSIT_ON_SALES_CONTRACT = new DownPaymentType("DepositOnSalesContract");
   public static final DownPaymentType EQUITY_ON_PENDING_SALE = new DownPaymentType("EquityOnPendingSale");
   public static final DownPaymentType EQUITY_ON_SOLD_PROPERTY = new DownPaymentType("EquityOnSoldProperty");
   public static final DownPaymentType EQUITY_ON_SUBJECT_PROPERTY = new DownPaymentType("EquityOnSubjectProperty");
   public static final DownPaymentType GIFT_FUNDS = new DownPaymentType("GiftFunds");
   public static final DownPaymentType LIFE_INSURANCE_CASH_VALUE = new DownPaymentType("LifeInsuranceCashValue");
   public static final DownPaymentType LOT_EQUITY = new DownPaymentType("LotEquity");
   public static final DownPaymentType OTHER_TYPE_OF_DOWN_PAYMENT = new DownPaymentType("OtherTypeOfDownPayment");
   public static final DownPaymentType RENT_WITH_OPTION_TO_PURCHASE = new DownPaymentType("RentWithOptionToPurchase");
   public static final DownPaymentType RETIREMENT_FUNDS = new DownPaymentType("RetirementFunds");
   public static final DownPaymentType SALE_OF_CHATTEL = new DownPaymentType("SaleOfChattel");
   public static final DownPaymentType SECURED_BORROWED_FUNDS = new DownPaymentType("SecuredBorrowedFunds");
   public static final DownPaymentType STOCKS_AND_BONDS = new DownPaymentType("StocksAndBonds");
   public static final DownPaymentType SWEAT_EQUITY = new DownPaymentType("SweatEquity");
   public static final DownPaymentType TRADE_EQUITY = new DownPaymentType("TradeEquity");
   public static final DownPaymentType TRUST_FUNDS = new DownPaymentType("TrustFunds");
   public static final DownPaymentType UNSECURED_BORROWED_FUNDS = new DownPaymentType("UnsecuredBorrowedFunds");
   static Class class$org$commerce$mismo$DownPaymentType;


   private DownPaymentType(String name) {
      super(name);
   }

   public static DownPaymentType getEnum(String type) {
      return (DownPaymentType)getEnum(class$org$commerce$mismo$DownPaymentType == null?(class$org$commerce$mismo$DownPaymentType = class$("org.commerce.mismo.DownPaymentType")):class$org$commerce$mismo$DownPaymentType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$DownPaymentType == null?(class$org$commerce$mismo$DownPaymentType = class$("org.commerce.mismo.DownPaymentType")):class$org$commerce$mismo$DownPaymentType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$DownPaymentType == null?(class$org$commerce$mismo$DownPaymentType = class$("org.commerce.mismo.DownPaymentType")):class$org$commerce$mismo$DownPaymentType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$DownPaymentType == null?(class$org$commerce$mismo$DownPaymentType = class$("org.commerce.mismo.DownPaymentType")):class$org$commerce$mismo$DownPaymentType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
