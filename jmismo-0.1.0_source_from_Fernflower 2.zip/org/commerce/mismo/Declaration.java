package org.commerce.mismo;

import org.commerce.mismo.CitizenshipResidencyType;
import org.commerce.mismo.PriorPropertyTitleType;
import org.commerce.mismo.PriorPropertyUsageType;

public interface Declaration {

   Boolean isAlimonyChildSupportObligation();

   void setAlimonyChildSupportObligation(Boolean var1);

   Boolean isBankruptcy();

   void setBankruptcy(Boolean var1);

   Boolean isBorrowedDownPayment();

   void setBorrowedDownPayment(Boolean var1);

   Boolean isBorrowerFirstTimeHomebuyer();

   void setBorrowerFirstTimeHomebuyer(Boolean var1);

   CitizenshipResidencyType getCitizenshipResidencyType();

   void setCitizenshipResidencyType(CitizenshipResidencyType var1);

   Boolean isCoMakerEndorserOfNote();

   void setCoMakerEndorserOfNote(Boolean var1);

   Boolean isHomeownerPastThreeYearsType();

   void setHomeownerPastThreeYearsType(Boolean var1);

   Boolean isIntentToOccupyType();

   void setIntentToOccupyType(Boolean var1);

   Boolean isLoanForeclosureOrJudgement();

   void setLoanForeclosureOrJudgement(Boolean var1);

   Boolean isOutstandingJudgements();

   void setOutstandingJudgements(Boolean var1);

   Boolean isPartyToLawsuit();

   void setPartyToLawsuit(Boolean var1);

   Boolean isPresentlyDelinquent();

   void setPresentlyDelinquent(Boolean var1);

   PriorPropertyTitleType getPriorPropertyTitleType();

   void setPriorPropertyTitleType(PriorPropertyTitleType var1);

   PriorPropertyUsageType getPriorPropertyUsageType();

   void setPriorPropertyUsageType(PriorPropertyUsageType var1);

   Boolean isPropertyForeclosedPastSevenYears();

   void setPropertyForeclosedPastSevenYears(Boolean var1);
}
