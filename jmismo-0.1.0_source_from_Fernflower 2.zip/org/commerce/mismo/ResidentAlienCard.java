package org.commerce.mismo;

import java.util.Date;

public interface ResidentAlienCard {

   String getCardNumber();

   Date getExpirationDate();

   Date getIssueDate();

   void setCardNumber(String var1);

   void setExpirationDate(Date var1);

   void setIssueDate(Date var1);
}
