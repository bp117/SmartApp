package org.commerce.mismo;

import org.commerce.mismo.Address;
import org.commerce.mismo.BorrowerResidencyBasisType;
import org.commerce.mismo.BorrowerResidencyType;
import org.commerce.mismo.Landlord;

public interface Residence {

   Address getAddress();

   void setAddress(Address var1);

   BorrowerResidencyBasisType getResidencyBasisType();

   void setResidencyBasisType(BorrowerResidencyBasisType var1);

   int getBorrowerResidencyDurationMonths();

   void setBorrowerResidencyDurationMonths(int var1);

   int getBorrowerResidencyDurationYears();

   void setBorrowerResidencyDurationYears(int var1);

   BorrowerResidencyType getResidencyType();

   void setResidencyType(BorrowerResidencyType var1);

   Landlord getLandlord();
}
