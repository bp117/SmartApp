package org.commerce.mismo.xml;

import org.commerce.mismo.LoanProductData;
import org.commerce.mismo.xml.ArmXMLGenerator;
import org.commerce.mismo.xml.LoanFeaturesXMLMapper;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class LoanProductDataXMLMapper extends XMLGeneratorSupport {

   private ArmXMLGenerator armXMLGenerator = new ArmXMLGenerator();
   private LoanFeaturesXMLMapper loanFeaturesXMLMapper = new LoanFeaturesXMLMapper();


   public Element getElement(XMLGenerationContext context, LoanProductData productData) {
      Element node = context.createElement("LOAN_PRODUCT_DATA");
      if(productData.getARM() != null) {
         node.appendChild(this.armXMLGenerator.getElement(context, productData.getARM()));
      }

      node.appendChild(this.loanFeaturesXMLMapper.getElement(context, productData.getLoanFeatures()));
      return node;
   }
}
