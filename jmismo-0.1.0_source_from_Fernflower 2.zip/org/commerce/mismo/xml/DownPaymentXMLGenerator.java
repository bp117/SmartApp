package org.commerce.mismo.xml;

import org.commerce.mismo.DownPayment;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class DownPaymentXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, DownPayment downPayment) {
      Element node = context.createElement("DOWN_PAYMENT");
      this.setAttribute(node, "_Amount", downPayment.getAmount(), 2);
      this.setAttribute(node, "_SourceDescription", downPayment.getSourceDescription());
      this.setAttribute(node, "_Type", downPayment.getDownPaymentType());
      return node;
   }
}
