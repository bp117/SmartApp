package org.commerce.mismo.xml;

import org.commerce.mismo.Dependent;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class DependentXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, Dependent d) {
      Element node = context.createElement("DEPENDENT");
      this.setAttribute(node, "_AgeYears", d.getAgeYears());
      return node;
   }
}
