package org.commerce.mismo.xml;

import org.commerce.mismo.ARM;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class ArmXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, ARM arm) {
      Element node = context.createElement("ARM");
      this.setAttribute(node, "_IndexCurrentValuePercent", arm.getIndexCurrentValuePercent());
      this.setAttribute(node, "_IndexMarginPercent", arm.getIndexMarginPercent());
      this.setAttribute(node, "_QualifyingRatePercent", arm.getQualifyingRatePercent());
      this.setAttribute(node, "PaymentAdjustmentLifetimeCapAmount", arm.getPaymentAdjustmentLifetimeCapAmount());
      this.setAttribute(node, "PaymentAdjustmentLifetimeCapPercent", arm.getPaymentAdjustmentLifetimeCapPercent());
      this.setAttribute(node, "RateAdjustmentLifetimeCapPercent", arm.getRateAdjustmentLifetimeCapPercent());
      return node;
   }
}
