package org.commerce.mismo.xml;

import org.commerce.mismo.Landlord;
import org.commerce.mismo.xml.ContactDetailXMLGenerator;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class LandlordXMLGenerator extends XMLGeneratorSupport {

   private ContactDetailXMLGenerator contactDetailGenerator = new ContactDetailXMLGenerator();


   public Element getElement(XMLGenerationContext context, Landlord landlord) {
      Element node = context.createElement("LANDLORD");
      this.setAttribute(node, "_Name", landlord.getName());
      this.setAddress(node, "_", landlord.getAddress(), false);
      node.appendChild(this.contactDetailGenerator.getElement(context, landlord.getContactDetail()));
      return node;
   }
}
