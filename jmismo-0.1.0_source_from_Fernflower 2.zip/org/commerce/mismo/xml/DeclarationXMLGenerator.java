package org.commerce.mismo.xml;

import org.commerce.mismo.Declaration;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class DeclarationXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, Declaration declaration) {
      Element node = context.createElement("DECLARATION");
      this.setAttribute(node, "AlimonyChildSupportObligationIndicator", declaration.isAlimonyChildSupportObligation());
      this.setAttribute(node, "BankruptcyIndicator", declaration.isBankruptcy());
      this.setAttribute(node, "BorrowedDownPaymentIndicator", declaration.isBorrowedDownPayment());
      this.setAttribute(node, "CitizenshipResidencyType", declaration.getCitizenshipResidencyType());
      this.setAttribute(node, "CoMakerEndorserOfNoteIndicator", declaration.isCoMakerEndorserOfNote());
      this.setAttribute(node, "HomeownerPastThreeYearsType", declaration.isHomeownerPastThreeYearsType(), DEFAULT_BOOLEAN_TYPE_VALUES);
      this.setAttribute(node, "IntentToOccupyType", declaration.isIntentToOccupyType(), DEFAULT_BOOLEAN_TYPE_VALUES);
      this.setAttribute(node, "LoanForeclosureOrJudgementIndicator", declaration.isLoanForeclosureOrJudgement());
      this.setAttribute(node, "OutstandingJudgementsIndicator", declaration.isOutstandingJudgements());
      this.setAttribute(node, "PartyToLawsuitIndicator", declaration.isPartyToLawsuit());
      this.setAttribute(node, "PresentlyDelinquentIndicator", declaration.isPresentlyDelinquent());
      this.setAttribute(node, "PriorPropertyTitleType", declaration.getPriorPropertyTitleType());
      this.setAttribute(node, "PriorPropertyUsageType", declaration.getPriorPropertyUsageType());
      this.setAttribute(node, "PropertyForeclosedPastSevenYearsIndicator", declaration.isPropertyForeclosedPastSevenYears());
      this.setAttribute(node, "BorrowerFirstTimeHomebuyerIndicator", declaration.isBorrowerFirstTimeHomebuyer());
      return node;
   }
}
