package org.commerce.mismo.xml;

import org.commerce.mismo.ResidentAlienCard;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

public class ResidentAlienCardXMLGenerator extends XMLGeneratorSupport {

   public static final String RESIDENT_ALIEN_CARD = "RESIDENT_ALIEN_CARD";
   public static final String CARD_NUMBER = "_Number";
   public static final String ISSUE_DATE = "_IssueDate";
   public static final String EXPIRATION_DATE = "_ExpirationDate";


   public Element getElement(XMLGenerationContext context, ResidentAlienCard residentAlienCard) {
      Element node = context.createElement("RESIDENT_ALIEN_CARD");
      this.setAttribute(node, "_ExpirationDate", residentAlienCard.getExpirationDate());
      this.setAttribute(node, "_IssueDate", residentAlienCard.getIssueDate());
      this.setAttribute(node, "_Number", residentAlienCard.getCardNumber());
      return node;
   }
}
