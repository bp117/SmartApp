package org.commerce.mismo.xml;

import org.commerce.mismo.PresentHousingExpense;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class PresentHousingExpenseXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, PresentHousingExpense expense) {
      Element node = context.createElement("PRESENT_HOUSING_EXPENSE");
      this.setAttribute(node, "HousingExpenseType", expense.getHousingExpenseType());
      this.setAttribute(node, "_PaymentAmount", expense.getPaymentAmount(), 2);
      return node;
   }
}
