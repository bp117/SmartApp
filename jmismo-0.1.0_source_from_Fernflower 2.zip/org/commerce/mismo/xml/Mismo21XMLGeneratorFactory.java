package org.commerce.mismo.xml;

import org.commerce.mismo.xml.BorrowerXMLGenerator;
import org.commerce.mismo.xml.MortgageTermsXMLGenerator;
import org.commerce.mismo.xml.PaymentXMLGenerator;
import org.commerce.mismo.xml.PropertyXMLGenerator;
import org.commerce.mismo.xml.REOPropertyXMLGenerator;
import org.commerce.mismo.xml.RespaFeeXMLGenerator;
import org.commerce.mismo.xml.XMLGeneratorFactory;

class Mismo21XMLGeneratorFactory extends XMLGeneratorFactory {

   BorrowerXMLGenerator getBorrowerXMLGenerator() {
      return new BorrowerXMLGenerator();
   }

   PropertyXMLGenerator getPropertyXMLGenerator() {
      return new PropertyXMLGenerator();
   }

   MortgageTermsXMLGenerator getMortgageTermsXMLGenerator() {
      return new MortgageTermsXMLGenerator();
   }

   REOPropertyXMLGenerator getREOPropertyXMLGenerator() {
      return new REOPropertyXMLGenerator();
   }

   RespaFeeXMLGenerator getRespaFeeXMLGenerator() {
      return new RespaFeeXMLGenerator();
   }

   PaymentXMLGenerator getPaymentXMLGenerator() {
      return new PaymentXMLGenerator();
   }
}
