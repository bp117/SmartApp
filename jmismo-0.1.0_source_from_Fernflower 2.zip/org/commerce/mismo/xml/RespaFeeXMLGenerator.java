package org.commerce.mismo.xml;

import org.commerce.mismo.Payment;
import org.commerce.mismo.RespaFee;
import org.commerce.mismo.xml.PaymentXMLGenerator;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class RespaFeeXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, RespaFee fee) {
      Element node = context.createElement("RESPA_FEE");
      this.populateAttributes(context, fee, node);
      Payment[] payments = fee.getPayments();
      if(payments.length > 0) {
         PaymentXMLGenerator paymentGen = context.getXMLGeneratorFactory().getPaymentXMLGenerator();

         for(int i = 0; i < payments.length; ++i) {
            node.appendChild(paymentGen.getElement(context, payments[i]));
         }
      }

      return node;
   }

   protected void populateAttributes(XMLGenerationContext context, RespaFee fee, Element element) {
      this.setAttribute(element, "RESPASectionClassificationType", fee.getRespaSectionClassificationType());
      this.setAttribute(element, "_PaidToName", fee.getPaidToName());
      this.setAttribute(element, "_ResponsiblePartyType", fee.getResponsiblePartyType());
      this.setAttribute(element, "_SpecifiedHUDLineNumber", fee.getSpecifiedHUDLineNumber());
      this.setAttribute(element, "_Type", fee.getType());
      this.setAttribute(element, "_TypeOtherDescription", fee.getOtherTypeDescription());
   }
}
