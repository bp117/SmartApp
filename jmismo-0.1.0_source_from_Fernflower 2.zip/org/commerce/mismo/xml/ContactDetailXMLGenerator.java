package org.commerce.mismo.xml;

import org.commerce.mismo.ContactDetail;
import org.commerce.mismo.ContactPoint;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

public class ContactDetailXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, ContactDetail contactDetail) {
      Element node = context.createElement("CONTACT_DETAIL");
      this.setAttribute(node, "_Name", contactDetail.getName());
      ContactPoint[] contactPoints = contactDetail.getContactPoints();

      for(int i = 0; i < contactPoints.length; ++i) {
         ContactPoint contactPoint = contactPoints[i];
         Element contactNode = context.createElement("CONTACT_POINT");
         this.setAttribute(contactNode, "_RoleType", contactPoint.getRoleType());
         this.setAttribute(contactNode, "_Type", contactPoint.getType());
         this.setAttribute(contactNode, "_TypeOtherDescription", contactPoint.getTypeOtherDescription());
         this.setAttribute(contactNode, "_Value", contactPoint.getValue());
         this.setAttribute(contactNode, "_PreferenceIndicator", contactPoint.getPreferenceIndicator());
         node.appendChild(contactNode);
      }

      return node;
   }
}
