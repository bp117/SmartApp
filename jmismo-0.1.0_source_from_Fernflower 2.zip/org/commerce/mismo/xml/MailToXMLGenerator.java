package org.commerce.mismo.xml;

import org.commerce.mismo.MailTo;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

public class MailToXMLGenerator extends XMLGeneratorSupport {

   public static final String MAIL_TO_ELEMENT_NAME = "_MAIL_TO";
   public static final String STREET_ADDRESS1_KEY = "_StreetAddress";
   public static final String STREET_ADDRESS2_KEY = "_StreetAddress2";
   public static final String CITY_KEY = "_City";
   public static final String STATE_KEY = "_State";
   public static final String POSTAL_CODE_KEY = "_PostalCode";
   public static final String COUNTRY_KEY = "_Country";


   public Element getElement(XMLGenerationContext context, MailTo mailingAddress) {
      Element node = context.createElement("_MAIL_TO");
      this.setMailTo(node, mailingAddress);
      return node;
   }

   public void setMailTo(Element element, MailTo address) {
      this.setAttribute(element, "_StreetAddress", address.getStreetAddress1());
      this.setAttribute(element, "_StreetAddress2", address.getStreetAddress2());
      this.setAttribute(element, "_City", address.getCity());
      this.setAttribute(element, "_State", address.getState());
      this.setAttribute(element, "_PostalCode", address.getPostalCode());
      this.setAttribute(element, "_Country", address.getCountry());
   }
}
