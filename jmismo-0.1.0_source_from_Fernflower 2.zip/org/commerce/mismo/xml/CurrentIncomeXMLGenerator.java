package org.commerce.mismo.xml;

import org.commerce.mismo.CurrentIncome;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class CurrentIncomeXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, CurrentIncome income) {
      Element node = context.createElement("CURRENT_INCOME");
      this.setAttribute(node, "IncomeType", income.getIncomeType());
      this.setAttribute(node, "_MonthlyTotalAmount", income.getMonthlyTotalAmount(), 2);
      return node;
   }
}
