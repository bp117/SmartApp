package org.commerce.mismo.xml;

import org.commerce.mismo.Identification;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

public class IdentificationXMLGenerator extends XMLGeneratorSupport {

   public static final String IDENTIFICATION = "IDENTIFICATION";
   public static final String TYPE = "_Type";
   public static final String ISSUE_DATE = "_IssueDate";
   public static final String EXPIRATION_DATE = "_ExpirationDate";
   public static final String ISSUING_COUNTRY = "_IssuingCountry";
   public static final String ISSUING_STATE = "_IssuingState";


   public Element getElement(XMLGenerationContext context, Identification identification) {
      Element node = context.createElement("IDENTIFICATION");
      this.setAttribute(node, "_ExpirationDate", identification.getExpirationDate());
      this.setAttribute(node, "_IssueDate", identification.getIssueDate());
      this.setAttribute(node, "_IssuingCountry", identification.getIssuingCountry());
      this.setAttribute(node, "_IssuingState", identification.getIssuingState());
      this.setAttribute(node, "_Type", identification.getType().getCode());
      return node;
   }
}
