package org.commerce.mismo.xml;

import org.commerce.mismo.REOProperty;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class REOPropertyXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, REOProperty property) {
      Element node = context.createElement("REO_PROPERTY");
      this.populateAttributes(context, property, node);
      return node;
   }

   protected void populateAttributes(XMLGenerationContext context, REOProperty property, Element node) {
      String id = context.getID(node, property);
      this.setAttribute(node, "REO_ID", id);
      String borrowerIds = context.getIDREFS("BORROWER", property.getBorrowers());
      this.setAttribute(node, "BorrowerID", borrowerIds);
      String liabilityIds = context.getIDREFS("LIABILITY", property.getLiabilities());
      this.setAttribute(node, "LiabilityID", liabilityIds);
      this.setAddress(node, "_", property.getAddress(), false);
      this.setAttribute(node, "_CurrentResidenceIndicator", property.isCurrentResidence());
      this.setAttribute(node, "_DispositionStatusType", property.getDispositionStatusType());
      this.setAttribute(node, "_GSEPropertyType", property.getGSEPropertyType());
      this.setAttribute(node, "_LienInstallmentAmount", property.getLienInstallmentAmount(), 2);
      this.setAttribute(node, "_LienUPBAmount", property.getLienUnpaidPrincipalBalanceAmount(), 2);
      this.setAttribute(node, "_MaintenanceExpenseAmount", property.getMaintenanceExpenseAmount(), 2);
      this.setAttribute(node, "_MarketValueAmount", property.getMarketValueAmount(), 2);
      this.setAttribute(node, "_RentalIncomeGrossAmount", property.getRentalIncomeGrossAmount(), 2);
      this.setAttribute(node, "_RentalIncomeNetAmount", property.getRentalIncomeNetAmount(), 2);
      this.setAttribute(node, "_SubjectIndicator", property.isSubject());
   }
}
