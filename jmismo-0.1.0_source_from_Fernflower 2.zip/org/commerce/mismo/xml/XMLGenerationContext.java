package org.commerce.mismo.xml;

import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.commerce.mismo.xml.MismoXmlType;
import org.commerce.mismo.xml.XMLGeneratorFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class XMLGenerationContext {

   private Document document = null;
   private Map elementIds = new HashMap();
   private MismoXmlType xmlType;


   public XMLGenerationContext() {
      this.xmlType = MismoXmlType.MISMO_2_3;
   }

   public void init() throws ParserConfigurationException {
      this.document = this.createDocument();
   }

   public Document getDocument() {
      return this.document;
   }

   public void setDocument(Document document) {
      this.document = document;
   }

   public Element createElement(String tagName) throws IllegalStateException {
      if(this.document == null) {
         throw new IllegalStateException("Document has not been set yet;  try calling init first");
      } else {
         Element element = this.document.createElement(tagName);
         return element;
      }
   }

   public Text createTextNode(String text) throws IllegalStateException {
      if(this.document == null) {
         throw new IllegalStateException("Document has not been set yet;  try calling init first");
      } else {
         Text node = this.document.createTextNode(text);
         return node;
      }
   }

   public String getID(Element element, Object payload) {
      return this.getID(element.getNodeName(), payload);
   }

   public String getID(String elementName, Object payload) {
      String id = null;
      if(payload != null) {
         Map ids = this.getIDs(elementName);
         id = (String)ids.get(payload);
         if(id == null) {
            id = elementName + "_" + ids.size();
            ids.put(payload, id);
         }
      }

      return id;
   }

   public String getIDREFS(String elementName, Object[] references) {
      StringBuffer idrefs = new StringBuffer();

      for(int i = 0; i < references.length; ++i) {
         if(references[i] != null) {
            if(idrefs.length() > 0) {
               idrefs.append(' ');
            }

            idrefs.append(this.getID(elementName, references[i]));
         }
      }

      if(idrefs.length() == 0) {
         return null;
      } else {
         return idrefs.toString();
      }
   }

   private Map getIDs(String elementName) {
      Object ids = (Map)this.elementIds.get(elementName);
      if(ids == null) {
         ids = new HashMap();
         this.elementIds.put(elementName, ids);
      }

      return (Map)ids;
   }

   private Document createDocument() throws ParserConfigurationException {
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      factory.setNamespaceAware(false);
      DocumentBuilder docBuilder = factory.newDocumentBuilder();
      return docBuilder.newDocument();
   }

   public MismoXmlType getXmlType() {
      return this.xmlType;
   }

   public void setXmlType(MismoXmlType xmlType) {
      if(xmlType == null) {
         throw new IllegalArgumentException("xmlType cannot be null");
      } else {
         this.xmlType = xmlType;
      }
   }

   public XMLGeneratorFactory getXMLGeneratorFactory() {
      return XMLGeneratorFactory.getXMLGeneratorFactory(this);
   }
}
