package org.commerce.mismo.xml;

import org.commerce.mismo.Employer;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class EmployerXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, Employer employer) {
      Element node = context.createElement("EMPLOYER");
      this.setAttribute(node, "_Name", employer.getName());
      this.setAddress(node, "_", employer.getAddress(), false);
      this.setAttribute(node, "_TelephoneNumber", employer.getTelephoneNumber());
      this.setAttribute(node, "CurrentEmploymentMonthsOnJob", employer.getMonthsOnJob());
      this.setAttribute(node, "CurrentEmploymentTimeInLineOfWorkYears", employer.getTimeInLineOfWork());
      this.setAttribute(node, "CurrentEmploymentYearsOnJob", employer.getYearsOnJob());
      this.setAttribute(node, "EmploymentBorrowerSelfEmployedIndicator", employer.isSelfEmployed());
      this.setAttribute(node, "EmploymentCurrentIndicator", employer.isCurrent());
      this.setAttribute(node, "EmploymentPositionDescription", employer.getEmploymentPositionDescription());
      this.setAttribute(node, "IncomeEmploymentMonthlyAmount", employer.getMonthlyIncome(), 2);
      this.setAttribute(node, "PreviousEmploymentEndDate", employer.getPreviousEmploymentEndDate());
      this.setAttribute(node, "PreviousEmploymentStartDate", employer.getPreviousEmploymentStartDate());
      this.setAttribute(node, "EmploymentPrimaryIndicator", employer.getEmploymentPrimaryIndicator());
      return node;
   }
}
