package org.commerce.mismo.xml;

import org.commerce.mismo.TransactionDetail;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class TransactionDetailXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, TransactionDetail detail) {
      Element node = context.createElement("TRANSACTION_DETAIL");
      this.setAttribute(node, "EstimatedClosingCostsAmount", detail.getEstimatedClosingCostsAmount(), 2);
      this.setAttribute(node, "PurchasePriceAmount", detail.getPurchasePriceAmount(), 2);
      this.setAttribute(node, "RefinanceIncludingDebtsToBePaidOffAmount", detail.getRefinanceIncludingDebtsToBePaidOffAmount(), 2);
      return node;
   }
}
