package org.commerce.mismo.xml;

import org.commerce.mismo.ConstructionRefinanceData;
import org.commerce.mismo.LoanPurpose;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class LoanPurposeXMLMapper extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, LoanPurpose purpose) {
      Element node = context.createElement("LOAN_PURPOSE");
      this.setAttribute(node, "GSETitleMannerHeldDescription", purpose.getGSETitleMannerHeldDescription());
      this.setAttribute(node, "_Type", purpose.getLoanPurposeType());
      this.setAttribute(node, "OtherLoanPurposeDescription", purpose.getOtherLoanPurposeDescription());
      this.setAttribute(node, "PropertyUsageType", purpose.getPropertyUsageType());
      this.setAttribute(node, "PropertyRightsType", purpose.getPropertyRightsType());
      node.appendChild(this.getConstuctionRefiData(context, purpose));
      return node;
   }

   private Element getConstuctionRefiData(XMLGenerationContext context, LoanPurpose purpose) {
      ConstructionRefinanceData refiData = purpose.getConstructionRefinanceData();
      Element node = context.createElement("CONSTRUCTION_REFINANCE_DATA");
      this.setAttribute(node, "GSERefinancePurposeType", refiData.getGSERefinancePurposeType());
      this.setAttribute(node, "PropertyExistingLienAmount", refiData.getPropertyExistingLienAmount(), 2);
      this.setAttribute(node, "PropertyOriginalCostAmount", refiData.getPropertyOriginalCostAmount(), 2);
      return node;
   }
}
