package org.commerce.mismo.xml;

import org.commerce.mismo.Asset;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class AssetXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, Asset asset) {
      Element node = context.createElement("ASSET");
      this.setAttribute(node, "BorrowerID", context.getIDREFS("BORROWER", asset.getBorrowers()));
      this.setAttribute(node, "_AccountIdentifier", asset.getAccountIdentifier());
      this.setAttribute(node, "_CashOrMarketValueAmount", asset.getCashOrMarketValueAmount(), 2);
      this.setAttribute(node, "_Type", asset.getAssetType());
      this.setAttribute(node, "_HolderName", asset.getHolder());
      this.setAddress(node, "_Holder", asset.getHolderAddress(), false);
      this.setAttribute(node, "AutomobileMakeDescription", asset.getAutomobileMakeDescription());
      this.setAttribute(node, "AutomobileModelYear", asset.getAutomobileModelYear());
      this.setAttribute(node, "LifeInsuranceFaceValueAmount", asset.getLifeInsuranceFaceValueAmount(), 2);
      this.setAttribute(node, "OtherAssetTypeDescription", asset.getOtherAssetTypeDescription());
      return node;
   }
}
