package org.commerce.mismo.xml;

import org.commerce.mismo.GovernmentReporting;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class GovernmentReportingXMLGenerator extends XMLGeneratorSupport {

   static final String ELEMENT_NAME = "GOVERNMENT_REPORTING";
   static final String LOAN_PURPOSE_ATTRIBUTE = "HMDAPurposeOfLoanType";


   Element createElement(XMLGenerationContext context, GovernmentReporting govReporting) {
      Element node = context.createElement("GOVERNMENT_REPORTING");
      this.setAttribute(node, "HMDAPurposeOfLoanType", govReporting.getHMDAPurposeOfLoanType());
      return node;
   }
}
