package org.commerce.mismo.xml;

import org.commerce.mismo.HMDARace;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

public class HMDARaceXmlGenerator extends XMLGeneratorSupport {

   public Element createElement(XMLGenerationContext context, HMDARace race) {
      Element node = context.createElement("HMDA_RACE");
      this.setAttribute(node, "_Type", race.getType().getName(), false);
      return node;
   }
}
