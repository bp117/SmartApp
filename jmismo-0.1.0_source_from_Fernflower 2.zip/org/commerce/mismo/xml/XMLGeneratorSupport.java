package org.commerce.mismo.xml;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.lang.enums.Enum;
import org.commerce.mismo.Address;
import org.w3c.dom.Element;

class XMLGeneratorSupport {

   protected static final String[] DEFAULT_BOOLEAN_VALUES = new String[]{"Y", "N"};
   protected static final String[] DEFAULT_BOOLEAN_TYPE_VALUES = new String[]{"Yes", "No", "Unknown"};
   protected static final SimpleDateFormat DATE_ONLY_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
   protected static final SimpleDateFormat DATE_TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd\'T\'HH:mm:ss");


   public void setAttribute(Element element, String name, Object value) {
      if(value != null) {
         this.setAttribute(element, name, (Object)value.toString(), true);
      }

   }

   public void setAttribute(Element element, String name, Object value, boolean upperCase) {
      if(name != null && value != null) {
         if(upperCase) {
            value = value.toString().toUpperCase();
         }

         element.setAttribute(name, value.toString());
      }

   }

   public void setAttribute(Element element, String name, Float value, int decimals) {
      if(value != null) {
         this.setAttribute(element, name, new BigDecimal((double)value.floatValue()), decimals);
      }

   }

   public void setAttribute(Element element, String name, BigDecimal value, int decimals) {
      if(value != null) {
         StringBuffer formatString = new StringBuffer("#0");
         if(decimals != 0) {
            formatString.append('.');

            for(int formatter = 0; formatter < decimals; ++formatter) {
               formatString.append('0');
            }
         }

         DecimalFormat var8 = new DecimalFormat(formatString.toString());
         String formattedValue = var8.format(value.doubleValue());
         this.setAttribute(element, name, (Object)formattedValue);
      }

   }

   public void setAttribute(Element element, String name, Enum value) {
      if(value != null) {
         this.setAttribute(element, name, (Object)value.getName(), false);
      }

   }

   public void setAttribute(Element element, String name, Date date) {
      this.setAttribute(element, name, date, false);
   }

   public void setAttribute(Element element, String name, Date date, boolean showTime) {
      if(date != null) {
         String value = null;
         if(showTime) {
            value = DATE_TIME_FORMAT.format(date);
         } else {
            value = DATE_ONLY_FORMAT.format(date);
         }

         this.setAttribute(element, name, (Object)value);
      }

   }

   public void setAttribute(Element element, String name, boolean value) {
      this.setAttribute(element, name, value, DEFAULT_BOOLEAN_VALUES);
   }

   public void setAttribute(Element element, String name, boolean value, String[] values) {
      String valueString = value?values[0]:values[1];
      this.setAttribute(element, name, (Object)String.valueOf(valueString), false);
   }

   public void setAttribute(Element element, String name, Boolean bool) {
      this.setAttribute(element, name, bool, DEFAULT_BOOLEAN_VALUES);
   }

   public void setAttribute(Element element, String name, Boolean bool, String[] values) {
      if(bool != null) {
         this.setAttribute(element, name, bool.booleanValue(), values);
      } else if(values.length > 2 && values[2] != null) {
         this.setAttribute(element, name, (Object)values[2], false);
      }

   }

   public void setAttribute(Element element, String name, int value) {
      this.setAttribute(element, name, (Object)String.valueOf(value));
   }

   public void setAttribute(Element element, String name, double value) {
      this.setAttribute(element, name, (Object)String.valueOf(value));
   }

   public void setAddress(Element element, String prefix, Address address, boolean includeCountry) {
      this.setAttribute(element, prefix + "StreetAddress", (Object)address.getStreetAddress());
      this.setAttribute(element, prefix + "City", (Object)address.getCity());
      this.setAttribute(element, prefix + "State", (Object)address.getState());
      this.setAttribute(element, prefix + "PostalCode", (Object)address.getPostalCode());
      if(includeCountry) {
         this.setAttribute(element, prefix + "Country", (Object)address.getCountry());
      }

   }

}
