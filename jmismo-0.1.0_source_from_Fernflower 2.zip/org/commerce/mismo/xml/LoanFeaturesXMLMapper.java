package org.commerce.mismo.xml;

import org.commerce.mismo.LoanFeatures;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class LoanFeaturesXMLMapper extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, LoanFeatures features) {
      Element node = context.createElement("LOAN_FEATURES");
      this.setAttribute(node, "LoanDocumentationType", features.getLoanDocumentationType());
      this.setAttribute(node, "ProductDescription", features.getProductDescription());
      this.setAttribute(node, "ProductName", features.getProductName());
      this.setAttribute(node, "PrepaymentPenaltyIndicator", features.getPrepaymentPenaltyIndicator());
      return node;
   }
}
