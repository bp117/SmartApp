package org.commerce.mismo.xml;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class MismoXmlType extends Enum {

   public static final MismoXmlType MISMO_2_3 = new MismoXmlType("MISMO 2.3");
   static Class class$org$commerce$mismo$xml$MismoXmlType;


   private MismoXmlType(String name) {
      super(name);
   }

   public static MismoXmlType getEnum(String type) {
      return (MismoXmlType)getEnum(class$org$commerce$mismo$xml$MismoXmlType == null?(class$org$commerce$mismo$xml$MismoXmlType = class$("org.commerce.mismo.xml.MismoXmlType")):class$org$commerce$mismo$xml$MismoXmlType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$xml$MismoXmlType == null?(class$org$commerce$mismo$xml$MismoXmlType = class$("org.commerce.mismo.xml.MismoXmlType")):class$org$commerce$mismo$xml$MismoXmlType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$xml$MismoXmlType == null?(class$org$commerce$mismo$xml$MismoXmlType = class$("org.commerce.mismo.xml.MismoXmlType")):class$org$commerce$mismo$xml$MismoXmlType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$xml$MismoXmlType == null?(class$org$commerce$mismo$xml$MismoXmlType = class$("org.commerce.mismo.xml.MismoXmlType")):class$org$commerce$mismo$xml$MismoXmlType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
