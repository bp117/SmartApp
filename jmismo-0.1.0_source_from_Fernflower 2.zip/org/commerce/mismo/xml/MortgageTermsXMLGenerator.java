package org.commerce.mismo.xml;

import org.commerce.mismo.MortgageTerms;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class MortgageTermsXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, MortgageTerms terms) {
      Element node = context.createElement("MORTGAGE_TERMS");
      this.populateAttributes(terms, node);
      return node;
   }

   protected void populateAttributes(MortgageTerms terms, Element node) {
      this.setAttribute(node, "BaseLoanAmount", terms.getBaseLoanAmount(), 2);
      this.setAttribute(node, "BorrowerRequestedLoanAmount", terms.getBorrowerRequestedLoanAmount(), 2);
      this.setAttribute(node, "AgencyCaseIdentifier", terms.getAgencyCaseIdentifier());
      if(terms.getLoanAmortizationTermMonths() > 0) {
         this.setAttribute(node, "LoanAmortizationTermMonths", terms.getLoanAmortizationTermMonths());
      }

      this.setAttribute(node, "LoanAmortizationType", terms.getLoanAmortizationType());
      this.setAttribute(node, "MortgageType", terms.getMortgageType());
      this.setAttribute(node, "RequestedInterestRatePercent", terms.getRequestedInterestRatePercent());
      this.setAttribute(node, "LoanEstimatedClosingDate", terms.getLoanEstimatedClosingDate());
   }
}
