package org.commerce.mismo.xml;

import java.util.Iterator;
import java.util.List;
import org.commerce.mismo.GovernmentMonitoring;
import org.commerce.mismo.HMDAEthnicityType;
import org.commerce.mismo.HMDARace;
import org.commerce.mismo.xml.HMDARaceXmlGenerator;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class GovernmentMonitoringXmlGenerator extends XMLGeneratorSupport {

   public Element createElement(XMLGenerationContext context, GovernmentMonitoring govInfo) {
      Element node = context.createElement("GOVERNMENT_MONITORING");
      Boolean isRefusal = govInfo.getRaceNationalOriginRefusalIndicator();
      String isRefusalString = null;
      if(isRefusal != null && isRefusal.booleanValue()) {
         isRefusalString = "Y";
      } else {
         isRefusalString = "N";
         this.setAttribute(node, "GenderType", govInfo.getGenderType());
         HMDAEthnicityType et = govInfo.getEthnicityType();
         if(et != null) {
            this.setAttribute(node, "HMDAEthnicityType", et.getName(), false);
         }

         this.appendRaceChildren(context, node, govInfo);
      }

      this.setAttribute(node, "RaceNationalOriginRefusalIndicator", isRefusalString);
      return node;
   }

   private void appendRaceChildren(XMLGenerationContext context, Element node, GovernmentMonitoring govInfo) {
      List races = govInfo.getHMDARaces();
      Iterator iter = races.iterator();
      HMDARaceXmlGenerator hmdaGenerator = new HMDARaceXmlGenerator();

      while(iter.hasNext()) {
         HMDARace race = (HMDARace)iter.next();
         Element raceElement = hmdaGenerator.createElement(context, race);
         node.appendChild(raceElement);
      }

   }
}
