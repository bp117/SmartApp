package org.commerce.mismo.xml;

import org.commerce.mismo.Borrower;
import org.commerce.mismo.CurrentIncome;
import org.commerce.mismo.Dependent;
import org.commerce.mismo.Employer;
import org.commerce.mismo.Identification;
import org.commerce.mismo.MailTo;
import org.commerce.mismo.PresentHousingExpense;
import org.commerce.mismo.Residence;
import org.commerce.mismo.ResidentAlienCard;
import org.commerce.mismo.xml.CurrentIncomeXMLGenerator;
import org.commerce.mismo.xml.DeclarationXMLGenerator;
import org.commerce.mismo.xml.DependentXMLGenerator;
import org.commerce.mismo.xml.EmployerXMLGenerator;
import org.commerce.mismo.xml.GovernmentMonitoringXmlGenerator;
import org.commerce.mismo.xml.IdentificationXMLGenerator;
import org.commerce.mismo.xml.MailToXMLGenerator;
import org.commerce.mismo.xml.PresentHousingExpenseXMLGenerator;
import org.commerce.mismo.xml.ResidenceXMLGenerator;
import org.commerce.mismo.xml.ResidentAlienCardXMLGenerator;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class BorrowerXMLGenerator extends XMLGeneratorSupport {

   private ResidenceXMLGenerator residenceXMLGenerator = new ResidenceXMLGenerator();
   private CurrentIncomeXMLGenerator currentIncomeXMLGenerator = new CurrentIncomeXMLGenerator();
   private EmployerXMLGenerator employerXMLGenerator = new EmployerXMLGenerator();
   private GovernmentMonitoringXmlGenerator governmentMonitoringXMLGenerator = new GovernmentMonitoringXmlGenerator();
   private PresentHousingExpenseXMLGenerator housingExpenseXMLGenerator = new PresentHousingExpenseXMLGenerator();
   private DeclarationXMLGenerator declarationXMLGenerator = new DeclarationXMLGenerator();
   private MailToXMLGenerator mailToXMLGenerator = new MailToXMLGenerator();
   private IdentificationXMLGenerator identificationXMLGenerator = new IdentificationXMLGenerator();
   private ResidentAlienCardXMLGenerator residentAlienCardXMLGenerator = new ResidentAlienCardXMLGenerator();
   private DependentXMLGenerator dependentXMLGenerator = new DependentXMLGenerator();


   public Element getElement(XMLGenerationContext context, Borrower borrower) {
      Element node = context.createElement("BORROWER");
      this.populateAttributes(context, borrower, node);

      for(int address = 0; address < borrower.getDependents().length && address < borrower.getDependentCount(); ++address) {
         Dependent identification = borrower.getDependents()[address];
         node.appendChild(this.dependentXMLGenerator.getElement(context, identification));
      }

      MailTo var7 = borrower.getMailTo();
      if(var7 != null) {
         node.appendChild(this.mailToXMLGenerator.getElement(context, var7));
      }

      int var8;
      for(var8 = 0; var8 < borrower.getResidences().length; ++var8) {
         Residence residentAlienCard = borrower.getResidences()[var8];
         node.appendChild(this.residenceXMLGenerator.getElement(context, residentAlienCard));
      }

      for(var8 = 0; var8 < borrower.getCurrentIncomes().length; ++var8) {
         CurrentIncome var9 = borrower.getCurrentIncomes()[var8];
         node.appendChild(this.currentIncomeXMLGenerator.getElement(context, var9));
      }

      node.appendChild(this.declarationXMLGenerator.getElement(context, borrower.getDeclarations()));

      for(var8 = 0; var8 < borrower.getEmployers().length; ++var8) {
         Employer var10 = borrower.getEmployers()[var8];
         node.appendChild(this.employerXMLGenerator.getElement(context, var10));
      }

      node.appendChild(this.governmentMonitoringXMLGenerator.createElement(context, borrower.getGovernmentMonitoring()));

      for(var8 = 0; var8 < borrower.getHousingExpenses().length; ++var8) {
         PresentHousingExpense var11 = borrower.getHousingExpenses()[var8];
         node.appendChild(this.housingExpenseXMLGenerator.getElement(context, var11));
      }

      Identification var13 = borrower.getIdentification();
      if(var13 != null) {
         node.appendChild(this.identificationXMLGenerator.getElement(context, var13));
      }

      ResidentAlienCard var12 = borrower.getResidentAlienCard();
      if(var12 != null) {
         node.appendChild(this.residentAlienCardXMLGenerator.getElement(context, var12));
      }

      return node;
   }

   protected void populateAttributes(XMLGenerationContext context, Borrower borrower, Element node) {
      String id = context.getID(node, borrower);
      this.setAttribute(node, "BorrowerID", id);
      String jointBorrowerId = context.getID(node, borrower.getJointAssetBorrower());
      this.setAttribute(node, "JointAssetBorrowerID", jointBorrowerId);
      this.setAttribute(node, "_FirstName", borrower.getFirstName());
      this.setAttribute(node, "_MiddleName", borrower.getMiddleName());
      this.setAttribute(node, "_LastName", borrower.getLastName());
      this.setAttribute(node, "_NameSuffix", borrower.getNameSuffix());
      this.setAttribute(node, "_HomeTelephoneNumber", borrower.getHomePhoneNumber());
      this.setAttribute(node, "_SSN", borrower.getSSN());
      this.setAttribute(node, "_AgeAtApplicationYears", borrower.getAgeAtApplicationYears());
      this.setAttribute(node, "_BirthDate", borrower.getBirthDate());
      this.setAttribute(node, "_UnparsedName", borrower.getUnparsedName());
      this.setAttribute(node, "_PrintPositionType", borrower.getPrintPositionType());
      this.setAttribute(node, "DependentCount", borrower.getDependentCount());
      this.setAttribute(node, "JointAssetLiabilityReportingType", borrower.getJointAssetResidenceReportingType());
      this.setAttribute(node, "MaritalStatusType", borrower.getMaritalStatus());
      this.setAttribute(node, "SchoolingYears", borrower.getSchoolingYears());
   }
}
