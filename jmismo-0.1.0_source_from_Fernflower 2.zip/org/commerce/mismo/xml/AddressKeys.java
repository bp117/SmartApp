package org.commerce.mismo.xml;


public interface AddressKeys {

   String MAIL_ADDRESS = "_MAIL_TO";
   String STREET_ADDRESS = "StreetAddress";
   String STREET_ADDRESS2 = "StreetAddress2";
   String CITY = "City";
   String STATE = "State";
   String POSTAL_CODE = "PostalCode";
   String COUNTRY = "Country";
   String STREET_ADDRESS1 = "StreetAddress1";

}
