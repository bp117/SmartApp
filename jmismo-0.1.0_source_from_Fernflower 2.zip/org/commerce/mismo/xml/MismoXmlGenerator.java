package org.commerce.mismo.xml;

import javax.xml.parsers.ParserConfigurationException;
import org.commerce.mismo.ApplicationMethodTakenType;
import org.commerce.mismo.Asset;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.DownPayment;
import org.commerce.mismo.GovernmentReporting;
import org.commerce.mismo.InterviewerInformation;
import org.commerce.mismo.Liability;
import org.commerce.mismo.LoanApplication;
import org.commerce.mismo.ProposedHousingExpense;
import org.commerce.mismo.REOProperty;
import org.commerce.mismo.RespaFee;
import org.commerce.mismo.xml.AssetXMLGenerator;
import org.commerce.mismo.xml.BorrowerXMLGenerator;
import org.commerce.mismo.xml.DownPaymentXMLGenerator;
import org.commerce.mismo.xml.GovernmentReportingXMLGenerator;
import org.commerce.mismo.xml.InterviewerInformationXMLGenerator;
import org.commerce.mismo.xml.LiabilityXMLGenerator;
import org.commerce.mismo.xml.LoanProductDataXMLMapper;
import org.commerce.mismo.xml.LoanPurposeXMLMapper;
import org.commerce.mismo.xml.MismoXmlType;
import org.commerce.mismo.xml.MortgageTermsXMLGenerator;
import org.commerce.mismo.xml.PropertyXMLGenerator;
import org.commerce.mismo.xml.ProposedHousingExpenseXMLGenerator;
import org.commerce.mismo.xml.REOPropertyXMLGenerator;
import org.commerce.mismo.xml.RespaFeeXMLGenerator;
import org.commerce.mismo.xml.TransactionDetailXMLGenerator;
import org.commerce.mismo.xml.TransmittalDataXMLGenerator;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class MismoXmlGenerator {

   private AssetXMLGenerator assetXMLGenerator = new AssetXMLGenerator();
   private DownPaymentXMLGenerator downPaymentXMLGenerator = new DownPaymentXMLGenerator();
   private GovernmentReportingXMLGenerator governmentReportingXMLGenerator = new GovernmentReportingXMLGenerator();
   private InterviewerInformationXMLGenerator interviewerInformationXMLGenerator = new InterviewerInformationXMLGenerator();
   private LiabilityXMLGenerator liabilityXMLGenerator = new LiabilityXMLGenerator();
   private TransmittalDataXMLGenerator transmittalDataXMLGenerator = new TransmittalDataXMLGenerator();
   private ProposedHousingExpenseXMLGenerator proposedHousingExpenseXMLGenerator = new ProposedHousingExpenseXMLGenerator();
   private LoanPurposeXMLMapper loanPurposeXMLMapper = new LoanPurposeXMLMapper();
   private LoanProductDataXMLMapper loanProductDataMapper = new LoanProductDataXMLMapper();
   private TransactionDetailXMLGenerator tranDetailXMLMapper = new TransactionDetailXMLGenerator();
   public static final String LOAN_APPLICATION = "LOAN_APPLICATION";


   public Document getMismoXml(LoanApplication mismoApp) throws ParserConfigurationException {
      XMLGenerationContext context = new XMLGenerationContext();
      context.setXmlType(MismoXmlType.MISMO_2_3);
      context.init();
      Element rootElement = this.getMismoXml(context, mismoApp);
      context.getDocument().appendChild(rootElement);
      return context.getDocument();
   }

   public Element getMismoXml(XMLGenerationContext context, LoanApplication mismoLoanApp) throws ParserConfigurationException {
      Element loanAppNode = context.createElement("LOAN_APPLICATION");
      loanAppNode.appendChild(this.transmittalDataXMLGenerator.getElement(context, mismoLoanApp.getAdditionalCaseData().getTransmittalData()));

      int governmentReporting;
      Element reoPropertyXMLGenerator;
      for(governmentReporting = 0; governmentReporting < mismoLoanApp.getAssets().length; ++governmentReporting) {
         Asset interviewerInformation = mismoLoanApp.getAssets()[governmentReporting];
         reoPropertyXMLGenerator = this.assetXMLGenerator.getElement(context, interviewerInformation);
         loanAppNode.appendChild(reoPropertyXMLGenerator);
      }

      for(governmentReporting = 0; governmentReporting < mismoLoanApp.getDownPayments().length; ++governmentReporting) {
         DownPayment var12 = mismoLoanApp.getDownPayments()[governmentReporting];
         reoPropertyXMLGenerator = this.downPaymentXMLGenerator.getElement(context, var12);
         loanAppNode.appendChild(reoPropertyXMLGenerator);
      }

      GovernmentReporting var11 = mismoLoanApp.getGovernmentReporting();
      if(var11 != null) {
         Element var13 = this.governmentReportingXMLGenerator.createElement(context, var11);
         loanAppNode.appendChild(var13);
      }

      InterviewerInformation var14 = mismoLoanApp.getInterviewerInformation();
      var14.setApplicationMethodTakenType(ApplicationMethodTakenType.INTERNET);
      loanAppNode.appendChild(this.interviewerInformationXMLGenerator.createElement(context, var14));

      int var15;
      for(var15 = 0; var15 < mismoLoanApp.getLiabilities().length; ++var15) {
         Liability borrowerXMLGenerator = mismoLoanApp.getLiabilities()[var15];
         loanAppNode.appendChild(this.liabilityXMLGenerator.getElement(context, borrowerXMLGenerator));
      }

      if(mismoLoanApp.getLoanProductData() != null) {
         loanAppNode.appendChild(this.loanProductDataMapper.getElement(context, mismoLoanApp.getLoanProductData()));
      }

      if(mismoLoanApp.getLoanPurpose() != null) {
         loanAppNode.appendChild(this.loanPurposeXMLMapper.getElement(context, mismoLoanApp.getLoanPurpose()));
      }

      if(mismoLoanApp.getMortgageTerms() != null) {
         MortgageTermsXMLGenerator var16 = context.getXMLGeneratorFactory().getMortgageTermsXMLGenerator();
         loanAppNode.appendChild(var16.getElement(context, mismoLoanApp.getMortgageTerms()));
      }

      if(mismoLoanApp.getProperty() != null) {
         PropertyXMLGenerator var18 = context.getXMLGeneratorFactory().getPropertyXMLGenerator();
         loanAppNode.appendChild(var18.getElement(context, mismoLoanApp.getProperty()));
      }

      for(var15 = 0; var15 < mismoLoanApp.getProposedHousingExpenses().length; ++var15) {
         ProposedHousingExpense var17 = mismoLoanApp.getProposedHousingExpenses()[var15];
         loanAppNode.appendChild(this.proposedHousingExpenseXMLGenerator.getElement(context, var17));
      }

      REOPropertyXMLGenerator var22 = context.getXMLGeneratorFactory().getREOPropertyXMLGenerator();

      for(int var19 = 0; var19 < mismoLoanApp.getReoProperties().length; ++var19) {
         REOProperty respaFeeXMLGenerator = mismoLoanApp.getReoProperties()[var19];
         loanAppNode.appendChild(var22.getElement(context, respaFeeXMLGenerator));
      }

      loanAppNode.appendChild(this.tranDetailXMLMapper.getElement(context, mismoLoanApp.getTransactionDetail()));
      BorrowerXMLGenerator var20 = context.getXMLGeneratorFactory().getBorrowerXMLGenerator();

      for(int var21 = 0; var21 < mismoLoanApp.getBorrowers().length; ++var21) {
         Borrower index = mismoLoanApp.getBorrowers()[var21];
         Element fee = var20.getElement(context, index);
         loanAppNode.appendChild(fee);
      }

      RespaFeeXMLGenerator var23 = context.getXMLGeneratorFactory().getRespaFeeXMLGenerator();

      for(int var24 = 0; var24 < mismoLoanApp.getRespaFees().length; ++var24) {
         RespaFee var25 = mismoLoanApp.getRespaFees()[var24];
         loanAppNode.appendChild(var23.getElement(context, var25));
      }

      return loanAppNode;
   }
}
