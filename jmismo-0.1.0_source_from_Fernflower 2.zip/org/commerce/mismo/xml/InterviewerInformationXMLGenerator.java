package org.commerce.mismo.xml;

import org.commerce.mismo.InterviewerInformation;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

public class InterviewerInformationXMLGenerator extends XMLGeneratorSupport {

   private static final String ATTRIBUTE_NAME_METHOD_TAKEN = "ApplicationTakenMethodType";


   Element createElement(XMLGenerationContext context, InterviewerInformation info) {
      Element node = context.createElement("INTERVIEWER_INFORMATION");
      this.setAttribute(node, "ApplicationTakenMethodType", info.getApplicationMethodTakenType().getName(), false);
      return node;
   }
}
