package org.commerce.mismo.xml;

import org.commerce.mismo.Property;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class PropertyXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, Property property) {
      Element node = context.createElement("PROPERTY");
      this.populateAttributes(context, property, node);

      for(int i = 0; i < property.getLegalDescriptions().length; ++i) {
         Element descNode = context.createElement("_LEGAL_DESCRIPTION");
         this.setAttribute(descNode, "_TextDescription", property.getLegalDescriptions()[i]);
         this.setAttribute(descNode, "_Type", "Other", false);
         node.appendChild(descNode);
      }

      return node;
   }

   protected void populateAttributes(XMLGenerationContext context, Property property, Element element) {
      this.setAddress(element, "_", property.getAddress(), false);
      this.setAttribute(element, "_County", property.getCounty());
      this.setAttribute(element, "BuildingStatusType", property.getBuildingStatusType());
      this.setAttribute(element, "_FinancedNumberOfUnits", property.getFinancedNumberOfUnits());
      this.setAttribute(element, "_StructureBuiltYear", property.getStructureBuiltYear());
   }
}
