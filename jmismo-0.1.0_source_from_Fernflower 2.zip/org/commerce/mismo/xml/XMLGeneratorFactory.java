package org.commerce.mismo.xml;

import org.commerce.mismo.xml.BorrowerXMLGenerator;
import org.commerce.mismo.xml.Mismo21XMLGeneratorFactory;
import org.commerce.mismo.xml.MortgageTermsXMLGenerator;
import org.commerce.mismo.xml.PaymentXMLGenerator;
import org.commerce.mismo.xml.PropertyXMLGenerator;
import org.commerce.mismo.xml.REOPropertyXMLGenerator;
import org.commerce.mismo.xml.RespaFeeXMLGenerator;
import org.commerce.mismo.xml.XMLGenerationContext;

public abstract class XMLGeneratorFactory {

   public static XMLGeneratorFactory getXMLGeneratorFactory(XMLGenerationContext context) {
      return new Mismo21XMLGeneratorFactory();
   }

   abstract BorrowerXMLGenerator getBorrowerXMLGenerator();

   abstract PropertyXMLGenerator getPropertyXMLGenerator();

   abstract MortgageTermsXMLGenerator getMortgageTermsXMLGenerator();

   abstract REOPropertyXMLGenerator getREOPropertyXMLGenerator();

   abstract RespaFeeXMLGenerator getRespaFeeXMLGenerator();

   abstract PaymentXMLGenerator getPaymentXMLGenerator();
}
