package org.commerce.mismo.xml;

import org.commerce.mismo.TransmittalData;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class TransmittalDataXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, TransmittalData data) {
      Element additionalDataNode = context.createElement("ADDITIONAL_CASE_DATA");
      Element node = context.createElement("TRANSMITTAL_DATA");
      this.setAttribute(node, "CaseStateType", data.getCaseStateType());
      this.setAttribute(node, "LenderBranchIdentifier", data.getLendersBranchIdentifier(), false);
      this.setAttribute(node, "LoanOriginationSystemLoanIdentifier", data.getLoanOriginationSystemLoanIdentifier(), false);
      this.setAttribute(node, "PropertyAppraisedValueAmount", data.getPropertyAppraisedValueAmount(), 2);
      additionalDataNode.appendChild(node);
      return additionalDataNode;
   }
}
