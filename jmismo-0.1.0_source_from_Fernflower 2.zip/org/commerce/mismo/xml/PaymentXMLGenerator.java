package org.commerce.mismo.xml;

import org.commerce.mismo.Payment;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class PaymentXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, Payment payment) {
      Element node = context.createElement("_PAYMENT");
      this.populateAttributes(context, payment, node);
      return node;
   }

   protected void populateAttributes(XMLGenerationContext context, Payment payment, Element element) {
      this.setAttribute(element, "_Amount", payment.getAmount(), 2);
      this.setAttribute(element, "_PaidByType", payment.getPaidBy());
      this.setAttribute(element, "_Percent", payment.getPaymentPercent());
   }
}
