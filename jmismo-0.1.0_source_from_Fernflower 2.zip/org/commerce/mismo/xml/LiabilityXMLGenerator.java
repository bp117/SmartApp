package org.commerce.mismo.xml;

import org.commerce.mismo.Liability;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class LiabilityXMLGenerator extends XMLGeneratorSupport {

   public Element getElement(XMLGenerationContext context, Liability liability) {
      Element node = context.createElement("LIABILITY");
      String id = context.getID(node, liability);
      this.setAttribute(node, "_ID", id);
      String borrowerIds = context.getIDREFS("BORROWER", liability.getBorrowers());
      this.setAttribute(node, "BorrowerID", borrowerIds);
      this.setAttribute(node, "_HolderName", liability.getHolderName());
      this.setAttribute(node, "_MonthlyPaymentAmount", liability.getMonthlyPaymentAmount(), 2);
      this.setAttribute(node, "_Type", liability.getLiabilityType());
      this.setAttribute(node, "_UnpaidBalanceAmount", liability.getUnpaidBalanceAmount(), 2);
      this.setAttribute(node, "_AccountIdentifier", liability.getAccountIdentifier());
      this.setAttribute(node, "_PayoffStatusIndicator", liability.getPayoffStatusIndicator());
      String reoId = context.getID("REO_PROPERTY", liability.getREOProperty());
      this.setAttribute(node, "REO_ID", reoId);
      return node;
   }
}
