package org.commerce.mismo.xml;

import org.commerce.mismo.BorrowerResidencyBasisType;
import org.commerce.mismo.Residence;
import org.commerce.mismo.xml.LandlordXMLGenerator;
import org.commerce.mismo.xml.XMLGenerationContext;
import org.commerce.mismo.xml.XMLGeneratorSupport;
import org.w3c.dom.Element;

class ResidenceXMLGenerator extends XMLGeneratorSupport {

   private LandlordXMLGenerator landlordGenerator = new LandlordXMLGenerator();


   public Element getElement(XMLGenerationContext context, Residence residence) {
      Element residenceNode = context.createElement("_RESIDENCE");
      this.setAddress(residenceNode, "_", residence.getAddress(), true);
      this.setAttribute(residenceNode, "BorrowerResidencyBasisType", residence.getResidencyBasisType());
      this.setAttribute(residenceNode, "BorrowerResidencyDurationMonths", residence.getBorrowerResidencyDurationMonths());
      this.setAttribute(residenceNode, "BorrowerResidencyDurationYears", residence.getBorrowerResidencyDurationYears());
      this.setAttribute(residenceNode, "BorrowerResidencyType", residence.getResidencyType());
      if(residence.getResidencyBasisType() != null && residence.getResidencyBasisType().equals(BorrowerResidencyBasisType.RENT)) {
         residenceNode.appendChild(this.landlordGenerator.getElement(context, residence.getLandlord()));
      }

      return residenceNode;
   }
}
