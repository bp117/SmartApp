package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class GSEPropertyType extends Enum {

   public static final GSEPropertyType SINGLE_FAMILY = new GSEPropertyType("SingleFamily");
   public static final GSEPropertyType CONDOMINIUM = new GSEPropertyType("Condominium");
   public static final GSEPropertyType TOWNHOUSE = new GSEPropertyType("Townhouse");
   public static final GSEPropertyType COOPERATIVE = new GSEPropertyType("Cooperative");
   public static final GSEPropertyType TWO_TO_FOUR_UNIT_PROPERTY = new GSEPropertyType("TwoToFourUnitProperty");
   public static final GSEPropertyType MULTI_FAMILY_MORE_THAN_FOUR_UNITS = new GSEPropertyType("MultifamilyMoreThanFourUnits");
   public static final GSEPropertyType MANUFACTURED_MOBILE_HOME = new GSEPropertyType("ManufacturedMobileHome");
   public static final GSEPropertyType COMMERCIAL_NON_RESIDENTIAL = new GSEPropertyType("CommercialNonResidential");
   public static final GSEPropertyType MIXED_USE_RESIDENTIAL = new GSEPropertyType("MixedUseResidential");
   public static final GSEPropertyType FARM = new GSEPropertyType("Farm");
   public static final GSEPropertyType HOME_AND_BUSINESS_COMBINED = new GSEPropertyType("HomeAndBusinessCombined");
   public static final GSEPropertyType LAND = new GSEPropertyType("Land");
   static Class class$org$commerce$mismo$GSEPropertyType;


   private GSEPropertyType(String name) {
      super(name);
   }

   public static GSEPropertyType getEnum(String type) {
      return (GSEPropertyType)getEnum(class$org$commerce$mismo$GSEPropertyType == null?(class$org$commerce$mismo$GSEPropertyType = class$("org.commerce.mismo.GSEPropertyType")):class$org$commerce$mismo$GSEPropertyType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$GSEPropertyType == null?(class$org$commerce$mismo$GSEPropertyType = class$("org.commerce.mismo.GSEPropertyType")):class$org$commerce$mismo$GSEPropertyType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$GSEPropertyType == null?(class$org$commerce$mismo$GSEPropertyType = class$("org.commerce.mismo.GSEPropertyType")):class$org$commerce$mismo$GSEPropertyType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$GSEPropertyType == null?(class$org$commerce$mismo$GSEPropertyType = class$("org.commerce.mismo.GSEPropertyType")):class$org$commerce$mismo$GSEPropertyType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
