package org.commerce.mismo;

import java.math.BigDecimal;
import org.commerce.mismo.util.EnumObject;

public interface Mismo extends EnumObject {

   BigDecimal getAmount();
}
