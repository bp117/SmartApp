package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class AssetType extends Enum {

   public static final AssetType AUTOMOBILE = new AssetType("Automobile");
   public static final AssetType BOND = new AssetType("Bond");
   public static final AssetType BRIDGE_LOAN_NOT_DEPOSITED = new AssetType("BridgeLoanNotDeposited");
   public static final AssetType CASH_ON_HAND = new AssetType("CashOnHand");
   public static final AssetType CERTIFICATION_OF_DEPOSIT_TIME_DEPOSIT = new AssetType("CertificateOfDepositTimeDeposit");
   public static final AssetType CHECKING_ACCOUNT = new AssetType("CheckingAccount");
   public static final AssetType EARNEST_MONEY_CASH_DEPOSIT_TOWARD_PURCHASE = new AssetType("EarnestMoneyCashDepositTowardPurchase");
   public static final AssetType GIFTS_TOTAL = new AssetType("GiftsTotal");
   public static final AssetType GIFTS_NOT_DEPOSITED = new AssetType("GiftsNotDeposited");
   public static final AssetType LIFE_INSURANCE = new AssetType("LifeInsurance");
   public static final AssetType MONEY_MARKET_FUND = new AssetType("MoneyMarketFund");
   public static final AssetType MUTUAL_FUND = new AssetType("MutualFund");
   public static final AssetType NET_WORTH_OF_BUSINESS_OWNED = new AssetType("NetWorkOfBusinessOwned");
   public static final AssetType OTHER_LIQUID_ASSETS = new AssetType("OtherLiquidAssets");
   public static final AssetType OTHER_NON_LIQUID_ASSETS = new AssetType("OtherNonLiquidAssets");
   public static final AssetType PENDING_NET_SALE_PROCEEDS_FROM_REAL_ESTATE_ASSETS = new AssetType("PendingNetSaleProceedsFromRealEstateAssets");
   public static final AssetType RETIREMENT_FUND = new AssetType("RetirementFund");
   public static final AssetType SALE_OTHER_ASSETS = new AssetType("SaleOtherAssets");
   public static final AssetType SAVINGS_ACCOUNT = new AssetType("SavingsAccount");
   public static final AssetType SECURED_BORROWED_FUNDS_NOT_DEPOSITED = new AssetType("SecuredBorrowedFundsNotDeposited");
   public static final AssetType STOCK = new AssetType("Stock");
   public static final AssetType TRUST_ACCOUNT = new AssetType("TrustAccount");
   static Class class$org$commerce$mismo$AssetType;


   private AssetType(String name) {
      super(name);
   }

   public static AssetType getEnum(String type) {
      return (AssetType)getEnum(class$org$commerce$mismo$AssetType == null?(class$org$commerce$mismo$AssetType = class$("org.commerce.mismo.AssetType")):class$org$commerce$mismo$AssetType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$AssetType == null?(class$org$commerce$mismo$AssetType = class$("org.commerce.mismo.AssetType")):class$org$commerce$mismo$AssetType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$AssetType == null?(class$org$commerce$mismo$AssetType = class$("org.commerce.mismo.AssetType")):class$org$commerce$mismo$AssetType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$AssetType == null?(class$org$commerce$mismo$AssetType = class$("org.commerce.mismo.AssetType")):class$org$commerce$mismo$AssetType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
