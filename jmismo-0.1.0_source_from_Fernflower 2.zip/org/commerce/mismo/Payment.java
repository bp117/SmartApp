package org.commerce.mismo;

import java.math.BigDecimal;
import org.commerce.mismo.PaidByType;

public interface Payment {

   BigDecimal getAmount();

   void setAmount(BigDecimal var1);

   PaidByType getPaidBy();

   void setPaidBy(PaidByType var1);

   Float getPaymentPercent();

   void setPaymentPercent(Float var1);
}
