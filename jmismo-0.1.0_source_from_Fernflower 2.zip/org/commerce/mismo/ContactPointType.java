package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class ContactPointType extends Enum {

   public static final ContactPointType EMAIL = new ContactPointType("Email");
   public static final ContactPointType FAX = new ContactPointType("Fax");
   public static final ContactPointType OTHER = new ContactPointType("Other");
   public static final ContactPointType PHONE = new ContactPointType("Phone");
   static Class class$org$commerce$mismo$ContactPointType;


   private ContactPointType(String name) {
      super(name);
   }

   public static ContactPointType getEnum(String type) {
      return (ContactPointType)getEnum(class$org$commerce$mismo$ContactPointType == null?(class$org$commerce$mismo$ContactPointType = class$("org.commerce.mismo.ContactPointType")):class$org$commerce$mismo$ContactPointType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$ContactPointType == null?(class$org$commerce$mismo$ContactPointType = class$("org.commerce.mismo.ContactPointType")):class$org$commerce$mismo$ContactPointType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$ContactPointType == null?(class$org$commerce$mismo$ContactPointType = class$("org.commerce.mismo.ContactPointType")):class$org$commerce$mismo$ContactPointType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$ContactPointType == null?(class$org$commerce$mismo$ContactPointType = class$("org.commerce.mismo.ContactPointType")):class$org$commerce$mismo$ContactPointType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
