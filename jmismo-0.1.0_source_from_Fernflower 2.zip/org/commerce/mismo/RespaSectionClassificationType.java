package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class RespaSectionClassificationType extends Enum {

   public static final RespaSectionClassificationType HUD_110_GROSS_AMOUNT_DUE_FROM_BORROWER = new RespaSectionClassificationType("100", "GrossAmountDueFromBorrower");
   public static final RespaSectionClassificationType HUD_200_AMOUNTS_PAID_BY_BORROWER = new RespaSectionClassificationType("200", "AmountsPaidByOrInBehalfOfBorrower");
   public static final RespaSectionClassificationType HUD_300_CASH_FROM_TO_BORROWER = new RespaSectionClassificationType("300", "CashAtSettlementFromToBorrower");
   public static final RespaSectionClassificationType HUD_400_GROSS_AMOUNT_DUE_TO_SELLER = new RespaSectionClassificationType("400", "GrossAmountDueToSeller");
   public static final RespaSectionClassificationType HUD_500_REDUCTIONS_IN_AMOUNT_DUE_TO_SELLER = new RespaSectionClassificationType("500", "ReductionsInAmountDueToSeller");
   public static final RespaSectionClassificationType HUD_600_CASH_TO_FROM_SELLER = new RespaSectionClassificationType("600", "CashAtSettlementToFromSeller");
   public static final RespaSectionClassificationType HUD_700_DIVISION_OF_COMMISSION = new RespaSectionClassificationType("700", "DivisionOfCommission");
   public static final RespaSectionClassificationType HUD_800_LOAN_FEES = new RespaSectionClassificationType("800", "LoanFees");
   public static final RespaSectionClassificationType HUD_900_REQUIRED_LENDER_PAID_IN_ADVANCE = new RespaSectionClassificationType("900", "RequiredLenderPaidInAdvance");
   public static final RespaSectionClassificationType HUD_1000_RESERVES_DEPOSITED_WITH_LENDER = new RespaSectionClassificationType("1000", "ReservesDepositedWithLender");
   public static final RespaSectionClassificationType HUD_1100_TITLE_CHARGES = new RespaSectionClassificationType("1100", "TitleCharges");
   public static final RespaSectionClassificationType HUD_1200_RECORDING_AND_TRANSFER_CHARGES = new RespaSectionClassificationType("1200", "RecordingAndTransferCharges");
   public static final RespaSectionClassificationType HUD_1300_ADDITIONAL_SETTLEMENT_FEES = new RespaSectionClassificationType("1300", "AdditionalSettlementFees");
   static Class class$org$commerce$mismo$RespaSectionClassificationType;


   private RespaSectionClassificationType(String hudNum, String name) {
      super(hudNum + ":" + name);
   }

   public static RespaSectionClassificationType getEnum(String type) {
      return (RespaSectionClassificationType)getEnum(class$org$commerce$mismo$RespaSectionClassificationType == null?(class$org$commerce$mismo$RespaSectionClassificationType = class$("org.commerce.mismo.RespaSectionClassificationType")):class$org$commerce$mismo$RespaSectionClassificationType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$RespaSectionClassificationType == null?(class$org$commerce$mismo$RespaSectionClassificationType = class$("org.commerce.mismo.RespaSectionClassificationType")):class$org$commerce$mismo$RespaSectionClassificationType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$RespaSectionClassificationType == null?(class$org$commerce$mismo$RespaSectionClassificationType = class$("org.commerce.mismo.RespaSectionClassificationType")):class$org$commerce$mismo$RespaSectionClassificationType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$RespaSectionClassificationType == null?(class$org$commerce$mismo$RespaSectionClassificationType = class$("org.commerce.mismo.RespaSectionClassificationType")):class$org$commerce$mismo$RespaSectionClassificationType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
