package org.commerce.mismo;

import java.math.BigDecimal;
import org.commerce.mismo.HousingExpenseType;
import org.commerce.mismo.Mismo;

public interface ProposedHousingExpense extends Mismo {

   BigDecimal getPaymentAmount();

   void setPaymentAmount(BigDecimal var1);

   HousingExpenseType getHousingExpenseType();

   void setHousingExpenseType(HousingExpenseType var1);
}
