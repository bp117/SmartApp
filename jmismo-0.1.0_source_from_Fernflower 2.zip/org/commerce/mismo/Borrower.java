package org.commerce.mismo;

import java.util.Date;
import org.commerce.mismo.CurrentIncome;
import org.commerce.mismo.Declaration;
import org.commerce.mismo.Dependent;
import org.commerce.mismo.Employer;
import org.commerce.mismo.GovernmentMonitoring;
import org.commerce.mismo.Identification;
import org.commerce.mismo.JointAssetLiabilityReportingType;
import org.commerce.mismo.MailTo;
import org.commerce.mismo.MaritalStatus;
import org.commerce.mismo.PresentHousingExpense;
import org.commerce.mismo.PrintPositionType;
import org.commerce.mismo.Residence;
import org.commerce.mismo.ResidentAlienCard;

public interface Borrower {

   void setBorrowerId(Long var1);

   Long getBorrowerId();

   String getFirstName();

   void setFirstName(String var1);

   String getMiddleName();

   void setMiddleName(String var1);

   String getLastName();

   void setLastName(String var1);

   String getUnparsedName();

   String getNameSuffix();

   void setNameSuffix(String var1);

   PrintPositionType getPrintPositionType();

   void setPrintPositionType(PrintPositionType var1);

   String getSSN();

   void setSSN(String var1);

   int getDependentCount();

   Dependent[] getDependents();

   void addDependent(Dependent var1);

   void setDependentCount(int var1);

   Date getBirthDate();

   void setBirthDate(Date var1);

   MaritalStatus getMaritalStatus();

   void setMaritalStatus(MaritalStatus var1);

   String getHomePhoneNumber();

   void setHomePhoneNumber(String var1);

   JointAssetLiabilityReportingType getJointAssetResidenceReportingType();

   void setJointAssetLiabilityReportingType(JointAssetLiabilityReportingType var1);

   Borrower getJointAssetBorrower();

   void setJointAssetBorrower(Borrower var1);

   Integer getAgeAtApplicationYears();

   void setAgeAtApplicationYears(Integer var1);

   void addResidence(Residence var1);

   Integer getSchoolingYears();

   void setSchoolingYears(Integer var1);

   Residence[] getResidences();

   Residence createResidence();

   MailTo createMailTo();

   MailTo getMailTo();

   Identification getIdentification();

   ResidentAlienCard getResidentAlienCard();

   void setMailTo(MailTo var1);

   void setIdentification(Identification var1);

   void setResidentAlienCard(ResidentAlienCard var1);

   void addEmployer(Employer var1);

   Employer[] getEmployers();

   Employer createEmployer();

   void addCurrentIncome(CurrentIncome var1);

   CurrentIncome[] getCurrentIncomes();

   CurrentIncome createCurrentIncome();

   void addHousingExpense(PresentHousingExpense var1);

   PresentHousingExpense[] getHousingExpenses();

   PresentHousingExpense createHousingExpense();

   Declaration getDeclarations();

   GovernmentMonitoring getGovernmentMonitoring();

   void setGovernmentMonitoring(GovernmentMonitoring var1);
}
