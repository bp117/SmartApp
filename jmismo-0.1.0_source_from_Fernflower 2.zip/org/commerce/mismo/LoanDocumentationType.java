package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class LoanDocumentationType extends Enum {

   public static final LoanDocumentationType ALTERNATIVE = new LoanDocumentationType("Alternative");
   public static final LoanDocumentationType FULL_DOCUMENTATION = new LoanDocumentationType("FullDocumentation");
   public static final LoanDocumentationType NO_DEPOSIT_VERIFICATION = new LoanDocumentationType("NoDepositVerification");
   public static final LoanDocumentationType NO_DEPOSIT_OR_EMPLOYMENT_OR_INCOME_VERIFICATION = new LoanDocumentationType("NoDepositVerificationEmploymentVerificationOrIncomeVerification");
   public static final LoanDocumentationType NO_DOCUMENTATION = new LoanDocumentationType("NoDocumentation");
   public static final LoanDocumentationType NO_EMPLOYMENT_OR_INCOME_VERIFICATION = new LoanDocumentationType("NoEmploymentVerificationOrIncomeVerification");
   public static final LoanDocumentationType REDUCED = new LoanDocumentationType("Reduced");
   public static final LoanDocumentationType STREAMLINE_REFINANCE = new LoanDocumentationType("StreamlineRefinance");
   static Class class$org$commerce$mismo$LoanDocumentationType;


   private LoanDocumentationType(String name) {
      super(name);
   }

   public static LoanDocumentationType getEnum(String color) {
      return (LoanDocumentationType)getEnum(class$org$commerce$mismo$LoanDocumentationType == null?(class$org$commerce$mismo$LoanDocumentationType = class$("org.commerce.mismo.LoanDocumentationType")):class$org$commerce$mismo$LoanDocumentationType, color);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$LoanDocumentationType == null?(class$org$commerce$mismo$LoanDocumentationType = class$("org.commerce.mismo.LoanDocumentationType")):class$org$commerce$mismo$LoanDocumentationType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$LoanDocumentationType == null?(class$org$commerce$mismo$LoanDocumentationType = class$("org.commerce.mismo.LoanDocumentationType")):class$org$commerce$mismo$LoanDocumentationType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$LoanDocumentationType == null?(class$org$commerce$mismo$LoanDocumentationType = class$("org.commerce.mismo.LoanDocumentationType")):class$org$commerce$mismo$LoanDocumentationType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
