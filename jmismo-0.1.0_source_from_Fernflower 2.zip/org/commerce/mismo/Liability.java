package org.commerce.mismo;

import java.math.BigDecimal;
import org.apache.commons.lang.enums.Enum;
import org.commerce.mismo.LiabilityType;
import org.commerce.mismo.Mismo;
import org.commerce.mismo.MultiBorrowerAssociatedEntity;
import org.commerce.mismo.REOProperty;

public interface Liability extends MultiBorrowerAssociatedEntity, Mismo {

   REOProperty getREOProperty();

   void setREOProperty(REOProperty var1);

   LiabilityType getLiabilityType();

   Enum getType();

   void setLiabilityType(LiabilityType var1);

   String getHolderName();

   void setHolderName(String var1);

   BigDecimal getMonthlyPaymentAmount();

   BigDecimal getAmount();

   void setMonthlyPaymentAmount(BigDecimal var1);

   BigDecimal getUnpaidBalanceAmount();

   void setUnpaidBalanceAmount(BigDecimal var1);

   String getAccountIdentifier();

   void setAccountIdentifier(String var1);

   Boolean getPayoffStatusIndicator();

   void setPayoffStatusIndicator(Boolean var1);
}
