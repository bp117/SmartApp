package org.commerce.mismo;

import org.commerce.mismo.HMDAPurposeOfLoanType;

public interface GovernmentReporting {

   void setHMDAPurposeOfLoanType(HMDAPurposeOfLoanType var1);

   HMDAPurposeOfLoanType getHMDAPurposeOfLoanType();
}
