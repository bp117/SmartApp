package org.commerce.mismo.util;

import java.io.BufferedWriter;
import java.io.CharArrayWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class StringUtil {

   protected static final Log log = LogFactory.getLog(class$org$commerce$mismo$util$StringUtil == null?(class$org$commerce$mismo$util$StringUtil = class$("org.commerce.mismo.util.StringUtil")):class$org$commerce$mismo$util$StringUtil);
   public static final String DELIMITER = ",";
   public static final HashMap CODE_MAP = new HashMap(4);
   public static final String CURRENT_DATE_AND_TIME_PATTERN = "MM/dd/yyyy, hh:mm:ss a z";
   public static final SimpleDateFormat CURRENT_DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy, hh:mm:ss a z");
   private static final int PHONE_NUMBER_LENGTH = 10;
   private static final int AREA_CODE_LENGTH = 3;
   private static final int PHONE_HYPHEN_BREAK = 3;
   static Class class$org$commerce$mismo$util$StringUtil;


   public static String nullToBlank(Object theObj) {
      return theObj == null?"":theObj.toString();
   }

   public static String blankToNull(String theStr) {
      return theStr == null?null:(theStr.trim().length() == 0?null:theStr);
   }

   public static boolean nullOrBlank(Object theObj) {
      return theObj == null || theObj instanceof String && ((String)theObj).trim().length() == 0;
   }

   public static String[] makeStringArray(Object theObject) {
      return theObject != null && theObject instanceof String[]?(String[])theObject:new String[0];
   }

   public static String quoteNonNull(Object s) {
      return s == null?"NULL":"\'" + String.valueOf(s) + "\'";
   }

   public static int countOccurrences(String source, String match) {
      int count = 0;
      if(source != null && match != null && match.length() > 0) {
         for(int currPos = 0; source.length() >= currPos && (currPos = source.indexOf(match, currPos)) > -1; ++count) {
            ++currPos;
         }
      }

      return count;
   }

   public static String[] parseDelimitedString(String source, String delim, boolean trim, boolean ignoreBlankToken) {
      return parseDelimitedString(source, delim, trim, ignoreBlankToken, false);
   }

   public static String[] parseDelimitedString(String source, String delim, boolean trim, boolean ignoreBlankToken, boolean ignoreCase) {
      Vector v = new Vector();
      source = source != null?source + delim:delim;
      String searchSource = null;
      if(ignoreCase) {
         delim = delim.toUpperCase();
         searchSource = source.toUpperCase();
      } else {
         searchSource = source;
      }

      int delimLength = delim.length();
      int curPos = 0;

      for(int nextPos = searchSource.indexOf(delim); nextPos >= curPos; nextPos = searchSource.indexOf(delim, curPos)) {
         String token = source.substring(curPos, nextPos);
         if(token != null && trim) {
            token = token.trim();
         }

         if(ignoreBlankToken) {
            token = blankToNull(token);
         }

         if(token != null || !ignoreBlankToken) {
            v.add(token);
         }

         curPos = nextPos + delimLength;
      }

      return (String[])v.toArray(new String[0]);
   }

   public static String[] parseDelimitedString(String source, String delim) {
      return parseDelimitedString(source, delim, false, false, false);
   }

   public static String parseToDelimString(Hashtable hash) {
      StringBuffer buff = new StringBuffer();
      String key;
      String value;
      if(hash != null) {
         for(Enumeration e = hash.keys(); e.hasMoreElements(); buff.append(key + " = " + value)) {
            key = (String)e.nextElement();
            value = getValue(hash.get(key));
            if(buff.length() > 0) {
               buff.append(", ");
            }
         }
      }

      return buff.toString();
   }

   public static Vector separateString(String theString, int theSize) {
      if(theString != null && theSize != 0) {
         Vector v = new Vector();

         int idx;
         for(idx = 0; idx + theSize < theString.length(); idx += theSize) {
            v.addElement(theString.substring(idx, idx + theSize));
         }

         v.addElement(theString.substring(idx, theString.length()));
         return v;
      } else {
         return null;
      }
   }

   public static boolean isNumeric(String theString) {
      if(theString == null) {
         return false;
      } else {
         StringBuffer sb = new StringBuffer(theString);

         for(int i = 0; i < sb.length(); ++i) {
            if(!isNumeric(sb.charAt(i))) {
               return false;
            }
         }

         return true;
      }
   }

   private static boolean isNumeric(char theChar) {
      return isNumeric(theChar, (String)null);
   }

   private static boolean isNumeric(char theChar, String theOtherAllowables) {
      String numbers = "0123456789" + (theOtherAllowables != null?theOtherAllowables:"");
      return numbers.indexOf(theChar) >= 0;
   }

   public static String replace(String theSource, String theMatch, String theReplace) {
      return replace(theSource, theMatch, theReplace, true);
   }

   public static String replace(String theString, String theMatch, String theReplace, boolean useCaseSensitivity) {
      if(theString == null) {
         return null;
      } else if(theMatch == null) {
         return theString;
      } else {
         StringBuffer sb = new StringBuffer();
         int matchLength = theMatch.length();
         int oldIdx = 0;
         boolean newIdx = false;
         String sourceSearcher = useCaseSensitivity?theString:theString.toUpperCase();

         int newIdx1;
         for(String matchSearcher = useCaseSensitivity?theMatch:theMatch.toUpperCase(); (newIdx1 = sourceSearcher.indexOf(matchSearcher, oldIdx)) != -1; oldIdx = newIdx1 + matchLength) {
            sb.append(theString.substring(oldIdx, newIdx1));
            sb.append(theReplace);
         }

         sb.append(theString.substring(oldIdx, theString.length()));
         return sb.toString();
      }
   }

   public static final Timestamp toTimestamp(String s) {
      return s != null && s.trim().length() != 0?Timestamp.valueOf(s):null;
   }

   public static String toProperCase(String s) {
      if(s == null) {
         return "";
      } else {
         String firstChar = s.substring(0, 1).toUpperCase();
         String restOfChars = s.substring(1).toLowerCase();
         return firstChar + restOfChars;
      }
   }

   public static final Timestamp mdyToTimestamp(String theDate) {
      SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
      ParsePosition pos = new ParsePosition(0);
      Date formattedDate = format.parse(theDate, pos);
      if(formattedDate == null) {
         throw new IllegalArgumentException(theDate);
      } else {
         return new Timestamp(formattedDate.getTime());
      }
   }

   public static final Timestamp mdyToTimestamp(String theDate, String theTime) {
      return mdyToTimestamp(theDate, theTime, "MM/dd/yyyy hh:mm:ss");
   }

   public static final Timestamp mdyToTimestamp(String theDate, String theTime, String thePattern) {
      SimpleDateFormat format = new SimpleDateFormat(thePattern);
      ParsePosition pos = new ParsePosition(0);
      Date formattedDate = format.parse(theDate + " " + theTime, pos);
      if(formattedDate == null) {
         throw new IllegalArgumentException(theDate);
      } else {
         return new Timestamp(formattedDate.getTime());
      }
   }

   public static final Integer toInteger(String s) {
      try {
         return s != null && s.trim().length() != 0?Integer.valueOf(s):null;
      } catch (NumberFormatException var2) {
         return null;
      }
   }

   public static String padRight(String theString, char theChar, int theLength) {
      String data = theString == null?"":theString;
      StringBuffer sb = new StringBuffer(data);

      for(int i = data.length(); i < theLength; ++i) {
         sb.append(theChar);
      }

      return sb.toString();
   }

   public static String padLeft(String theString, char theChar, int theLength) {
      String data = theString == null?"":theString;
      StringBuffer sb = new StringBuffer();

      for(int i = 0; i < theLength - data.length(); ++i) {
         sb.append(theChar);
      }

      sb.append(data);
      return sb.toString();
   }

   public static String checked(boolean theArg) {
      return theArg?"CHECKED":"";
   }

   public static String checked(String theArg) {
      return theArg != null && theArg.equalsIgnoreCase("Y")?"CHECKED":"";
   }

   public static String selected(boolean theArg) {
      return theArg?"SELECTED":"";
   }

   public static String formatDate(Date theDate) {
      return formatDate(theDate, "MM/dd/yyyy");
   }

   public static String formatDate(Date theDate, String thePattern) {
      String value = null;
      if(theDate != null && thePattern != null) {
         SimpleDateFormat dateFormat = new SimpleDateFormat(thePattern);
         value = dateFormat.format(theDate);
      }

      return value != null?value:"";
   }

   public static String formatCurrentDateAndTime() {
      Date date = new Date(System.currentTimeMillis());
      return CURRENT_DATE_FORMAT.format(date);
   }

   public static Date stringToDate(String dateString) {
      Date t = stringToDate(dateString, "MM/dd/yyyy");
      if(t == null) {
         t = stringToDate(dateString, "M/dd/yyyy");
      }

      return t;
   }

   public static Date stringToDate(String dateString, String thePattern) {
      Date theDate = null;
      SimpleDateFormat sdf = new SimpleDateFormat();

      try {
         sdf.applyPattern(thePattern);
         theDate = sdf.parse(dateString);
      } catch (ParseException var5) {
         ;
      }

      return theDate;
   }

   public static String convertDatePatternOnString(String dateString, String pattern1, String pattern2) {
      String convertedDateString = null;
      Date tmpDate = stringToDate(dateString, pattern1);
      if(tmpDate != null) {
         convertedDateString = formatDate(tmpDate, pattern2);
      }

      return convertedDateString;
   }

   public static String formatTimestamp(Timestamp timeStamp) {
      return formatTimestamp(timeStamp, "MM/dd/yyyy hh:mm:ss");
   }

   public static String formatTimestamp(Timestamp timeStamp, String thePattern) {
      String value = null;
      if(timeStamp != null && thePattern != null) {
         value = formatDate(new Timestamp(timeStamp.getTime()), thePattern);
      }

      return value != null?value:"";
   }

   public static String encode(Object theArg) {
      try {
         return URLEncoder.encode(theArg != null?theArg.toString():"", "UTF-8");
      } catch (UnsupportedEncodingException var2) {
         log.error("Unable to parse/encode: " + theArg, var2);
         return (String)theArg;
      }
   }

   public static String encodeSpecial(String theArg) {
      String value = theArg;
      Set set = CODE_MAP.keySet();
      String code = null;

      for(Iterator i = set.iterator(); i.hasNext(); value = replace(value, code, (String)CODE_MAP.get(code))) {
         code = (String)i.next();
      }

      return value;
   }

   public static String decodeSpecial(String theArg) {
      String value = theArg;
      Set set = CODE_MAP.keySet();
      String code = null;

      for(Iterator i = set.iterator(); i.hasNext(); value = replace(value, (String)CODE_MAP.get(code), code)) {
         code = (String)i.next();
      }

      return value;
   }

   public static String formatPrice(double number) {
      NumberFormat numberFormatter = NumberFormat.getCurrencyInstance();
      return numberFormatter.format(number);
   }

   public static String formatPhone(String phone) {
      String formattedPhone = "";
      if(phone != null) {
         formattedPhone = extractDigits(phone);
         if(StringUtils.isNotEmpty(phone)) {
            if(formattedPhone.length() >= 10) {
               StringBuffer sb = new StringBuffer();
               sb.append(formattedPhone.substring(0, 3));
               sb.append('-');
               sb.append(formattedPhone.substring(3, 6));
               sb.append('-');
               sb.append(formattedPhone.substring(6, 10));
               if(formattedPhone.length() > 10) {
                  sb.append(" X");
                  sb.append(formattedPhone.substring(10));
               }

               formattedPhone = sb.toString();
            } else {
               formattedPhone = phone;
            }
         }
      }

      return formattedPhone;
   }

   public static String millisToDaysHoursMinutes(long millis) {
      long absMillis = Math.abs(millis);
      long days = absMillis / 86400000L;
      long hours = absMillis % 86400000L / 3600000L;
      long minutes = absMillis % 86400000L % 3600000L / 60000L;
      return (millis < 0L?"-":"") + padLeft(String.valueOf(days), '0', 2) + ":" + padLeft(String.valueOf(hours), '0', 2) + ":" + padLeft(String.valueOf(minutes), '0', 2);
   }

   public static String getValue(Object field) {
      return getValue(field, (String)null);
   }

   public static String getValue(Object theField, String theDefault) {
      String value = theDefault;
      if(theField != null) {
         if(theField instanceof String) {
            value = (String)theField;
         }

         if(theField instanceof String[]) {
            value = ((String[])theField)[0];
         }
      }

      return value;
   }

   public static boolean isAlphaNumeric(String theStringToTest) {
      return isAlphaNumeric(theStringToTest, (String)null);
   }

   public static boolean isAlphaNumeric(String theStringToTest, String theOtherAllowables) {
      boolean isAlphaNumeric = theStringToTest != null;
      StringBuffer sb = new StringBuffer(theStringToTest);

      for(int i = 0; i < sb.length() && isAlphaNumeric; ++i) {
         isAlphaNumeric = isAlpha(sb.charAt(i), theOtherAllowables) || isNumeric(sb.charAt(i), theOtherAllowables);
      }

      return isAlphaNumeric;
   }

   public static boolean isAlpha(String theStringToTest) {
      boolean isAlpha = theStringToTest != null;
      StringBuffer sb = new StringBuffer(theStringToTest);

      for(int i = 0; i < sb.length() && isAlpha; ++i) {
         isAlpha = isAlpha(sb.charAt(i));
      }

      return isAlpha;
   }

   public static boolean isAlpha(char theCharToTest) {
      return isAlpha(theCharToTest, (String)null);
   }

   private static boolean isAlpha(char theCharToTest, String theOtherAllowables) {
      String alphas = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" + (theOtherAllowables != null?theOtherAllowables:"");
      return alphas.indexOf(theCharToTest) >= 0;
   }

   public static String truncate(String s, int maxLength) {
      return truncate(s, maxLength, (String)null);
   }

   public static String truncate(String s, int maxLength, String suffix) {
      if(s != null) {
         if(s.length() <= maxLength) {
            return s;
         } else {
            int suffixLength = 0;
            if(suffix != null) {
               suffixLength = suffix.length();
            }

            String returnedString = s.substring(0, maxLength - suffixLength);
            if(suffixLength > 0) {
               returnedString = returnedString + suffix;
            }

            return returnedString;
         }
      } else {
         return null;
      }
   }

   public static String extractDigits(String text) {
      String result = new String();

      for(int i = 0; i < text.length(); ++i) {
         char c = text.charAt(i);
         if(Character.isDigit(c)) {
            result = result + c;
         }
      }

      return result;
   }

   public static void printStackTraceToStringBuffer(Exception e, StringBuffer sb) {
      CharArrayWriter caw = new CharArrayWriter(100);
      BufferedWriter bw = new BufferedWriter(caw);
      PrintWriter pw = new PrintWriter(bw);
      e.printStackTrace(pw);
      pw.flush();
      sb.append("\nStack trace is:\n");
      sb.append(caw.toCharArray());
   }

   public static boolean isZeroLength(String str) {
      return null == str || str.length() <= 0;
   }

   public static String getStackTrace(Exception e) {
      if(null == e) {
         return "";
      } else {
         StringWriter sw = new StringWriter();
         PrintWriter pw = new PrintWriter(sw);
         e.printStackTrace(pw);
         return sw.getBuffer().toString();
      }
   }

   public static String arrayToString(Object[] array, String delimiter, String quoteCharacter) {
      if(array == null) {
         return "";
      } else {
         StringBuffer sb = new StringBuffer();

         for(int i = 0; i < array.length; ++i) {
            if(i > 0) {
               sb.append(delimiter);
            }

            sb.append(quoteCharacter + array[i].toString() + quoteCharacter);
         }

         return sb.toString();
      }
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

   static {
      CODE_MAP.put("\"", "&quot;");
      CODE_MAP.put("<", "&lt;");
      CODE_MAP.put(">", "&gt;");
      CODE_MAP.put("\'", "&#39;");
   }
}
