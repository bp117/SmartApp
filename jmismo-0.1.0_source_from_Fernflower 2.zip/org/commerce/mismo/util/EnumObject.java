package org.commerce.mismo.util;

import org.apache.commons.lang.enums.Enum;

public interface EnumObject {

   Enum getType();
}
