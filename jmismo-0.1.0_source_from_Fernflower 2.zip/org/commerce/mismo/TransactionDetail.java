package org.commerce.mismo;

import java.math.BigDecimal;

public interface TransactionDetail {

   Float getEstimatedClosingCostsAmount();

   void setEstimatedClosingCostsAmount(Float var1);

   Float getPurchasePriceAmount();

   void setPurchasePriceAmount(Float var1);

   BigDecimal getRefinanceIncludingDebtsToBePaidOffAmount();

   void setRefinanceIncludingDebtsToBePaidOffAmount(BigDecimal var1);
}
