package org.commerce.mismo;

import org.commerce.mismo.ContactPointRoleType;
import org.commerce.mismo.ContactPointType;

public interface ContactPoint {

   ContactPointRoleType getRoleType();

   void setRoleType(ContactPointRoleType var1);

   ContactPointType getType();

   void setType(ContactPointType var1);

   String getTypeOtherDescription();

   void setTypeOtherDescription(String var1);

   String getValue();

   void setValue(String var1);

   Boolean getPreferenceIndicator();

   void setPreferenceIndicator(Boolean var1);
}
