package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class RespaType extends Enum {

   public static final RespaType HUD_203_KDISCOUNT_ON_REPAIRS = new RespaType("203KDiscountOnRepairs");
   public static final RespaType HUD_203_KPERMITS = new RespaType("203KPermits");
   public static final RespaType HUD_203_KARCHITECTURAL_AND_ENGINEERING_FEE = new RespaType("203KArchitecturalAndEngineeringFee");
   public static final RespaType HUD_203_KINSPECTION_FEE = new RespaType("203KInspectionFee");
   public static final RespaType HUD_203_KSUPPLEMENTAL_ORIGINATION_FEE = new RespaType("203KSupplementalOriginationFee");
   public static final RespaType HUD_203_KCONSULTANT_FEE = new RespaType("203KConsultantFee");
   public static final RespaType HUD_203_KTITLE_UPDATE = new RespaType("203KTitleUpdate");
   public static final RespaType ABSTRACT_OR_TITLE_SEARCH_FEE = new RespaType("AbstractOrTitleSearchFee");
   public static final RespaType AMORTIZATION_FEE = new RespaType("AmortizationFee");
   public static final RespaType APPLICATION_FEE = new RespaType("ApplicationFee");
   public static final RespaType APPRAISAL_FEE = new RespaType("AppraisalFee");
   public static final RespaType ASSIGNMENT_FEE = new RespaType("AssignmentFee");
   public static final RespaType ASSIGNMENT_RECORDING_FEE = new RespaType("AssignmentRecordingFee");
   public static final RespaType ASSUMPTION_FEE = new RespaType("AssumptionFee");
   public static final RespaType ATTORNEY_FEE = new RespaType("AttorneyFee");
   public static final RespaType BOND_REVIEW_FEE = new RespaType("BondReviewFee");
   public static final RespaType CITY_COUNTY_DEED_TAX_STAMP_FEE = new RespaType("CityCountyDeedTaxStampFee");
   public static final RespaType CITY_COUNTY_MORTGAGE_TAX_STAMP_FEE = new RespaType("CityCountyMortgageTaxStampFee");
   public static final RespaType CLOACCESS_FEE = new RespaType("CLOAccessFee");
   public static final RespaType COMMITMENT_FEE = new RespaType("CommitmentFee");
   public static final RespaType COPY_FAX_FEE = new RespaType("CopyFaxFee");
   public static final RespaType COURIER_FEE = new RespaType("CourierFee");
   public static final RespaType CREDIT_REPORT_FEE = new RespaType("CreditReportFee");
   public static final RespaType DEED_RECORDING_FEE = new RespaType("DeedRecordingFee");
   public static final RespaType DOCUMENT_PREPARATION_FEE = new RespaType("DocumentPreparationFee");
   public static final RespaType DOCUMENTARY_STAMP_FEE = new RespaType("DocumentaryStampFee");
   public static final RespaType ESCROW_WAIVER_FEE = new RespaType("EscrowWaiverFee");
   public static final RespaType FLOOD_CERTIFICATION = new RespaType("FloodCertification");
   public static final RespaType GENERAL_COUNSEL_FEE = new RespaType("GeneralCounselFee");
   public static final RespaType INSPECTION_FEE = new RespaType("InspectionFee");
   public static final RespaType LOAN_DISCOUNT_POINTS = new RespaType("LoanDiscountPoints");
   public static final RespaType LOAN_ORIGINATION_FEE = new RespaType("LoanOriginationFee");
   public static final RespaType MODIFICATION_FEE = new RespaType("ModificationFee");
   public static final RespaType MORTGAGE_BROKER_FEE = new RespaType("MortgageBrokerFee");
   public static final RespaType MORTGAGE_RECORDING_FEE = new RespaType("MortgageRecordingFee");
   public static final RespaType MUNICIPAL_LIEN_CERTIFICATE_FEE = new RespaType("MunicipalLienCertificateFee");
   public static final RespaType MUNICIPAL_LIEN_CERTIFICATE_RECORDING_FEE = new RespaType("MunicipalLienCertificateRecordingFee");
   public static final RespaType NEW_LOAN_ADMINISTRATION_FEE = new RespaType("NewLoanAdministrationFee");
   public static final RespaType NOTARY_FEE = new RespaType("NotaryFee");
   public static final RespaType OTHER = new RespaType("Other");
   public static final RespaType PEST_INSPECTION_FEE = new RespaType("PestInspectionFee");
   public static final RespaType PROCESSING_FEE = new RespaType("ProcessingFee");
   public static final RespaType REDRAW_FEE = new RespaType("RedrawFee");
   public static final RespaType REINSPECTION_FEE = new RespaType("ReinspectionFee");
   public static final RespaType RELEASE_RECORDING_FEE = new RespaType("ReleaseRecordingFee");
   public static final RespaType RURAL_HOUSING_FEE = new RespaType("RuralHousingFee");
   public static final RespaType SETTLEMENT_OR_CLOSING_FEE = new RespaType("SettlementOrClosingFee");
   public static final RespaType STATE_DEED_TAX_STAMP_FEE = new RespaType("StateDeedTaxStampFee");
   public static final RespaType STATE_MORTGAGE_TAX_STAMP_FEE = new RespaType("StateMortgageTaxStampFee");
   public static final RespaType SURVEY_FEE = new RespaType("SurveyFee");
   public static final RespaType TAX_RELATED_SERVICE_FEE = new RespaType("TaxRelatedServiceFee");
   public static final RespaType TITLE_EXAMINATION_FEE = new RespaType("TitleExaminationFee");
   public static final RespaType TITLE_INSURANCE_BINDER_FEE = new RespaType("TitleInsuranceBinderFee");
   public static final RespaType TITLE_INSURANCE_FEE = new RespaType("TitleInsuranceFee");
   public static final RespaType UNDERWRITING_FEE = new RespaType("UnderwritingFee");
   static Class class$org$commerce$mismo$RespaType;


   private RespaType(String name) {
      super(name);
   }

   public static RespaType getEnum(String type) {
      return (RespaType)getEnum(class$org$commerce$mismo$RespaType == null?(class$org$commerce$mismo$RespaType = class$("org.commerce.mismo.RespaType")):class$org$commerce$mismo$RespaType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$RespaType == null?(class$org$commerce$mismo$RespaType = class$("org.commerce.mismo.RespaType")):class$org$commerce$mismo$RespaType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$RespaType == null?(class$org$commerce$mismo$RespaType = class$("org.commerce.mismo.RespaType")):class$org$commerce$mismo$RespaType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$RespaType == null?(class$org$commerce$mismo$RespaType = class$("org.commerce.mismo.RespaType")):class$org$commerce$mismo$RespaType);
   }

   public static RespaType getType(int hudNumber) {
      switch(hudNumber) {
      case 802:
         return LOAN_ORIGINATION_FEE;
      case 803:
         return APPLICATION_FEE;
      case 810:
         return FLOOD_CERTIFICATION;
      case 811:
         return TAX_RELATED_SERVICE_FEE;
      case 1101:
         return SETTLEMENT_OR_CLOSING_FEE;
      case 1108:
         return TITLE_INSURANCE_FEE;
      case 1201:
         return MORTGAGE_RECORDING_FEE;
      default:
         return OTHER;
      }
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
