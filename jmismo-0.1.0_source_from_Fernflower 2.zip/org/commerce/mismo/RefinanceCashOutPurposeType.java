package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public class RefinanceCashOutPurposeType extends Enum {

   public static String PURPOSE_HOME_IMPROVEMENT = "HomeImprovement";
   public static String PURPOSE_HOME_PURCHASE = "HomePurchase";
   public static String PURPOSE_OTHER = "Other";
   public static RefinanceCashOutPurposeType HOME_IMPROVEMENT = new RefinanceCashOutPurposeType(PURPOSE_HOME_IMPROVEMENT);
   public static RefinanceCashOutPurposeType HOME_PURCHASE = new RefinanceCashOutPurposeType(PURPOSE_HOME_PURCHASE);
   public static RefinanceCashOutPurposeType OTHER = new RefinanceCashOutPurposeType(PURPOSE_OTHER);
   static Class class$org$commerce$mismo$RefinanceCashOutPurposeType;


   public RefinanceCashOutPurposeType(String name) {
      super(name);
   }

   public static RefinanceCashOutPurposeType getEnum(String type) {
      return (RefinanceCashOutPurposeType)getEnum(class$org$commerce$mismo$RefinanceCashOutPurposeType == null?(class$org$commerce$mismo$RefinanceCashOutPurposeType = class$("org.commerce.mismo.RefinanceCashOutPurposeType")):class$org$commerce$mismo$RefinanceCashOutPurposeType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$RefinanceCashOutPurposeType == null?(class$org$commerce$mismo$RefinanceCashOutPurposeType = class$("org.commerce.mismo.RefinanceCashOutPurposeType")):class$org$commerce$mismo$RefinanceCashOutPurposeType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$RefinanceCashOutPurposeType == null?(class$org$commerce$mismo$RefinanceCashOutPurposeType = class$("org.commerce.mismo.RefinanceCashOutPurposeType")):class$org$commerce$mismo$RefinanceCashOutPurposeType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$RefinanceCashOutPurposeType == null?(class$org$commerce$mismo$RefinanceCashOutPurposeType = class$("org.commerce.mismo.RefinanceCashOutPurposeType")):class$org$commerce$mismo$RefinanceCashOutPurposeType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
