package org.commerce.mismo;

import org.commerce.mismo.Borrower;

public interface MultiBorrowerAssociatedEntity {

   Borrower[] getBorrowers();

   void addBorrower(Borrower var1);

   void removeBorrower(Borrower var1);
}
