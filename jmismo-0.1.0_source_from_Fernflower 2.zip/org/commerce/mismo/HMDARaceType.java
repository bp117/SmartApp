package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public class HMDARaceType extends Enum {

   public static final HMDARaceType AMERICAN_INDIAN_OR_ALASKAN_NATIVE = new HMDARaceType("AmericanIndianOrAlaskaNative");
   public static final HMDARaceType ASIAN = new HMDARaceType("Asian");
   public static final HMDARaceType BLACK_OR_AFRICAN_AMERICAN = new HMDARaceType("BlackOrAfricanAmerican");
   public static final HMDARaceType NATIVE_HAWAIIAN_OR_OTHER_PACIFIC_ISLANDER = new HMDARaceType("NativeHawaiianOrOtherPacificIslander");
   public static final HMDARaceType INFORMATION_NOT_PROVIDED = new HMDARaceType("InformationNotProvidedByApplicantInMailInternetOrTelephoneApplication");
   public static final HMDARaceType NOT_APPLICABLE = new HMDARaceType("NotApplicable");
   public static final HMDARaceType OTHER = new HMDARaceType("Other");
   public static final HMDARaceType WHITE = new HMDARaceType("White");
   static Class class$org$commerce$mismo$HMDARaceType;


   public HMDARaceType(String arg0) {
      super(arg0);
   }

   public static HMDARaceType getEnum(String type) {
      return (HMDARaceType)getEnum(class$org$commerce$mismo$HMDARaceType == null?(class$org$commerce$mismo$HMDARaceType = class$("org.commerce.mismo.HMDARaceType")):class$org$commerce$mismo$HMDARaceType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$HMDARaceType == null?(class$org$commerce$mismo$HMDARaceType = class$("org.commerce.mismo.HMDARaceType")):class$org$commerce$mismo$HMDARaceType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$HMDARaceType == null?(class$org$commerce$mismo$HMDARaceType = class$("org.commerce.mismo.HMDARaceType")):class$org$commerce$mismo$HMDARaceType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$HMDARaceType == null?(class$org$commerce$mismo$HMDARaceType = class$("org.commerce.mismo.HMDARaceType")):class$org$commerce$mismo$HMDARaceType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
