package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class LoanAmortizationType extends Enum {

   public static final LoanAmortizationType ADJUSTABLE_RATE = new LoanAmortizationType("AdjustableRate");
   public static final LoanAmortizationType FIXED = new LoanAmortizationType("Fixed");
   public static final LoanAmortizationType GRADUATED_PAYMENT_MORTGAGE = new LoanAmortizationType("GraduatedPaymentMortgage");
   public static final LoanAmortizationType GROWING_EQUITY_MORTGAGE = new LoanAmortizationType("GrowingEquityMortgage");
   public static final LoanAmortizationType OTHER_AMORTIZATION_TYPE = new LoanAmortizationType("OtherAmortizationType");
   static Class class$org$commerce$mismo$LoanAmortizationType;


   private LoanAmortizationType(String name) {
      super(name);
   }

   public static LoanAmortizationType getEnum(String type) {
      return (LoanAmortizationType)getEnum(class$org$commerce$mismo$LoanAmortizationType == null?(class$org$commerce$mismo$LoanAmortizationType = class$("org.commerce.mismo.LoanAmortizationType")):class$org$commerce$mismo$LoanAmortizationType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$LoanAmortizationType == null?(class$org$commerce$mismo$LoanAmortizationType = class$("org.commerce.mismo.LoanAmortizationType")):class$org$commerce$mismo$LoanAmortizationType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$LoanAmortizationType == null?(class$org$commerce$mismo$LoanAmortizationType = class$("org.commerce.mismo.LoanAmortizationType")):class$org$commerce$mismo$LoanAmortizationType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$LoanAmortizationType == null?(class$org$commerce$mismo$LoanAmortizationType = class$("org.commerce.mismo.LoanAmortizationType")):class$org$commerce$mismo$LoanAmortizationType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
