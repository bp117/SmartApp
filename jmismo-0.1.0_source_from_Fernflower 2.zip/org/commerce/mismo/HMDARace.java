package org.commerce.mismo;

import org.commerce.mismo.HMDARaceType;

public interface HMDARace {

   HMDARaceType getType();

   void setType(HMDARaceType var1);
}
