package org.commerce.mismo;


public interface ARM {

   Float getIndexCurrentValuePercent();

   void setIndexCurrentValuePercent(Float var1);

   Float getIndexMarginPercent();

   void setIndexMarginPercent(Float var1);

   Float getQualifyingRatePercent();

   void setQualifyingRatePercent(Float var1);

   Float getPaymentAdjustmentLifetimeCapAmount();

   void setPaymentAdjustmentLifetimeCapAmount(Float var1);

   Float getPaymentAdjustmentLifetimeCapPercent();

   void setPaymentAdjustmentLifetimeCapPercent(Float var1);

   Float getRateAdjustmentLifetimeCapPercent();

   void setRateAdjustmentLifetimeCapPercent(Float var1);

   Boolean getConversionOptionIndicator();

   void setConversionOptionIndicator(Boolean var1);
}
