package org.commerce.mismo.map.pdf1003;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.commerce.mismo.Address;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.Employer;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.PdfContext;
import org.commerce.mismo.util.StringUtil;

class MapEmployment extends MapCommon {

   private static final String PREVIOUS_ID_2 = "2";
   private static final String PREVIOUS_ID_3 = "3";


   void map(PdfContext context) {
      Borrower borrower = context.getCurrentBorrower();
      boolean isLeftSideBorrower = context.isLeftSideBorrower(borrower);
      if(isLeftSideBorrower) {
         Map d = context.getDestination();
         this.mapEmployment(borrower, d, "");
         if(context.isJointly()) {
            Borrower coBorrower = borrower.getJointAssetBorrower();
            if(coBorrower != null) {
               this.mapEmployment(coBorrower, d, "co");
            }
         }
      }

   }

   private void mapEmployment(Borrower borrower, Map d, String prefix) {
      Employer[] employerArray = borrower.getEmployers();
      ArrayList employers = new ArrayList();

      for(int currentEmployers = 0; currentEmployers < employerArray.length; ++currentEmployers) {
         Employer previousEmployers = employerArray[currentEmployers];
         if(previousEmployers.isCurrent()) {
            employers.add(0, previousEmployers);
         } else {
            employers.add(previousEmployers);
         }
      }

      if(employerArray != null) {
         List var8 = this.getEmployersForCurrentCondition(employers, true);
         List var9 = this.getEmployersForCurrentCondition(employers, false);
         this.mapCurrentEmployer(var8, prefix, d);
         this.mapPreviousEmployer(var8, var9, prefix, d, "2");
         this.mapPreviousEmployer(var8, var9, prefix, d, "3");
      }

   }

   private void mapCurrentEmployer(List currentEmployers, String prefix, Map d) {
      Employer employer = null;
      Iterator iter = currentEmployers.iterator();
      boolean havePrimaryCurrent = false;

      while(iter.hasNext()) {
         employer = (Employer)iter.next();
         if(employer.getEmploymentPrimaryIndicator()) {
            this.mapCurrent(employer, prefix, d);
            havePrimaryCurrent = true;
            break;
         }
      }

      if(havePrimaryCurrent) {
         currentEmployers.remove(employer);
      } else if(currentEmployers.size() > 0) {
         employer = (Employer)currentEmployers.get(0);
         this.mapCurrent(employer, prefix, d);
         currentEmployers.remove(employer);
      }

   }

   private void mapPreviousEmployer(List currentEmployers, List previousEmployers, String prefix, Map d, String previousEmploymentID) {
      Employer selectedEmployer = null;
      if(currentEmployers.size() > 0) {
         selectedEmployer = (Employer)currentEmployers.get(0);
         currentEmployers.remove(selectedEmployer);
      } else {
         if(previousEmployers.size() <= 0) {
            return;
         }

         selectedEmployer = (Employer)previousEmployers.get(0);
         previousEmployers.remove(selectedEmployer);
      }

      this.mapPrevious(selectedEmployer, prefix, d, previousEmploymentID);
   }

   private List getEmployersForCurrentCondition(List employers, boolean isCurrent) {
      ArrayList results = new ArrayList();

      while(employers.size() > 0) {
         Employer employer = (Employer)employers.get(0);
         if(employer.isCurrent() != isCurrent) {
            break;
         }

         results.add(employer);
         employers.remove(employer);
      }

      return results;
   }

   private void mapCurrent(Employer employer, String prefix, Map d) {
      Address address = employer.getAddress();
      String[][] pairs = new String[][]{{"employer1a", employer.getName()}, {"employer1b", address.getStreetAddress()}, {"employer1c", this.getCityStateZipCountry(address)}, {"former_years2", String.valueOf(employer.getYearsOnJob())}, {"years_work", String.valueOf(employer.getTimeInLineOfWork())}, {"selfemploy", this.mapCheckbox(employer.isSelfEmployed())}, {"income", this.emptyStringIfNull(employer.getMonthlyIncome())}, {"title", employer.getEmploymentPositionDescription()}, {"bphone", employer.getTelephoneNumber()}};
      this.mapArray(d, prefix + "borrower_", pairs);
   }

   private void mapArray(Map d, String prefix, String[][] pairs) {
      for(int i = 0; i < pairs.length; ++i) {
         d.put(prefix + pairs[i][0], pairs[i][1]);
      }

   }

   private String mapCheckbox(boolean isSet) {
      return isSet?"Yes":"";
   }

   private void mapPrevious(Employer employer, String prefix, Map d, String previousID) {
      Address address = employer.getAddress();
      String formattedEndDate = employer.isCurrent()?"curr":this.formatMMYYDate(employer.getPreviousEmploymentEndDate());
      String[][] pairs = new String[][]{{"a", employer.getName()}, {"b", address.getStreetAddress()}, {"c", this.getCityStateZipCountry(address)}, {"_self", this.mapCheckbox(employer.isSelfEmployed())}, {"_start_date", this.formatMMYYDate(employer.getPreviousEmploymentStartDate())}, {"_end_date", formattedEndDate}, {"_income", this.emptyStringIfNull(employer.getMonthlyIncome())}, {"_title", employer.getEmploymentPositionDescription()}, {"_bphone", StringUtil.formatPhone(employer.getTelephoneNumber())}};

      for(int i = 0; i < pairs.length; ++i) {
         d.put(prefix + "borrower_employ" + previousID + pairs[i][0], pairs[i][1]);
      }

   }
}
