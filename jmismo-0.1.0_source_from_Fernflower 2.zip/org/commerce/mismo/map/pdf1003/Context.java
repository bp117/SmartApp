package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.HousingExpenseType;
import org.commerce.mismo.PresentHousingExpense;
import org.commerce.mismo.ProposedHousingExpense;
import org.commerce.mismo.map.pdf1003.PdfContext;

class Context {

   private PdfContext context;
   private PresentHousingExpense[] presentExpenses;
   private ProposedHousingExpense[] proposedExpenses;
   private BigDecimal presentTotal = new BigDecimal(0.0D);
   private BigDecimal proposedTotal = new BigDecimal(0.0D);
   private HousingExpenseType type;
   private String keyComponent;
   private Borrower borrower;


   PresentHousingExpense[] getPresentExpenses() {
      return this.presentExpenses;
   }

   ProposedHousingExpense[] getProposedExpenses() {
      return this.proposedExpenses;
   }

   void setPresentExpenses(PresentHousingExpense[] expenses) {
      this.presentExpenses = expenses != null?expenses:new PresentHousingExpense[0];
   }

   void setProposedExpenses(ProposedHousingExpense[] expenses) {
      this.proposedExpenses = expenses;
   }

   Borrower getBorrower() {
      return this.borrower;
   }

   PdfContext getContext() {
      return this.context;
   }

   String getKeyComponent() {
      return this.keyComponent;
   }

   BigDecimal getPresentTotal() {
      return this.presentTotal;
   }

   BigDecimal getProposedTotal() {
      return this.proposedTotal;
   }

   HousingExpenseType getType() {
      return this.type;
   }

   void setBorrower(Borrower borrower) {
      this.borrower = borrower;
   }

   void setContext(PdfContext context) {
      this.context = context;
   }

   void setKeyComponent(String string) {
      this.keyComponent = string;
   }

   void setPresentTotal(BigDecimal decimal) {
      this.presentTotal = decimal;
   }

   void setProposedTotal(BigDecimal decimal) {
      this.proposedTotal = decimal;
   }

   void setType(HousingExpenseType type) {
      this.type = type;
   }
}
