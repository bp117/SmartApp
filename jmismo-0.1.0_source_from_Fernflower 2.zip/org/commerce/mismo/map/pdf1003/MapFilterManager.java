package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang.enums.Enum;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.Mismo;
import org.commerce.mismo.MultiBorrowerAssociatedEntity;
import org.commerce.mismo.util.EnumObject;

class MapFilterManager {

   private static Log log = LogFactory.getLog(class$org$commerce$mismo$map$pdf1003$MapFilterManager == null?(class$org$commerce$mismo$map$pdf1003$MapFilterManager = class$("org.commerce.mismo.map.pdf1003.MapFilterManager")):class$org$commerce$mismo$map$pdf1003$MapFilterManager);
   static final int FIRST_BORROWER = 1;
   static final int ASSOCIATED_BORROWER = 2;
   static final int NON_ASSOCIATED_BORROWER = 3;
   static Class class$org$commerce$mismo$map$pdf1003$MapFilterManager;


   static List filterObjectsFromArray(EnumObject[] array, Enum enumObject) {
      ArrayList results = new ArrayList();
      if(array != null) {
         for(int i = 0; i < array.length; ++i) {
            EnumObject object = array[i];
            if(log.isDebugEnabled()) {
               if(object == null && log.isDebugEnabled()) {
                  log.debug("Mismo object at offset " + i + " is null");
               }

               if(object.getType() == null) {
                  log.debug("Mismo object type " + object.getClass().getName() + "\'s type is null");
               }
            }

            Enum type = object.getType();
            if(enumObject.equals(type)) {
               results.add(object);
            }
         }
      }

      return results;
   }

   static List filterMultiBorrowerEntitiesForBorrower(List entities, Borrower currentBorrower) {
      ArrayList filtered = new ArrayList();
      Iterator iter = entities.iterator();

      while(iter.hasNext()) {
         MultiBorrowerAssociatedEntity entity = (MultiBorrowerAssociatedEntity)iter.next();
         int borrowerRelationship = getBorrowerRelationship(entity, currentBorrower);
         if(borrowerRelationship == 1) {
            filtered.add(entity);
         }
      }

      return filtered;
   }

   static int getBorrowerRelationship(MultiBorrowerAssociatedEntity entity, Borrower currentBorrower) {
      byte result = 3;
      Borrower[] borrowers = entity.getBorrowers();
      boolean isFirst = true;

      for(int i = 0; i < borrowers.length; ++i) {
         Borrower candidate = borrowers[i];
         if(candidate.equals(currentBorrower)) {
            if(isFirst) {
               result = 1;
            } else {
               result = 2;
            }
            break;
         }

         isFirst = false;
      }

      return result;
   }

   static BigDecimal getTotalForTypeFromArray(Mismo[] array, Enum enumObject) {
      return getTotalFromFilteredList(filterObjectsFromArray(array, enumObject));
   }

   static BigDecimal getTotalFromFilteredList(List filteredEnums) {
      BigDecimal total = new BigDecimal(0.0D);

      Mismo object;
      for(Iterator iter = filteredEnums.iterator(); iter.hasNext(); total = total.add(object.getAmount())) {
         object = (Mismo)iter.next();
      }

      return total;
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
