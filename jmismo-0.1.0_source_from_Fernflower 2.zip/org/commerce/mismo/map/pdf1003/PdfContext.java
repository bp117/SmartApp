package org.commerce.mismo.map.pdf1003;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.JointAssetLiabilityReportingType;
import org.commerce.mismo.LoanApplication;
import org.commerce.mismo.PrintPositionType;

public class PdfContext {

   private static Log log = LogFactory.getLog(class$org$commerce$mismo$map$pdf1003$PdfContext == null?(class$org$commerce$mismo$map$pdf1003$PdfContext = class$("org.commerce.mismo.map.pdf1003.PdfContext")):class$org$commerce$mismo$map$pdf1003$PdfContext);
   private Set borrowers = new HashSet();
   private LoanApplication source;
   private Map destination = new HashMap();
   private int currentBorrowerId;
   private boolean isJointly;
   static Class class$org$commerce$mismo$map$pdf1003$PdfContext;


   public PdfContext(LoanApplication source, int borrowerId) {
      this.setSource(source);
      this.setCurrentBorrowerId(borrowerId);
   }

   Set getBorrowers() {
      return this.borrowers;
   }

   Map getDestination() {
      return this.destination;
   }

   LoanApplication getSource() {
      return this.source;
   }

   void addBorrower(Borrower borrower) {
      this.borrowers.add(borrower);
   }

   void setDestination(Map map) {
      this.destination = map;
   }

   void setSource(LoanApplication application) {
      this.source = application;
      this.isJointly = this.determineJointly(application);
   }

   boolean determineJointly(LoanApplication application) {
      Borrower[] borrowers = application.getBorrowers();
      boolean result = false;
      if(log.isDebugEnabled()) {
         log.debug("testing jointly");
      }

      if(JointAssetLiabilityReportingType.JOINTLY.equals(borrowers[0].getJointAssetResidenceReportingType())) {
         if(log.isDebugEnabled()) {
            log.debug("this loan is definitely jointly");
         }

         result = true;
      }

      return result;
   }

   boolean determineJointly() {
      return this.determineJointly(this.source);
   }

   int getCurrentBorrowerId() {
      return this.currentBorrowerId;
   }

   void setCurrentBorrowerId(int i) {
      this.currentBorrowerId = i;
      if(log.isDebugEnabled()) {
         log.debug("setCurrentBorrowerId: " + i);
      }

   }

   boolean isJointly() {
      return this.isJointly;
   }

   boolean isBorrowerMigrated(Borrower borrower) {
      return this.borrowers.contains(borrower);
   }

   void resetMigratedBorrowers() {
      this.borrowers.clear();
   }

   void declareBorrowerMigrated(Borrower borrower) {
      this.borrowers.add(borrower);
   }

   Borrower getCurrentBorrower() {
      Borrower[] borrowers = this.source.getBorrowers();
      return borrowers[this.currentBorrowerId];
   }

   boolean isJointlyBorrower(Borrower borrower) {
      return this.isJointly() && PrintPositionType.BORROWER == borrower.getPrintPositionType();
   }

   boolean isJointlyCoBorrower(Borrower borrower) {
      return this.isJointly() && PrintPositionType.COBORROWER == borrower.getPrintPositionType();
   }

   boolean isLeftSideBorrower(Borrower borrower) {
      boolean isLeftSide = true;
      if(this.isJointly) {
         Borrower jointlyBorrower = borrower.getJointAssetBorrower();
         if(jointlyBorrower != null && this.isJointlyBorrower(jointlyBorrower)) {
            isLeftSide = false;
         }
      }

      return isLeftSide;
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
