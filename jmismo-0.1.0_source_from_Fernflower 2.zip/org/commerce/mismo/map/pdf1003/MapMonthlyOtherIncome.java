package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.CurrentIncome;
import org.commerce.mismo.IncomeType;
import org.commerce.mismo.map.pdf1003.MapFilterManager;
import org.commerce.mismo.map.pdf1003.MonthlyIncomeTotals;
import org.commerce.mismo.map.pdf1003.OutputFormatting;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapMonthlyOtherIncome extends OutputFormatting {

   private static final int OTHER_INCOME_ENTRY_MAX_COUNT = 3;
   private static final String BORROWER_ABBREV = "B";
   private static final String COBORROWER_ABBREV = "C";


   void map(PdfContext context, MonthlyIncomeTotals totals) {
      if(this.getLog().isDebugEnabled()) {
         this.getLog().debug("Begin section V other income mapping");
      }

      Borrower borrower = context.getCurrentBorrower();
      if(context.isLeftSideBorrower(borrower)) {
         this.map(context, borrower, totals);
      }

   }

   private void map(PdfContext context, Borrower borrower, MonthlyIncomeTotals totals) {
      Map d = context.getDestination();
      ArrayList otherIncomes = new ArrayList();
      this.addOtherIncomesForBorrowerToList(borrower, otherIncomes);
      if(context.determineJointly()) {
         this.addOtherIncomesForBorrowerToList(borrower.getJointAssetBorrower(), otherIncomes);
      }

      int maxRows = Math.min(3, otherIncomes.size());
      BigDecimal borrowerTotal = new BigDecimal(0.0D);
      BigDecimal coBorrowerTotal = new BigDecimal(0.0D);

      for(int i = 0; i < maxRows; ++i) {
         CurrentIncome income = (CurrentIncome)otherIncomes.get(i);
         IncomeType currentIncomeType = income.getIncomeType();
         int rowIndex = i + 1;
         boolean isBorrower = context.isLeftSideBorrower(borrower);
         BigDecimal amount = income.getAmount();
         if(isBorrower) {
            borrowerTotal = borrowerTotal.add(amount);
         } else {
            coBorrowerTotal = coBorrowerTotal.add(amount);
         }

         d.put("other_income_bc" + rowIndex, this.getBorrowerOrCoBorrowerAbbrev(context));
         d.put("other_income_desc" + rowIndex, currentIncomeType.getFormattedName());
         d.put("other_income_amt" + rowIndex, this.emptyStringIfNull(amount));
      }

      this.mapMonthlyIncomeOther2(d, borrowerTotal, coBorrowerTotal);
      totals.addToBorrowerTotal(borrowerTotal);
      totals.addToCoBorrowerTotal(coBorrowerTotal);
   }

   private void addOtherIncomesForBorrowerToList(Borrower borrower, List otherIncomes) {
      if(borrower != null) {
         for(int i = 0; i < IncomeType.OTHER_INCOME_TYPES.length; ++i) {
            CurrentIncome[] currentIncomes = borrower.getCurrentIncomes();
            if(currentIncomes != null) {
               otherIncomes.addAll(MapFilterManager.filterObjectsFromArray(currentIncomes, IncomeType.OTHER_INCOME_TYPES[i]));
            }
         }
      }

   }

   private String getBorrowerOrCoBorrowerAbbrev(PdfContext context) {
      return context.isJointlyBorrower(context.getCurrentBorrower())?"B":"C";
   }

   private void mapMonthlyIncomeOther2(Map d, BigDecimal borrowerTotal, BigDecimal coBorrowerTotal) {
      d.put("borrower_other_income2", this.emptyStringIfNull(borrowerTotal));
      d.put("coborrower_other_income2", this.emptyStringIfNull(coBorrowerTotal));
      BigDecimal combinedTotal = new BigDecimal(0.0D);
      combinedTotal = combinedTotal.add(borrowerTotal);
      combinedTotal = combinedTotal.add(coBorrowerTotal);
      d.put("total_other_income2", this.emptyStringIfNull(combinedTotal));
   }
}
