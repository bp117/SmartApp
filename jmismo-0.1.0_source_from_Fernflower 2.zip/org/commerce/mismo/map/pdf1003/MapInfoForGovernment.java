package org.commerce.mismo.map.pdf1003;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.GenderType;
import org.commerce.mismo.GovernmentMonitoring;
import org.commerce.mismo.HMDAEthnicityType;
import org.commerce.mismo.HMDARace;
import org.commerce.mismo.HMDARaceType;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapInfoForGovernment extends MapCommon {

   private static final String[][] BORROWER_RACE_KEYS = new String[][]{{HMDARaceType.AMERICAN_INDIAN_OR_ALASKAN_NATIVE.getName(), "b_hmda_indian"}, {HMDARaceType.ASIAN.getName(), "b_hmda_asian"}, {HMDARaceType.BLACK_OR_AFRICAN_AMERICAN.getName(), "b_hmda_black"}, {HMDARaceType.NATIVE_HAWAIIAN_OR_OTHER_PACIFIC_ISLANDER.getName(), "b_hmda_hawaiian"}, {HMDARaceType.WHITE.getName(), "b_hmda_white"}};


   void map(PdfContext context) {
      Borrower borrower = context.getCurrentBorrower();
      if(context.isLeftSideBorrower(borrower)) {
         GovernmentMonitoring gvmt = borrower.getGovernmentMonitoring();
         this.mapBorrower(context, gvmt, "");
         Map d = context.getDestination();
         d.put("b_app_by_internet", "Yes");
         if(context.isJointly()) {
            Borrower coborrower = borrower.getJointAssetBorrower();
            if(coborrower != null) {
               GovernmentMonitoring gvmt2 = coborrower.getGovernmentMonitoring();
               this.mapBorrower(context, gvmt2, "co");
            }
         }
      }

   }

   private void mapBorrower(PdfContext context, GovernmentMonitoring gvmt, String prefix) {
      if(!this.mapNoWishToFurnish(context, gvmt, prefix)) {
         this.mapGender(context, gvmt, prefix, "b_hmda_female", "b_hmda_male");
         this.mapEthnicity(context, gvmt, prefix, "b_hmda_hispanic", "b_hmda_not_hispanic");
         this.mapRace(context, gvmt, prefix);
      }

   }

   private boolean mapNoWishToFurnish(PdfContext context, GovernmentMonitoring gvmt, String prefix) {
      boolean noWishToFurnish = gvmt.getRaceNationalOriginRefusalIndicator().booleanValue();
      if(noWishToFurnish) {
         Map d = context.getDestination();
         d.put(prefix + "b_hmda_not_furnish", "Yes");
      }

      return noWishToFurnish;
   }

   private void mapGender(PdfContext context, GovernmentMonitoring gvmt, String prefix, String femaleKey, String maleKey) {
      GenderType gender = gvmt.getGenderType();
      Map d = context.getDestination();
      if(gender.equals(GenderType.FEMALE)) {
         d.put(prefix + femaleKey, "Yes");
      } else if(gender.equals(GenderType.MALE)) {
         d.put(prefix + maleKey, "Yes");
      }

   }

   private void mapEthnicity(PdfContext context, GovernmentMonitoring gvmt, String prefix, String hispanicKey, String notHispanicKey) {
      HMDAEthnicityType ethnicity = gvmt.getEthnicityType();
      Map d = context.getDestination();
      if(ethnicity != null) {
         if(ethnicity.equals(HMDAEthnicityType.HISPANIC_OR_LATINO)) {
            d.put(prefix + hispanicKey, "Yes");
         } else if(ethnicity.equals(HMDAEthnicityType.NOT_HISPANIC_OR_LATINO)) {
            d.put(prefix + notHispanicKey, "Yes");
         }
      }

   }

   private void mapRace(PdfContext context, GovernmentMonitoring gvmt, String prefix) {
      Map d = context.getDestination();
      List races = gvmt.getHMDARaces();
      Iterator iter = races.iterator();

      while(iter.hasNext()) {
         HMDARace mismoRace = (HMDARace)iter.next();
         HMDARaceType mismoRaceType = mismoRace.getType();
         String mismoRaceName = mismoRaceType.getName();

         for(int i = 0; i < BORROWER_RACE_KEYS.length; ++i) {
            String thisRaceName = BORROWER_RACE_KEYS[i][0];
            if(thisRaceName.equals(mismoRaceName)) {
               d.put(prefix + BORROWER_RACE_KEYS[i][1], "Yes");
               break;
            }
         }
      }

   }

}
