package org.commerce.mismo.map.pdf1003;

import java.util.Date;
import java.util.Map;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.MailTo;
import org.commerce.mismo.Residence;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.PdfContext;
import org.commerce.mismo.util.StringUtil;

class MapBorrower extends MapCommon {

   void map(PdfContext context) {
      Map d = context.getDestination();
      Borrower borrower = context.getCurrentBorrower();
      if(context.isLeftSideBorrower(borrower)) {
         this.mapBorrower("", context.getCurrentBorrower(), d);
         if(context.isJointly()) {
            Borrower coBorrower = borrower.getJointAssetBorrower();
            if(coBorrower != null) {
               this.mapBorrower("co", borrower.getJointAssetBorrower(), d);
            }
         }
      }

   }

   private void mapBorrower(String p, Borrower b, Map d) {
      Object date = null;
      d.put(p + "borrower_name", b.getUnparsedName());
      d.put(p + "borrower_ssn", b.getSSN());
      this.mapPhone(d, p + "borrower_hphone", b.getHomePhoneNumber());
      d.put(p + "borrower_dob", StringUtil.formatDate(b.getBirthDate()));
      d.put(p + "borrower_yrs_school", b.getSchoolingYears() != null?b.getSchoolingYears().toString():" ");
      if(b.getMaritalStatus() != null) {
         if("Married".equals(b.getMaritalStatus().getName())) {
            d.put(p + "borrower_married", "Yes");
         } else if("Unmarried".equals(b.getMaritalStatus().getName())) {
            d.put(p + "borrower_unmarried", "Yes");
         } else if("Separated".equals(b.getMaritalStatus().getName())) {
            d.put(p + "borrower_separated", "Yes");
         }
      }

      d.put(p + "borrower_no_depend", String.valueOf(b.getDependentCount()));
      String ageStr = "";

      for(int residenceArray = 0; b.getDependents() != null && residenceArray < b.getDependents().length && residenceArray < b.getDependentCount(); ++residenceArray) {
         if(residenceArray > 0) {
            ageStr = ageStr + ",";
         }

         ageStr = ageStr + b.getDependents()[residenceArray].getAgeYears();
      }

      d.put("borrower_age_depend", ageStr);
      Residence[] var11 = b.getResidences();
      if(var11 != null) {
         int residencyYears;
         Residence residence;
         if(var11.length > 0 && var11[0] != null) {
            residence = var11[0];
            d.put(p + "borrower_addressa", residence.getAddress().getStreetAddress());
            d.put(p + "borrower_addressb", this.getCityStateZipCountry(residence.getAddress()));
            if("Own".equals(residence.getResidencyBasisType().getName())) {
               d.put(p + "borrower_own", "Yes");
            } else if("Rent".equals(residence.getResidencyBasisType().getName())) {
               d.put(p + "borrower_rent", "Yes");
            }

            residencyYears = residence.getBorrowerResidencyDurationYears();
            d.put(p + "b_yrs_at_address", String.valueOf(residencyYears));
            MailTo mailingAddress = b.getMailTo();
            Boolean isSameAddress = mailingAddress.getIsSameAddress();
            if(isSameAddress != null && !isSameAddress.booleanValue()) {
               d.put(p + "borrower_mailing_addressa", mailingAddress.getStreetAddress1());
               d.put(p + "borrower_mailing_addressb", mailingAddress.getStreetAddress2());
               d.put(p + "borrower_mailing_addressc", this.getCityStateZipCountry(mailingAddress.getCity(), mailingAddress.getState(), mailingAddress.getPostalCode(), mailingAddress.getCountry()));
            }
         }

         if(var11.length > 1 && var11[1] != null) {
            residence = var11[1];
            d.put(p + "borrower_former_address1a", residence.getAddress().getStreetAddress());
            d.put(p + "borrower_former_address1b", this.getCityStateZipCountry(residence.getAddress()));
            d.put(p + "borrower_former_add_to", StringUtil.formatDate((Date)date));
            residencyYears = residence.getBorrowerResidencyDurationYears();
            d.put(p + "borrower_former_years1", String.valueOf(residencyYears));
         }
      }

   }
}
