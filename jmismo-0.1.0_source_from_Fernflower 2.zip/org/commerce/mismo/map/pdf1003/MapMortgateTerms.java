package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;
import java.util.Map;
import org.commerce.mismo.LoanAmortizationType;
import org.commerce.mismo.LoanApplication;
import org.commerce.mismo.MortgageTerms;
import org.commerce.mismo.MortgageType;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapMortgateTerms extends MapCommon {

   void map(PdfContext context) {
      Map d = context.getDestination();
      LoanApplication app = context.getSource();
      MortgageTerms terms = app.getMortgageTerms();
      MortgageType type = terms.getMortgageType();
      this.mapLoanAppliedFor(type, d);
      d.put("loan_number", terms.getAgencyCaseIdentifier());
      this.mapLoanAmount(terms, d);
      d.put("interest_rate", this.formattedInPercent(terms.getRequestedInterestRatePercent()));
      d.put("no_of_months", new Integer(terms.getLoanAmortizationTermMonths()));
      this.mapAmortizationType(terms.getLoanAmortizationType(), d);
   }

   private void mapLoanAppliedFor(MortgageType type, Map d) {
      if(MortgageType.VA == type) {
         d.put("loan_applied_for_va", "Yes");
      } else if(MortgageType.FHA == type) {
         d.put("loan_applied_for_fha", "Yes");
      } else if(MortgageType.CONVENTIONAL == type) {
         d.put("loan_applied_for_conv", "Yes");
      } else if(MortgageType.OTHER == type) {
         d.put("loan_applied_for_other", "Yes");
      }

   }

   private void mapLoanAmount(MortgageTerms terms, Map d) {
      BigDecimal borrowerRequested = terms.getBorrowerRequestedLoanAmount();
      BigDecimal result = null;
      if(borrowerRequested != null) {
         result = borrowerRequested;
      } else {
         BigDecimal baseLoanAmount = terms.getBaseLoanAmount();
         if(baseLoanAmount != null) {
            result = baseLoanAmount;
         }
      }

      if(result != null) {
         d.put("loan_amount", this.emptyStringIfNull(result));
      }

   }

   private void mapAmortizationType(LoanAmortizationType type, Map d) {
      if(LoanAmortizationType.FIXED == type) {
         d.put("amort_type_fixed_rate", "Yes");
      } else if(LoanAmortizationType.GRADUATED_PAYMENT_MORTGAGE == type) {
         d.put("amort_type_gpm", "Yes");
      } else if(LoanAmortizationType.OTHER_AMORTIZATION_TYPE == type) {
         d.put("amort_type_other", "Yes");
      } else if(LoanAmortizationType.ADJUSTABLE_RATE == type) {
         d.put("amort_type_arm", "Yes");
      }

   }
}
