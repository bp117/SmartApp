package org.commerce.mismo.map.pdf1003;

import java.util.Map;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.CitizenshipResidencyType;
import org.commerce.mismo.Declaration;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapDeclarations extends MapCommon {

   private String[][] declarationKeys = new String[][]{{"b_deca_yes", "b_deca_no"}, {"b_decb_yes", "b_decb_no"}, {"b_decc_yes", "b_decc_no"}, {"b_decd_yes", "b_decd_no"}, {"b_dece_yes", "b_dece_no"}, {"b_decf_yes", "b_decf_no"}, {"b_decg_yes", "b_decg_no"}, {"b_dech_yes", "b_dech_no"}, {"b_deci_yes", "b_deci_no"}, {"b_decj_yes", "b_decj_no"}, {"b_deck_yes", "b_deck_no"}, {"b_decl_yes", "b_decl_no"}, {"b_decl1_yes", "b_decl1_no"}, {"b_decm_yes", "b_decm_no"}, {"b_decm1", "b_decm1"}, {"b_decm2", "b_decm2"}};
   private String[][] declarationKeysCoBorrower = new String[][]{{"cb_deca_yes", "cb_deca_no"}, {"cb_decb_yes", "cb_decb_no"}, {"cb_decc_yes", "cb_decc_no"}, {"cb_decd_yes", "cb_decd_no"}, {"cb_dece_yes", "cb_dece_no"}, {"cb_decf_yes", "cb_decf_no"}, {"cb_decg_yes", "cb_decg_no"}, {"cb_dech_yes", "cb_dech_no"}, {"cb_deci_yes", "cb_deci_no"}, {"cb_decj_yes", "cb_decj_no"}, {"cb_deck_yes", "cb_deck_no"}, {"cb_decl_yes", "cb_decl_no"}, {"cb_decl1_yes", "cb_decl1_no"}, {"cb_decm_yes", "cb_decm_no"}, {"cb_decm1", "cb_decm1"}, {"cb_decm2", "cb_decm2"}};


   void map(PdfContext context) {
      Map d = context.getDestination();
      Borrower borrower = context.getCurrentBorrower();
      Declaration declaration = borrower.getDeclarations();
      if(context.isLeftSideBorrower(borrower)) {
         this.mapBorrowerDeclaration(d, declaration, false);
         if(context.isJointly()) {
            Borrower coborrower = borrower.getJointAssetBorrower();
            if(coborrower != null) {
               Declaration declarationCoBorrower = coborrower.getDeclarations();
               this.mapBorrowerDeclaration(d, declarationCoBorrower, true);
            }
         }
      }

   }

   private void mapBorrowerDeclaration(Map valMap, Declaration declaration, boolean coBorrower) {
      String[][] keys = !coBorrower?this.declarationKeys:this.declarationKeysCoBorrower;
      this.mapBooleanDeclaration(declaration.isOutstandingJudgements().booleanValue(), valMap, keys[0][0], keys[0][1]);
      this.mapBooleanDeclaration(declaration.isBankruptcy().booleanValue(), valMap, keys[1][0], keys[1][1]);
      this.mapBooleanDeclaration(declaration.isPropertyForeclosedPastSevenYears().booleanValue(), valMap, keys[2][0], keys[2][1]);
      this.mapBooleanDeclaration(declaration.isPartyToLawsuit().booleanValue(), valMap, keys[3][0], keys[3][1]);
      this.mapBooleanDeclaration(declaration.isLoanForeclosureOrJudgement().booleanValue(), valMap, keys[4][0], keys[4][1]);
      this.mapBooleanDeclaration(declaration.isPresentlyDelinquent().booleanValue(), valMap, keys[5][0], keys[5][1]);
      this.mapBooleanDeclaration(declaration.isAlimonyChildSupportObligation().booleanValue(), valMap, keys[6][0], keys[6][1]);
      this.mapBooleanDeclaration(declaration.isBorrowedDownPayment().booleanValue(), valMap, keys[7][0], keys[7][1]);
      this.mapBooleanDeclaration(declaration.isCoMakerEndorserOfNote().booleanValue(), valMap, keys[8][0], keys[8][1]);
      boolean t = declaration.getCitizenshipResidencyType().equals(CitizenshipResidencyType.US_CITIZEN);
      this.mapBooleanDeclaration(t, valMap, keys[9][0], keys[9][1]);
      boolean u = declaration.getCitizenshipResidencyType().equals(CitizenshipResidencyType.PERMANENT_RESIDENT_ALIEN);
      this.mapBooleanDeclaration(u, valMap, keys[10][0], keys[10][1]);
      this.mapBooleanDeclaration(declaration.isIntentToOccupyType().booleanValue(), valMap, keys[11][0], keys[11][1]);
      if(declaration.isIntentToOccupyType().booleanValue()) {
         this.mapBooleanDeclaration(declaration.getPriorPropertyUsageType() != null, valMap, keys[13][0], keys[13][1]);
         if(declaration.getPriorPropertyUsageType() != null) {
            valMap.put(keys[14][0], this.formatEnum(declaration.getPriorPropertyUsageType()));
            valMap.put(keys[15][0], this.formatEnum(declaration.getPriorPropertyTitleType()));
         }
      }

   }
}
