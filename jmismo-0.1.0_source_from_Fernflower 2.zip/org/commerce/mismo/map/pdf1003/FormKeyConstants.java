package org.commerce.mismo.map.pdf1003;


public interface FormKeyConstants {

   String BORROWER_PREFIX = "";
   String COBORROWER_PREFIX = "co";
   String YEARS_AT_ADDRESS = "b_yrs_at_address";
   String YEARS_AT_LINE_OF_WORK = "borrower_years_work";
   String APPLIED_BY_INTERNET = "b_app_by_internet";
   String HMDA_NO_WISH_TO_FURNISH = "b_hmda_not_furnish";
   String HMDA_ETHNICITY_HISPANIC = "b_hmda_hispanic";
   String HMDA_ETHNICITY_NOT_HISPANIC = "b_hmda_not_hispanic";
   String HMDA_ASIAN = "b_hmda_asian";
   String HMDA_BLACK = "b_hmda_black";
   String HMDA_FEMALE = "b_hmda_female";
   String HMDA_HAWAIIAN = "b_hmda_hawaiian";
   String HMDA_INDIAN = "b_hmda_indian";
   String HMDA_MALE = "b_hmda_male";
   String HMDA_WHITE = "b_hmda_white";
   String MAILTO_ADDRESSA = "borrower_mailing_addressa";
   String MAILTO_ADDRESSB = "borrower_mailing_addressb";
   String MAILTO_ADDRESSC = "borrower_mailing_addressc";
   String MAILTO_ADDRESSD = "borrower_mailing_addressd";

}
