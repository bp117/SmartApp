package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;
import org.apache.commons.lang.enums.Enum;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.JointAssetLiabilityReportingType;
import org.commerce.mismo.map.pdf1003.MapAssets;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.MapLiablities;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapAssetsAndLiabilities extends MapCommon {

   static final String REO_MKT_VALUE_TOTAL_KEY = "reo_mkt_value_total";


   void map(PdfContext context) {
      this.mapJointly(context);
      BigDecimal unpaidLiabilities = (new MapLiablities()).renderLiabilities(context);
      BigDecimal totalAssets = (new MapAssets()).renderAssets(context);
      context.getDestination().put("net_worth", totalAssets.subtract(unpaidLiabilities));
   }

   String formatNameType(String name, Enum e) {
      String t = "";
      if(name != null) {
         t = t + name;
      }

      if(e != null) {
         t = t + " (" + e.getName() + ")";
      }

      return t;
   }

   private void mapJointly(PdfContext context) {
      Borrower borrower = context.getCurrentBorrower();
      JointAssetLiabilityReportingType jointAssetType = borrower.getJointAssetResidenceReportingType();
      this.mapBooleanDeclaration(JointAssetLiabilityReportingType.JOINTLY.equals(jointAssetType), context.getDestination(), "completed_jointly", "completed_not_jointly");
   }
}
