package org.commerce.mismo.map.pdf1003;

import java.util.Map;
import org.commerce.mismo.LoanApplication;
import org.commerce.mismo.TransactionDetail;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapTransactionDetails extends MapCommon {

   void map(PdfContext context) {
      Map d = context.getDestination();
      LoanApplication app = context.getSource();
      TransactionDetail trans = app.getTransactionDetail();
      d.put("purchase_price", this.emptyStringIfNull(trans.getPurchasePriceAmount()));
      d.put("refinance", this.emptyStringIfNull(trans.getRefinanceIncludingDebtsToBePaidOffAmount()));
      d.put("est_closing_costs", this.emptyStringIfNull(trans.getEstimatedClosingCostsAmount()));
   }
}
