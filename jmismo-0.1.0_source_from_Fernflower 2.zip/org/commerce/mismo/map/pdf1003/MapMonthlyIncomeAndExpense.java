package org.commerce.mismo.map.pdf1003;

import org.commerce.mismo.Borrower;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.MapMonthlyExpense;
import org.commerce.mismo.map.pdf1003.MapMonthlyIncome;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapMonthlyIncomeAndExpense extends MapCommon {

   void map(PdfContext context) {
      Borrower borrower = context.getCurrentBorrower();
      if(context.isLeftSideBorrower(borrower)) {
         (new MapMonthlyIncome()).map(context);
         (new MapMonthlyExpense()).map(context);
      }

   }
}
