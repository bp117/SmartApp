package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.CurrentIncome;
import org.commerce.mismo.IncomeType;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.MapFilterManager;
import org.commerce.mismo.map.pdf1003.MapMonthlyOtherIncome;
import org.commerce.mismo.map.pdf1003.MonthlyIncomeTotals;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapMonthlyIncome extends MapCommon {

   void map(PdfContext context) {
      Borrower borrower = context.getCurrentBorrower();
      if(context.isLeftSideBorrower(borrower)) {
         this.map(context, borrower);
      }

   }

   private void map(PdfContext context, Borrower borrower) {
      MonthlyIncomeTotals totals = new MonthlyIncomeTotals();
      this.mapIncomeRow(totals, context, borrower, IncomeType.BASE, "base_income");
      this.mapIncomeRow(totals, context, borrower, IncomeType.OVERTIME, "overtime");
      this.mapIncomeRow(totals, context, borrower, IncomeType.BONUS, "bonus");
      this.mapIncomeRow(totals, context, borrower, IncomeType.COMMISSIONS, "commissions");
      this.mapIncomeRow(totals, context, borrower, IncomeType.DIVIDENDS_INTEREST, "dividends");
      this.mapIncomeRow(totals, context, borrower, IncomeType.NET_RENTAL_INCOME, "net_rental");
      this.mapIncomeRow(totals, context, borrower, IncomeType.OTHER_TYPES_OF_INCOME, "other_income");
      (new MapMonthlyOtherIncome()).map(context, totals);
      Map d = context.getDestination();
      d.put("borrower_total_income", this.emptyStringIfNull(totals.getBorrowerTotal()));
      d.put("coborrower_total_income", this.emptyStringIfNull(totals.getCoBorrowerTotal()));
      d.put("combined_total_income", this.emptyStringIfNull(totals.getBorrowerTotal().add(totals.getCoBorrowerTotal())));
   }

   private void mapIncomeRow(MonthlyIncomeTotals totals, PdfContext context, Borrower borrower, IncomeType incomeType, String key) {
      String borrowerKey = "borrower_" + key;
      String coBorrowerKey = "coborrower_" + key;
      String totalKey = "total_" + key;
      Map d = context.getDestination();
      CurrentIncome[] borrowerIncomes = borrower.getCurrentIncomes();
      if(this.getLog().isDebugEnabled()) {
         boolean borrowerTotal = borrowerIncomes == null;
         this.getLog().debug("getLog().Income(): borrowerIncomes is null: " + borrowerTotal);
         if(!borrowerTotal) {
            this.getLog().debug("getLog().Income(): borrowerIncomes size is " + borrowerIncomes.length);

            for(int coBorrowerTotal = 0; coBorrowerTotal < borrowerIncomes.length; ++coBorrowerTotal) {
               CurrentIncome coBorrower = borrowerIncomes[coBorrowerTotal];
               this.getLog().debug("getLog().Income(): borrowerIncome[" + coBorrowerTotal + "] amount is " + this.emptyStringIfNull(coBorrower.getMonthlyTotalAmount()));
            }
         }
      }

      BigDecimal var15 = this.mapFilteredIncomes(borrowerIncomes, incomeType, borrowerKey, d);
      BigDecimal var16 = new BigDecimal(0.0D);
      if(context.isJointly()) {
         Borrower var17 = borrower.getJointAssetBorrower();
         if(var17 != null) {
            CurrentIncome[] coBorrowerIncomes = var17.getCurrentIncomes();
            var16 = this.mapFilteredIncomes(coBorrowerIncomes, incomeType, coBorrowerKey, d);
         }
      }

      context.getDestination().put(totalKey, this.emptyStringIfNull(var15.add(var16)));
      totals.setBorrowerTotal(totals.getBorrowerTotal().add(var15));
      totals.setCoBorrowerTotal(totals.getCoBorrowerTotal().add(var16));
   }

   private BigDecimal mapFilteredIncomes(CurrentIncome[] incomes, IncomeType incomeType, String key, Map d) {
      BigDecimal total = new BigDecimal(0.0D);
      if(incomes != null) {
         if(this.getLog().isDebugEnabled()) {
            this.getLog().debug("getLog().FilteredIncomes: incomes class: " + incomes.getClass().getName());
            this.getLog().debug("getLog().FilteredIncomes: incomeType class: " + incomeType.getClass().getName());
         }

         List filteredIncomes = MapFilterManager.filterObjectsFromArray(incomes, incomeType);
         if(this.getLog().isDebugEnabled()) {
            this.getLog().debug("getLog().FilteredIncomes(): key is \'" + key + '\'');
            this.getLog().debug("getLog().FilteredIncomes(): filteredIncomes size is " + filteredIncomes.size());
            this.getLog().debug("getLog().FilteredIncomes(): type is " + incomeType.getFormattedName());
         }

         CurrentIncome income;
         for(Iterator iter = filteredIncomes.iterator(); iter.hasNext(); total = total.add(income.getMonthlyTotalAmount())) {
            income = (CurrentIncome)iter.next();
            if(this.getLog().isDebugEnabled()) {
               this.getLog().debug("getLog().FilteredIncomes(): amount is " + this.emptyStringIfNull(income.getMonthlyTotalAmount()));
            }
         }

         d.put(key, this.emptyStringIfNull(total));
      }

      return total;
   }
}
