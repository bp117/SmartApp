package org.commerce.mismo.map.pdf1003;

import java.util.Map;
import org.commerce.mismo.map.pdf1003.MapAssetsAndLiabilities;
import org.commerce.mismo.map.pdf1003.MapBorrower;
import org.commerce.mismo.map.pdf1003.MapDeclarations;
import org.commerce.mismo.map.pdf1003.MapEmployment;
import org.commerce.mismo.map.pdf1003.MapInfoForGovernment;
import org.commerce.mismo.map.pdf1003.MapMonthlyIncomeAndExpense;
import org.commerce.mismo.map.pdf1003.MapMortgateTerms;
import org.commerce.mismo.map.pdf1003.MapProperty;
import org.commerce.mismo.map.pdf1003.MapTransactionDetails;
import org.commerce.mismo.map.pdf1003.PdfContext;

public class Mapper1003 {

   public Map map(PdfContext context) {
      (new MapMortgateTerms()).map(context);
      (new MapProperty()).map(context);
      (new MapBorrower()).map(context);
      (new MapEmployment()).map(context);
      (new MapMonthlyIncomeAndExpense()).map(context);
      (new MapAssetsAndLiabilities()).map(context);
      (new MapTransactionDetails()).map(context);
      (new MapDeclarations()).map(context);
      (new MapInfoForGovernment()).map(context);
      return context.getDestination();
   }
}
