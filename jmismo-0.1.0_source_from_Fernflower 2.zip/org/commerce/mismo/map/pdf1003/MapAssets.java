package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.commerce.mismo.Asset;
import org.commerce.mismo.AssetType;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.DownPaymentType;
import org.commerce.mismo.map.pdf1003.MapAssetsAndLiabilities;
import org.commerce.mismo.map.pdf1003.MapFilterManager;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapAssets extends MapAssetsAndLiabilities {

   private static final int MAX_CHECKING_AND_SAVINGS_ENTRIES_COUNT = 4;


   BigDecimal renderAssets(PdfContext context) {
      Map d = context.getDestination();
      BigDecimal total = new BigDecimal(0.0D);
      total = total.add(this.mapCashDeposit(context));
      total = total.add(this.mapCheckingAndSavingsAccounts(context));
      total = total.add(this.mapLifeInsurance(context));
      d.put("subtotal_liquid_assets", this.emptyStringIfNull(total));
      total = total.add(this.mapTotalRealEstateOwned(context));
      total = total.add(this.mapVestedRetirement(context));
      total = total.add(this.mapOtherAssetsValue(context));
      total = total.add(this.mapAutosValue(context));
      d.put("total_assets_value", this.emptyStringIfNull(total));
      return total;
   }

   private BigDecimal mapCashDeposit(PdfContext context) {
      BigDecimal totalCashDeposit = MapFilterManager.getTotalForTypeFromArray(context.getSource().getDownPayments(), DownPaymentType.DEPOSIT_ON_SALES_CONTRACT);
      context.getDestination().put("cash_deposit_value", this.emptyStringIfNull(totalCashDeposit));
      return totalCashDeposit;
   }

   private BigDecimal mapCheckingAndSavingsAccounts(PdfContext context) {
      AssetType[] assetTypes = new AssetType[]{AssetType.CHECKING_ACCOUNT, AssetType.SAVINGS_ACCOUNT};
      return this.mapAssetsForTypes(context, "account", assetTypes, 4);
   }

   private BigDecimal mapLifeInsurance(PdfContext context) {
      return new BigDecimal(0.0D);
   }

   private BigDecimal mapTotalRealEstateOwned(PdfContext context) {
      Map d = context.getDestination();
      BigDecimal totalReoValue = (BigDecimal)d.get("reo_mkt_value_total");
      d.put("real_estate_owned", this.emptyStringIfNull(totalReoValue));
      return totalReoValue;
   }

   private BigDecimal mapVestedRetirement(PdfContext context) {
      Map d = context.getDestination();
      BigDecimal totalRetirement = this.getTotalForAssetTypeAndBorrower(context, AssetType.RETIREMENT_FUND);
      d.put("vested_retirement", totalRetirement);
      return totalRetirement;
   }

   private List getAssetsForBorrowerAndType(PdfContext context, AssetType type) {
      ArrayList filtered = new ArrayList();
      Borrower currentBorrower = context.getCurrentBorrower();
      Asset[] assets = context.getSource().getAssets();

      for(int i = 0; i < assets.length; ++i) {
         Asset asset = assets[i];
         if(type.equals(asset.getAssetType())) {
            int borrowerRelationship = MapFilterManager.getBorrowerRelationship(asset, currentBorrower);
            if(1 == borrowerRelationship) {
               filtered.add(asset);
            }
         }
      }

      return filtered;
   }

   private BigDecimal getTotalForAssetList(List assetList) {
      BigDecimal total = new BigDecimal(0.0D);
      return total;
   }

   private BigDecimal getTotalForAssetTypeAndBorrower(PdfContext context, AssetType assetType) {
      return this.getTotalForAssetList(this.getAssetsForBorrowerAndType(context, assetType));
   }

   private BigDecimal mapOtherAssetsValue(PdfContext context) {
      Map d = context.getDestination();
      BigDecimal totalLiquidAssets = this.getTotalForAssetTypeAndBorrower(context, AssetType.OTHER_LIQUID_ASSETS);
      BigDecimal totalNonLiquidAssets = this.getTotalForAssetTypeAndBorrower(context, AssetType.OTHER_NON_LIQUID_ASSETS);
      BigDecimal totalBoth = totalLiquidAssets.add(totalNonLiquidAssets);
      d.put("other_assets_value", totalBoth);
      return totalBoth;
   }

   private BigDecimal mapAutosValue(PdfContext context) {
      BigDecimal total = this.getTotalForAssetTypeAndBorrower(context, AssetType.AUTOMOBILE);
      Map d = context.getDestination();
      d.put("auto_value", total);
      return total;
   }

   private BigDecimal mapAssetsForTypes(PdfContext context, String keyComponent, AssetType[] assetTypes, int maxEntriesCount) {
      Map d = context.getDestination();
      BigDecimal total = new BigDecimal(0.0D);
      List assetsForTypes = this.getAssetsForTypes(context, assetTypes);
      int maxLoopCount = Math.min(maxEntriesCount, assetsForTypes.size());
      int outputRowCount = 1;
      Iterator iter = assetsForTypes.iterator();

      while(iter.hasNext()) {
         BigDecimal amount = new BigDecimal(0.0D);
         boolean isMapRow = true;
         boolean isMapAmount = false;
         Asset asset = (Asset)iter.next();
         int borrowerRelationship = MapFilterManager.getBorrowerRelationship(asset, context.getCurrentBorrower());
         switch(borrowerRelationship) {
         case 1:
            amount = asset.getCashOrMarketValueAmount();
            isMapAmount = true;
         case 2:
         default:
            break;
         case 3:
            isMapRow = false;
         }

         if(isMapRow) {
            String prefix = keyComponent + outputRowCount;
            d.put(prefix, asset.getAccountIdentifier());
            if(isMapAmount) {
               d.put(prefix + "_value", this.emptyStringIfNull(amount));
               total = total.add(amount);
            }

            if(outputRowCount++ >= maxLoopCount) {
               break;
            }
         }
      }

      return total;
   }

   private List getAssetsForTypes(PdfContext context, AssetType[] assetTypes) {
      Asset[] allAssets = context.getSource().getAssets();
      ArrayList assetsForType = new ArrayList();

      for(int i = 0; i < assetTypes.length; ++i) {
         assetsForType.addAll(MapFilterManager.filterObjectsFromArray(allAssets, assetTypes[i]));
      }

      return assetsForType;
   }
}
