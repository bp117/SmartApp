package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.commerce.mismo.Address;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.ConstructionRefinanceData;
import org.commerce.mismo.DownPayment;
import org.commerce.mismo.GSERefinancePurposeType;
import org.commerce.mismo.Liability;
import org.commerce.mismo.LoanApplication;
import org.commerce.mismo.LoanPurpose;
import org.commerce.mismo.LoanPurposeType;
import org.commerce.mismo.Property;
import org.commerce.mismo.PropertyRightsType;
import org.commerce.mismo.PropertyUsageType;
import org.commerce.mismo.RefinanceCashOutPurposeType;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapProperty extends MapCommon {

   void map(PdfContext context) {
      Map d = context.getDestination();
      LoanApplication app = context.getSource();
      Property property = app.getProperty();
      Address address = property.getAddress();
      if(address != null) {
         this.mapSubjectPropertyAddress(property.getAddress(), d);
      }

      Integer unitCount = property.getFinancedNumberOfUnits();
      if(unitCount != null) {
         d.put("no_of_units", unitCount);
      }

      this.mapLegalDescription(property.getLegalDescriptions(), d);
      Integer yearBuilt = property.getStructureBuiltYear();
      if(yearBuilt != null) {
         d.put("year_built", yearBuilt.toString());
      }

      this.mapLoanPurpose(app, d);
      this.mapTitleInfo(app, d);
      this.mapTitleHeld(context);
      this.mapDownPaymentSource(context);
      this.mapTitleHeldAs(context);
   }

   private void mapSubjectPropertyAddress(Address address, Map d) {
      StringBuffer sb = new StringBuffer();
      sb.append(address.getStreetAddress());
      sb.append(", ");
      sb.append(address.getCity());
      sb.append(", ");
      sb.append(address.getState());
      sb.append(" ");
      sb.append(address.getPostalCode());
      d.put("subject_property_address", sb.toString());
   }

   private void mapLegalDescription(String[] legalDescriptions, Map d) {
      if(legalDescriptions != null) {
         d.put("legal_desc", StringUtils.join(legalDescriptions, "; "));
      }

   }

   private void mapLoanPurpose(LoanApplication app, Map d) {
      LoanPurpose purpose = app.getLoanPurpose();
      if(purpose != null) {
         this.mapLoanPurposeCategory(purpose, d);
         String otherPurposeExplain = purpose.getOtherLoanPurposeDescription();
         if(otherPurposeExplain != null) {
            d.put("loan_purpose_other_explain", otherPurposeExplain);
         }

         this.mapUsageType(purpose.getPropertyUsageType(), d);
         this.mapCollateralType(purpose, d);
         LoanPurposeType purposeType = purpose.getLoanPurposeType();
         if(LoanPurposeType.CONSTRUCTION_TO_PERMANENT == purposeType) {
            this.mapConstructionPermanentDetails(purpose, d);
         }

         if(LoanPurposeType.REFINANCE == purposeType) {
            this.mapRefinanceDetails(app, d);
         }
      }

   }

   private void mapLoanPurposeCategory(LoanPurpose purpose, Map d) {
      LoanPurposeType purposeType = purpose.getLoanPurposeType();
      if(LoanPurposeType.PURCHASE == purposeType) {
         d.put("loan_purpose_purchase", "Yes");
      } else if(LoanPurposeType.CONSTRUCTION_TO_PERMANENT == purposeType) {
         d.put("loan_purpose_construct", "Yes");
      } else if(LoanPurposeType.REFINANCE == purposeType) {
         d.put("loan_purpose_refi", "Yes");
      } else if(LoanPurposeType.OTHER == purposeType) {
         d.put("loan_purpose_other", "Yes");
      }

      GSERefinancePurposeType refinanceLoanPurposeType = purpose.getConstructionRefinanceData().getGSERefinancePurposeType();
      if(GSERefinancePurposeType.CASH_OUT_CONSOLIDATION.equals(refinanceLoanPurposeType) || GSERefinancePurposeType.CASH_OUT_HOME_IMPROVEMENT.equals(refinanceLoanPurposeType) || GSERefinancePurposeType.CASH_OUT_LIMITED.equals(refinanceLoanPurposeType) || GSERefinancePurposeType.CASH_OUT_OTHER.equals(refinanceLoanPurposeType)) {
         d.put("loan_purpose_cashback", "Yes");
      }

      if(GSERefinancePurposeType.NO_CASH_OUT_FHA_STREAMLINED_REFINANCE.equals(refinanceLoanPurposeType) || GSERefinancePurposeType.NO_CASH_OUT_FRE_OWNED_REFINANCE.equals(refinanceLoanPurposeType) || GSERefinancePurposeType.NO_CASH_OUT_OTHER.equals(refinanceLoanPurposeType) || GSERefinancePurposeType.NO_CASH_OUT_STREAMLINED_REFINANCE.equals(refinanceLoanPurposeType)) {
         d.put("loan_purpose_nocash", "Yes");
      }

      if(LoanPurposeType.CONSTRUCTION_ONLY == purposeType) {
         d.put("loan_purpose_home_imp", "Yes");
      }

   }

   private void mapUsageType(PropertyUsageType usageType, Map d) {
      if(PropertyUsageType.PRIMARY_RESIDENCE == usageType) {
         d.put("property_type_primary", "Yes");
      } else if(PropertyUsageType.SECOND_HOME == usageType) {
         d.put("property_type_second", "Yes");
      } else if(PropertyUsageType.INVESTOR == usageType) {
         d.put("property_type_invest", "Yes");
      }

   }

   private void mapCollateralType(LoanPurpose purpose, Map d) {}

   private void mapConstructionPermanentDetails(LoanPurpose purpose, Map d) {
      ConstructionRefinanceData data = purpose.getConstructionRefinanceData();
      if(data != null) {
         ;
      }

   }

   private void mapRefinanceDetails(LoanApplication app, Map d) {
      BigDecimal refiLiens = this.getExistingLiensAmount(app);
      d.put("refi_liens", this.emptyStringIfNull(refiLiens));
      LoanPurpose lp = app.getLoanPurpose();
      if(lp != null) {
         String cashoutPurpose = null;
         RefinanceCashOutPurposeType pt = lp.getRefinanceCashOutPurposeType();
         if(pt != null) {
            cashoutPurpose = "CashOut-" + lp.getRefinanceCashOutPurposeType().getName();
         } else {
            cashoutPurpose = "Refi loan balance";
         }

         d.put("refi_purpose", cashoutPurpose);
      }

   }

   private void mapTitleInfo(LoanApplication app, Map d) {
      Borrower[] borrowers = app.getBorrowers();
      ArrayList names = new ArrayList();

      for(int i = 0; i < borrowers.length; ++i) {
         Borrower borrower = borrowers[i];
         String unparsedName = borrower.getUnparsedName();
         if(unparsedName != null) {
            names.add(unparsedName);
         }
      }

      d.put("title_held_names", StringUtils.join(names.toArray(), ", "));
   }

   private void mapTitleHeld(PdfContext context) {
      Map d = context.getDestination();
      String heldManner = context.getSource().getLoanPurpose().getGSETitleMannerHeldDescription();
      d.put("title_held_manner", heldManner);
   }

   private BigDecimal getExistingLiensAmount(LoanApplication app) {
      BigDecimal sum = new BigDecimal(0.0D);
      Liability[] liabilities = app.getLiabilities();

      for(int i = 0; i < liabilities.length; ++i) {
         Liability liability = liabilities[i];
         sum.add(liability.getUnpaidBalanceAmount());
      }

      return sum;
   }

   private void mapDownPaymentSource(PdfContext context) {
      Map d = context.getDestination();
      LoanApplication app = context.getSource();
      DownPayment[] downPayments = app.getDownPayments();
      if(downPayments != null) {
         ArrayList downPaymentInfos = new ArrayList();

         for(int i = 0; i < downPayments.length; ++i) {
            DownPayment downPayment = downPayments[i];
            String description = downPayment.getSourceDescription();
            if(description != null) {
               downPaymentInfos.add(description);
            }
         }

         d.put("source_down_pay", StringUtils.join(downPaymentInfos.toArray(), "; "));
      }

   }

   private void mapTitleHeldAs(PdfContext context) {
      Map d = context.getDestination();
      LoanApplication app = context.getSource();
      PropertyRightsType propertyRights = app.getLoanPurpose().getPropertyRightsType();
      if(propertyRights != null) {
         if(PropertyRightsType.FEE_SIMPLE.equals(propertyRights)) {
            d.put("estate_held_fee", "Yes");
         }

         if(PropertyRightsType.LEASEHOLD.equals(propertyRights)) {
            d.put("estate_held_lease", "Yes");
         }
      }

   }
}
