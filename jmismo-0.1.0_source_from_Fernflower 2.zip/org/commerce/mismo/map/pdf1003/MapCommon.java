package org.commerce.mismo.map.pdf1003;

import org.commerce.mismo.map.pdf1003.OutputFormatting;
import org.commerce.mismo.map.pdf1003.PdfContext;

abstract class MapCommon extends OutputFormatting {

   abstract void map(PdfContext var1);
}
