package org.commerce.mismo.map.pdf1003;

import java.util.Map;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.MailTo;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.PdfContext;

public class MapMailTo extends MapCommon {

   private static final String[] MAIL_KEY_NAMES = new String[]{"borrower_mailing_addressa", "borrower_mailing_addressb", "borrower_mailing_addressc", "borrower_mailing_addressd"};


   void map(PdfContext context) {
      Map d = context.getDestination();
      Borrower borrower = context.getCurrentBorrower();
      MailTo mailTo = borrower.getMailTo();
      if(mailTo != null) {
         this.mapMailTo(d, mailTo, "");
      }

      if(context.isLeftSideBorrower(borrower) && context.isJointly()) {
         Borrower coborrower = borrower.getJointAssetBorrower();
         if(coborrower != null) {
            MailTo mailTo2 = coborrower.getMailTo();
            if(mailTo2 != null) {
               this.mapMailTo(d, mailTo2, "co");
            }
         }
      }

   }

   protected void mapMailTo(Map d, MailTo mailTo, String prefix) {
      if(!mailTo.getIsSameAddress().booleanValue()) {
         byte nextAvailable = 0;
         int nextAvailable1 = this.writeOffsetEntryToMap(d, nextAvailable, prefix, mailTo.getStreetAddress1());
         nextAvailable1 = this.writeOffsetEntryToMap(d, nextAvailable1, prefix, mailTo.getStreetAddress2());
         String cityStateZip = mailTo.getCity() + ", " + mailTo.getState() + " " + mailTo.getPostalCode();
         nextAvailable1 = this.writeOffsetEntryToMap(d, nextAvailable1, prefix, cityStateZip);
         this.writeOffsetEntryToMap(d, nextAvailable1, prefix, mailTo.getCountry());
      }

   }

   protected int writeOffsetEntryToMap(Map d, int nextAvailable, String prefix, String source) {
      int offset = nextAvailable;
      if(source != null) {
         StringBuffer var10001 = (new StringBuffer()).append(prefix);
         offset = nextAvailable + 1;
         d.put(var10001.append(MAIL_KEY_NAMES[nextAvailable]).toString(), source);
      }

      return offset;
   }

}
