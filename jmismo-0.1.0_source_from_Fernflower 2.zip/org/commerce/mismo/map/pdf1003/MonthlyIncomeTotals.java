package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;

class MonthlyIncomeTotals {

   private BigDecimal borrowerTotal = new BigDecimal(0.0D);
   private BigDecimal coBorrowerTotal = new BigDecimal(0.0D);


   BigDecimal getBorrowerTotal() {
      return this.borrowerTotal;
   }

   BigDecimal getCoBorrowerTotal() {
      return this.coBorrowerTotal;
   }

   void setBorrowerTotal(BigDecimal decimal) {
      this.borrowerTotal = decimal;
   }

   void setCoBorrowerTotal(BigDecimal decimal) {
      this.coBorrowerTotal = decimal;
   }

   void addToBorrowerTotal(BigDecimal decimal) {
      this.borrowerTotal = this.borrowerTotal.add(decimal);
   }

   void addToCoBorrowerTotal(BigDecimal decimal) {
      this.coBorrowerTotal = this.coBorrowerTotal.add(decimal);
   }
}
