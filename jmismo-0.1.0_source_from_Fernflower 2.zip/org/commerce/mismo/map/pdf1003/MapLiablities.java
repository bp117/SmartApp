package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;
import java.util.Map;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.DispositionStatusType;
import org.commerce.mismo.Liability;
import org.commerce.mismo.LiabilityType;
import org.commerce.mismo.REOProperty;
import org.commerce.mismo.map.pdf1003.MapAssetsAndLiabilities;
import org.commerce.mismo.map.pdf1003.MapFilterManager;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapLiablities extends MapAssetsAndLiabilities {

   private static final int MAX_REO_ENTRY_COUNT = 6;
   private static final int MAX_MORTGAGE_LIABILITY_COUNT = 2;
   private static final int MAX_NON_MORTGAGE_LIABILITY_COUNT = 5;


   BigDecimal renderLiabilities(PdfContext context) {
      BigDecimal unpaidLiabilities = this.mapLiabilities(context);
      this.mapREOProperties(context);
      return unpaidLiabilities;
   }

   private BigDecimal mapLiabilities(PdfContext context) {
      Liability[] liabilities = context.getSource().getLiabilities();
      Map d = context.getDestination();
      BigDecimal unpaidSum = new BigDecimal(0.0D);
      Borrower currentBorrower = context.getCurrentBorrower();
      if(liabilities != null) {
         BigDecimal monthlyPaymentSum = new BigDecimal(0.0D);
         int mortgageIdx = 1;

         int i;
         for(i = 0; i < liabilities.length; ++i) {
            Liability renderIdx = liabilities[i];
            if(renderIdx.getLiabilityType().equals(LiabilityType.MORTGAGE_LOAN)) {
               int l = MapFilterManager.getBorrowerRelationship(renderIdx, currentBorrower);
               if(3 != l) {
                  d.put("mortgage_co_info" + mortgageIdx + "a", renderIdx.getHolderName());
                  d.put("mortgage_acct" + mortgageIdx, renderIdx.getAccountIdentifier());
                  if(1 == l || 2 == l) {
                     d.put("mortgage_payment" + mortgageIdx, renderIdx.getMonthlyPaymentAmount());
                     monthlyPaymentSum = monthlyPaymentSum.add(renderIdx.getMonthlyPaymentAmount());
                     BigDecimal borrowerRelationship = renderIdx.getUnpaidBalanceAmount();
                     d.put("unpaid_mortgage" + mortgageIdx, borrowerRelationship);
                     unpaidSum = unpaidSum.add(borrowerRelationship);
                  }

                  if(mortgageIdx++ >= 2) {
                     break;
                  }
               }
            }
         }

         for(int var13 = 1; i < liabilities.length; ++i) {
            Liability var14 = liabilities[i];
            if(!var14.getLiabilityType().equals(LiabilityType.MORTGAGE_LOAN)) {
               int var15 = MapFilterManager.getBorrowerRelationship(var14, currentBorrower);
               if(3 != var15) {
                  d.put("liability" + var13, this.formatNameType(var14.getHolderName(), var14.getLiabilityType()));
                  if(1 == var15) {
                     d.put("liability_payment" + var13, this.emptyStringIfNull(var14.getMonthlyPaymentAmount()));
                     monthlyPaymentSum = monthlyPaymentSum.add(var14.getMonthlyPaymentAmount());
                     BigDecimal unpaidBalance = var14.getUnpaidBalanceAmount();
                     d.put("unpaid_liability" + var13, this.emptyStringIfNull(unpaidBalance));
                     unpaidSum = unpaidSum.add(unpaidBalance);
                  }

                  if(var13++ >= 5) {
                     break;
                  }
               }
            }
         }

         d.put("total_monthly_payments", this.emptyStringIfNull(monthlyPaymentSum));
         d.put("total_liabilities", this.emptyStringIfNull(unpaidSum));
      }

      return unpaidSum;
   }

   private void mapREOProperties(PdfContext context) {
      REOProperty[] properties = context.getSource().getReoProperties();
      Map d = context.getDestination();
      BigDecimal sumPresentValue = new BigDecimal(0.0D);
      BigDecimal sumLiens = new BigDecimal(0.0D);
      BigDecimal sumRentalIncome = new BigDecimal(0.0D);
      BigDecimal sumMortgagePayments = new BigDecimal(0.0D);
      BigDecimal sumMaintenance = new BigDecimal(0.0D);
      BigDecimal sumNetIncome = new BigDecimal(0.0D);
      Borrower currentBorrower = context.getCurrentBorrower();
      int rowIndex = 1;

      for(int offset = 0; offset < properties.length; ++offset) {
         REOProperty r = properties[offset];
         int borrowerRelationship = MapFilterManager.getBorrowerRelationship(r, currentBorrower);
         boolean isShowEntry = 3 != borrowerRelationship;
         if(isShowEntry) {
            String address = r.getAddress().getStreetAddress() + "\n" + this.getCityStateZipCountry(r.getAddress());
            d.put("reo_address" + rowIndex, address);
            d.put("reo_status" + rowIndex, this.formatDispositionStatus(r.getDispositionStatusType()));
            d.put("reo_type" + rowIndex, r.getGSEPropertyType().getName());
            boolean isShowAmount = 1 == borrowerRelationship;
            if(isShowAmount) {
               d.put("reo_mkt_value" + rowIndex, r.getMarketValueAmount());
               sumPresentValue = sumPresentValue.add(this.sumHelp(r.getMarketValueAmount()));
               d.put("reo_amt_mortgage" + rowIndex, r.getLienInstallmentAmount());
               sumLiens = sumLiens.add(this.sumHelp(r.getLienInstallmentAmount()));
               d.put("reo_rent_income" + rowIndex, r.getRentalIncomeGrossAmount());
               sumRentalIncome = sumRentalIncome.add(this.sumHelp(r.getRentalIncomeGrossAmount()));
               sumMortgagePayments = sumMortgagePayments.add(this.mapReoEntry(d, rowIndex, "mort_pay", MapFilterManager.getTotalForTypeFromArray(r.getLiabilities(), LiabilityType.MORTGAGE_LOAN)));
               d.put("reo_insure" + rowIndex, r.getMaintenanceExpenseAmount());
               sumMaintenance = sumMaintenance.add(this.sumHelp(r.getMaintenanceExpenseAmount()));
               d.put("reo_net_rent" + rowIndex, r.getRentalIncomeNetAmount());
               sumNetIncome = sumNetIncome.add(this.sumHelp(r.getRentalIncomeNetAmount()));
            }

            if(rowIndex++ >= 6) {
               break;
            }
         }
      }

      d.put("reo_mkt_value_total", sumPresentValue);
      d.put("reo_amt_mortgage_total", sumLiens);
      d.put("reo_rent_income_total", sumRentalIncome);
      d.put("reo_mort_pay_total", sumMortgagePayments);
      d.put("reo_insure_total", sumMaintenance);
      d.put("reo_net_rent_total", sumNetIncome);
   }

   private BigDecimal mapReoEntry(Map d, int index, String keyToken, BigDecimal amount) {
      d.put("reo_" + keyToken + index, amount);
      return amount;
   }

   private String formatDispositionStatus(DispositionStatusType status) {
      return status == null?"":(status.equals(DispositionStatusType.PENDING_SALE)?"PS":(status.equals(DispositionStatusType.RETAIN_FOR_PRIMARY_OR_SECONDARY_RESIDENCE)?"":(status.equals(DispositionStatusType.RETAIN_FOR_RENTAL)?"R":(status.equals(DispositionStatusType.SOLD)?"S":""))));
   }

   private BigDecimal sumHelp(BigDecimal b) {
      return b == null?new BigDecimal(0.0D):b;
   }
}
