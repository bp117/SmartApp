package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.enums.Enum;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.commerce.mismo.Address;
import org.commerce.mismo.util.StringUtil;

abstract class OutputFormatting {

   protected static final String CHECK = "Yes";
   protected static final String UNCHECK = " ";
   private static final SimpleDateFormat MMYY_FORMATTER = new SimpleDateFormat("MMyy");
   protected static final String JOIN_SEPARATOR = "; ";
   private Log log = LogFactory.getLog(this.getClass());


   protected String emptyStringIfNull(Object value) {
      return value != null?value.toString():"";
   }

   protected String formattedInPercent(Float percent) {
      return percent != null?this.formattedInPercent(percent.toString()):"";
   }

   protected String formattedInPercent(BigDecimal percent) {
      return percent != null?this.formattedInPercent(percent.toString()):"";
   }

   protected String formattedInPercent(String percent) {
      return percent != null?percent:"";
   }

   protected String getCityStateZipCountry(Address address) {
      return this.getCityStateZipCountry(address.getCity(), address.getState(), address.getPostalCode(), address.getCountry());
   }

   protected String getCityStateZipCountry(String city, String state, String postalCode, String country) {
      ArrayList addressComponents = new ArrayList();
      if(city != null) {
         addressComponents.add(city);
      }

      if(state != null) {
         if(postalCode != null) {
            state = state + " " + postalCode;
         }

         addressComponents.add(state);
      } else if(postalCode != null) {
         addressComponents.add(postalCode);
      }

      if(country != null) {
         addressComponents.add(country);
      }

      return StringUtils.join(addressComponents.toArray(), ", ");
   }

   protected String formatMMYYDate(Date date) {
      String result = "";
      if(date != null) {
         result = MMYY_FORMATTER.format(date);
      }

      return result;
   }

   protected String formatDate(Date date) {
      return StringUtil.formatDate(date);
   }

   protected void mapPhone(Map d, String key, String phone) {
      if(phone != null) {
         d.put(key, StringUtil.formatPhone(phone));
         if(this.getLog().isDebugEnabled()) {
            this.getLog().debug("Formatted phone number is \'" + StringUtil.formatPhone(phone) + '\'');
         }
      }

   }

   protected String formatEnum(Enum e) {
      return e != null?e.getName():"";
   }

   protected void mapBooleanDeclaration(boolean value, Map valMap, String yesBox, String noBox) {
      if(value) {
         valMap.put(yesBox, "Yes");
      } else {
         valMap.put(noBox, "Yes");
      }

   }

   protected Log getLog() {
      return this.log;
   }

}
