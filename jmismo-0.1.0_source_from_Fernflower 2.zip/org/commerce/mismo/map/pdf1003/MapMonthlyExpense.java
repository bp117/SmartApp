package org.commerce.mismo.map.pdf1003;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.HousingExpenseType;
import org.commerce.mismo.LoanApplication;
import org.commerce.mismo.PresentHousingExpense;
import org.commerce.mismo.ProposedHousingExpense;
import org.commerce.mismo.map.pdf1003.Context;
import org.commerce.mismo.map.pdf1003.MapCommon;
import org.commerce.mismo.map.pdf1003.MapFilterManager;
import org.commerce.mismo.map.pdf1003.PdfContext;

class MapMonthlyExpense extends MapCommon {

   void map(PdfContext context) {
      Borrower borrower = context.getCurrentBorrower();
      if(context.isLeftSideBorrower(borrower)) {
         this.map(context, borrower);
      }

   }

   private void map(PdfContext context, Borrower borrower) {
      LoanApplication app = context.getSource();
      if(app != null) {
         Context expenseContext = new Context();
         expenseContext.setBorrower(borrower);
         expenseContext.setProposedExpenses(app.getProposedHousingExpenses());
         expenseContext.setContext(context);
         this.mapExpenseRow(expenseContext, HousingExpenseType.RENT, "rent");
         this.mapExpenseRow(expenseContext, HousingExpenseType.FIRST_MORTGAGE_PRINCIPAL_AND_INTEREST, "mortgage");
         this.mapExpenseRow(expenseContext, HousingExpenseType.OTHER_MORTGAGE_LOAN_PRINCIPAL_AND_INTEREST, "financing");
         this.mapExpenseRow(expenseContext, HousingExpenseType.HAZARD_INSURANCE, "haz_ins");
         this.mapExpenseRow(expenseContext, HousingExpenseType.REAL_ESTATE_TAX, "real_estate");
         this.mapExpenseRow(expenseContext, HousingExpenseType.MORTGAGE_INSURANCE, "mort_ins");
         this.mapExpenseRow(expenseContext, HousingExpenseType.HOMEOWNERS_ASSOCIATION_DUES_AND_CONDO_FEES, "home_dues");
         this.mapExpenseRow(expenseContext, HousingExpenseType.OTHER_HOUSING_EXPENSE, "other");
         this.mapTotalRow(expenseContext);
      }

   }

   private void mapExpenseRow(Context expenseContext, HousingExpenseType type, String keyComponent) {
      expenseContext.setType(type);
      this.mapPresentExpenseRow(expenseContext);
      this.mapProposedExpenseRow(expenseContext);
   }

   private void mapPresentExpenseRow(Context expenseContext) {
      if(this.getLog().isDebugEnabled()) {
         if(expenseContext.getPresentExpenses() != null) {
            this.getLog().debug("mapPresentExpenseRow(): presentExpense class is " + expenseContext.getPresentExpenses().getClass().getName());
         } else {
            this.getLog().debug("mapPresentExpenseRow(): presentExpense is null");
         }

         this.getLog().debug("mapPResentExpenseRow(): type class is " + expenseContext.getType().getClass().getName());
      }

      List filteredExpenses = MapFilterManager.filterObjectsFromArray(expenseContext.getPresentExpenses(), expenseContext.getType());
      BigDecimal presentExpense = new BigDecimal(0.0D);

      PresentHousingExpense expense;
      for(Iterator iter = filteredExpenses.iterator(); iter.hasNext(); presentExpense = presentExpense.add(expense.getPaymentAmount())) {
         expense = (PresentHousingExpense)iter.next();
      }

      expenseContext.getContext().getDestination().put("present_" + expenseContext.getKeyComponent(), this.emptyStringIfNull(presentExpense));
   }

   private void mapProposedExpenseRow(Context expenseContext) {
      List filteredExpenses = MapFilterManager.filterObjectsFromArray(expenseContext.getProposedExpenses(), expenseContext.getType());
      BigDecimal proposedExpense = new BigDecimal(0.0D);

      ProposedHousingExpense expense;
      for(Iterator iter = filteredExpenses.iterator(); iter.hasNext(); proposedExpense = proposedExpense.add(expense.getPaymentAmount())) {
         expense = (ProposedHousingExpense)iter.next();
      }

      expenseContext.getContext().getDestination().put("proposed_" + expenseContext.getKeyComponent(), this.emptyStringIfNull(proposedExpense));
   }

   private void mapTotalRow(Context context) {
      Map d = context.getContext().getDestination();
      d.put("present_total", this.emptyStringIfNull(context.getPresentTotal()));
      d.put("proposed_total", this.emptyStringIfNull(context.getProposedTotal()));
   }
}
