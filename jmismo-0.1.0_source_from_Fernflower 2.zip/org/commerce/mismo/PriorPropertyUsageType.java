package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class PriorPropertyUsageType extends Enum {

   public static final PriorPropertyUsageType INVESTMENT = new PriorPropertyUsageType("Investment");
   public static final PriorPropertyUsageType PRIMARY_RESIDENCE = new PriorPropertyUsageType("PrimaryResidence");
   public static final PriorPropertyUsageType SECONDARY_RESIDENCE = new PriorPropertyUsageType("SecondaryResidence");
   static Class class$org$commerce$mismo$PriorPropertyUsageType;


   private PriorPropertyUsageType(String name) {
      super(name);
   }

   public static PriorPropertyUsageType getEnum(String type) {
      return (PriorPropertyUsageType)getEnum(class$org$commerce$mismo$PriorPropertyUsageType == null?(class$org$commerce$mismo$PriorPropertyUsageType = class$("org.commerce.mismo.PriorPropertyUsageType")):class$org$commerce$mismo$PriorPropertyUsageType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$PriorPropertyUsageType == null?(class$org$commerce$mismo$PriorPropertyUsageType = class$("org.commerce.mismo.PriorPropertyUsageType")):class$org$commerce$mismo$PriorPropertyUsageType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$PriorPropertyUsageType == null?(class$org$commerce$mismo$PriorPropertyUsageType = class$("org.commerce.mismo.PriorPropertyUsageType")):class$org$commerce$mismo$PriorPropertyUsageType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$PriorPropertyUsageType == null?(class$org$commerce$mismo$PriorPropertyUsageType = class$("org.commerce.mismo.PriorPropertyUsageType")):class$org$commerce$mismo$PriorPropertyUsageType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
