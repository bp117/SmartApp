package org.commerce.mismo;

import java.math.BigDecimal;
import org.commerce.mismo.Address;
import org.commerce.mismo.DispositionStatusType;
import org.commerce.mismo.GSEPropertyType;
import org.commerce.mismo.Liability;
import org.commerce.mismo.MultiBorrowerAssociatedEntity;

public interface REOProperty extends MultiBorrowerAssociatedEntity {

   Liability[] getLiabilities();

   void addLiability(Liability var1);

   void removeLiability(Liability var1);

   Address getAddress();

   DispositionStatusType getDispositionStatusType();

   void setDispositionStatusType(DispositionStatusType var1);

   GSEPropertyType getGSEPropertyType();

   void setGSEPropertyType(GSEPropertyType var1);

   BigDecimal getMarketValueAmount();

   void setMarketValueAmount(BigDecimal var1);

   BigDecimal getLienUnpaidPrincipalBalanceAmount();

   void setLienUnpaidPrincipalBalanceAmount(BigDecimal var1);

   BigDecimal getRentalIncomeGrossAmount();

   void setRentalIncomeGrossAmount(BigDecimal var1);

   BigDecimal getLienInstallmentAmount();

   void setLienInstallmentAmount(BigDecimal var1);

   BigDecimal getMaintenanceExpenseAmount();

   void setMaintenanceExpenseAmount(BigDecimal var1);

   BigDecimal getRentalIncomeNetAmount();

   void setRentalIncomeNetAmount(BigDecimal var1);

   boolean isCurrentResidence();

   void setCurrentResidence(boolean var1);

   boolean isSubject();

   void setSubject(boolean var1);
}
