package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class ContactPointRoleType extends Enum {

   public static final ContactPointRoleType HOME = new ContactPointRoleType("Home");
   public static final ContactPointRoleType MOBILE = new ContactPointRoleType("Mobile");
   public static final ContactPointRoleType WORK = new ContactPointRoleType("Work");
   static Class class$org$commerce$mismo$ContactPointRoleType;


   private ContactPointRoleType(String name) {
      super(name);
   }

   public static ContactPointRoleType getEnum(String type) {
      return (ContactPointRoleType)getEnum(class$org$commerce$mismo$ContactPointRoleType == null?(class$org$commerce$mismo$ContactPointRoleType = class$("org.commerce.mismo.ContactPointRoleType")):class$org$commerce$mismo$ContactPointRoleType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$ContactPointRoleType == null?(class$org$commerce$mismo$ContactPointRoleType = class$("org.commerce.mismo.ContactPointRoleType")):class$org$commerce$mismo$ContactPointRoleType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$ContactPointRoleType == null?(class$org$commerce$mismo$ContactPointRoleType = class$("org.commerce.mismo.ContactPointRoleType")):class$org$commerce$mismo$ContactPointRoleType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$ContactPointRoleType == null?(class$org$commerce$mismo$ContactPointRoleType = class$("org.commerce.mismo.ContactPointRoleType")):class$org$commerce$mismo$ContactPointRoleType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
