package org.commerce.mismo;

import org.commerce.mismo.Address;
import org.commerce.mismo.ContactDetail;

public interface Landlord {

   String getName();

   void setName(String var1);

   Address getAddress();

   ContactDetail getContactDetail();
}
