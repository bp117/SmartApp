package org.commerce.mismo;


public interface MailTo {

   String getCity();

   String getCountry();

   String getPostalCode();

   String getState();

   String getStreetAddress1();

   String getStreetAddress2();

   void setCity(String var1);

   void setCountry(String var1);

   void setPostalCode(String var1);

   void setState(String var1);

   void setStreetAddress1(String var1);

   void setStreetAddress2(String var1);

   void setIsSameAddress(Boolean var1);

   Boolean getIsSameAddress();
}
