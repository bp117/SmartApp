package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public class IdentificationType extends Enum {

   public static final String US_DRIVERS_LICENSE_IDENTIFICATION_TYPE_CODE = "01";
   public static final String US_MILITARY_OR_GOVERNMENT_IDENTIFICATION_ID_TYPE_CODE = "02";
   public static final String PASSPORT_IDENTIFICATION_TYPE_CODE = "03";
   public static final String US_STATE_ID_IDENTIFICATION_TYPE_CODE = "04";
   private String code;
   public static final IdentificationType US_DRIVERS_LICENSE = new IdentificationType("01");
   public static final IdentificationType US_MILITARY_OR_GOVERNMENT_ID = new IdentificationType("02");
   public static final IdentificationType PASSPORT = new IdentificationType("03");
   public static final IdentificationType US_STATE_ID = new IdentificationType("04");
   static Class class$org$commerce$mismo$IdentificationType;


   public IdentificationType(String arg0) {
      super(arg0);
      this.code = arg0;
   }

   public static IdentificationType getEnum(String type) {
      return (IdentificationType)getEnum(class$org$commerce$mismo$IdentificationType == null?(class$org$commerce$mismo$IdentificationType = class$("org.commerce.mismo.IdentificationType")):class$org$commerce$mismo$IdentificationType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$IdentificationType == null?(class$org$commerce$mismo$IdentificationType = class$("org.commerce.mismo.IdentificationType")):class$org$commerce$mismo$IdentificationType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$IdentificationType == null?(class$org$commerce$mismo$IdentificationType = class$("org.commerce.mismo.IdentificationType")):class$org$commerce$mismo$IdentificationType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$IdentificationType == null?(class$org$commerce$mismo$IdentificationType = class$("org.commerce.mismo.IdentificationType")):class$org$commerce$mismo$IdentificationType);
   }

   public String getCode() {
      return this.code;
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
