package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public class ApplicationMethodTakenType extends Enum {

   public static final ApplicationMethodTakenType INTERNET = new ApplicationMethodTakenType("Internet");
   static Class class$org$commerce$mismo$ApplicationMethodTakenType;


   public static ApplicationMethodTakenType getEnum(String type) {
      return (ApplicationMethodTakenType)getEnum(class$org$commerce$mismo$ApplicationMethodTakenType == null?(class$org$commerce$mismo$ApplicationMethodTakenType = class$("org.commerce.mismo.ApplicationMethodTakenType")):class$org$commerce$mismo$ApplicationMethodTakenType, type);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$ApplicationMethodTakenType == null?(class$org$commerce$mismo$ApplicationMethodTakenType = class$("org.commerce.mismo.ApplicationMethodTakenType")):class$org$commerce$mismo$ApplicationMethodTakenType);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$ApplicationMethodTakenType == null?(class$org$commerce$mismo$ApplicationMethodTakenType = class$("org.commerce.mismo.ApplicationMethodTakenType")):class$org$commerce$mismo$ApplicationMethodTakenType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$ApplicationMethodTakenType == null?(class$org$commerce$mismo$ApplicationMethodTakenType = class$("org.commerce.mismo.ApplicationMethodTakenType")):class$org$commerce$mismo$ApplicationMethodTakenType);
   }

   private ApplicationMethodTakenType(String name) {
      super(name);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
