package org.commerce.mismo;


public interface PropertyInformation {
}
