package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class PrintPositionType extends Enum {

   public static final PrintPositionType BORROWER = new PrintPositionType("Borrower");
   public static final PrintPositionType COBORROWER = new PrintPositionType("CoBorrower");
   static Class class$org$commerce$mismo$PrintPositionType;


   private PrintPositionType(String name) {
      super(name);
   }

   public static PrintPositionType getEnum(String type) {
      return (PrintPositionType)getEnum(class$org$commerce$mismo$PrintPositionType == null?(class$org$commerce$mismo$PrintPositionType = class$("org.commerce.mismo.PrintPositionType")):class$org$commerce$mismo$PrintPositionType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$PrintPositionType == null?(class$org$commerce$mismo$PrintPositionType = class$("org.commerce.mismo.PrintPositionType")):class$org$commerce$mismo$PrintPositionType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$PrintPositionType == null?(class$org$commerce$mismo$PrintPositionType = class$("org.commerce.mismo.PrintPositionType")):class$org$commerce$mismo$PrintPositionType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$PrintPositionType == null?(class$org$commerce$mismo$PrintPositionType = class$("org.commerce.mismo.PrintPositionType")):class$org$commerce$mismo$PrintPositionType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
