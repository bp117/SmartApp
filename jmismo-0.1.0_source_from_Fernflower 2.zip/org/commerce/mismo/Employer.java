package org.commerce.mismo;

import java.math.BigDecimal;
import java.util.Date;
import org.commerce.mismo.Address;

public interface Employer {

   String getName();

   void setName(String var1);

   Address getAddress();

   boolean isCurrent();

   void setEmploymentPrimaryIndicator(boolean var1);

   boolean getEmploymentPrimaryIndicator();

   void setCurrent(boolean var1);

   boolean isSelfEmployed();

   void setSelfEmployed(boolean var1);

   int getYearsOnJob();

   void setYearsOnJob(int var1);

   int getMonthsOnJob();

   void setMonthsOnJob(int var1);

   int getTimeInLineOfWork();

   void setTimeInLineOfWork(int var1);

   BigDecimal getMonthlyIncome();

   void setMonthlyIncome(BigDecimal var1);

   String getEmploymentPositionDescription();

   void setEmploymentPositionDescription(String var1);

   Date getPreviousEmploymentStartDate();

   void setPreviousEmploymentStartDate(Date var1);

   Date getPreviousEmploymentEndDate();

   void setPreviousEmploymentEndDate(Date var1);

   String getTelephoneNumber();

   void setTelephoneNumber(String var1);
}
