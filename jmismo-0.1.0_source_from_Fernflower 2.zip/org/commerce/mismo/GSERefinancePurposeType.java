package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class GSERefinancePurposeType extends Enum {

   public static final GSERefinancePurposeType CASH_OUT_CONSOLIDATION = new GSERefinancePurposeType("CashOutDebtConsolidation");
   public static final GSERefinancePurposeType CASH_OUT_HOME_IMPROVEMENT = new GSERefinancePurposeType("CashOutHomeImprovement");
   public static final GSERefinancePurposeType CASH_OUT_LIMITED = new GSERefinancePurposeType("CashOutLimited");
   public static final GSERefinancePurposeType CASH_OUT_OTHER = new GSERefinancePurposeType("CashOutOther");
   public static final GSERefinancePurposeType NO_CASH_OUT_FHA_STREAMLINED_REFINANCE = new GSERefinancePurposeType("NoCashOutFHAStreamlinedRefinance");
   public static final GSERefinancePurposeType NO_CASH_OUT_FRE_OWNED_REFINANCE = new GSERefinancePurposeType("NoCashOutFREOwnedRefinance");
   public static final GSERefinancePurposeType NO_CASH_OUT_OTHER = new GSERefinancePurposeType("NoCashOutOther");
   public static final GSERefinancePurposeType NO_CASH_OUT_STREAMLINED_REFINANCE = new GSERefinancePurposeType("NoCashOutStreamlinedRefinance");
   public static final GSERefinancePurposeType CHANGE_IN_RATE_TERM = new GSERefinancePurposeType("ChangeInRateTerm");
   static Class class$org$commerce$mismo$GSERefinancePurposeType;


   private GSERefinancePurposeType(String name) {
      super(name);
   }

   public static GSERefinancePurposeType getEnum(String type) {
      return (GSERefinancePurposeType)getEnum(class$org$commerce$mismo$GSERefinancePurposeType == null?(class$org$commerce$mismo$GSERefinancePurposeType = class$("org.commerce.mismo.GSERefinancePurposeType")):class$org$commerce$mismo$GSERefinancePurposeType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$GSERefinancePurposeType == null?(class$org$commerce$mismo$GSERefinancePurposeType = class$("org.commerce.mismo.GSERefinancePurposeType")):class$org$commerce$mismo$GSERefinancePurposeType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$GSERefinancePurposeType == null?(class$org$commerce$mismo$GSERefinancePurposeType = class$("org.commerce.mismo.GSERefinancePurposeType")):class$org$commerce$mismo$GSERefinancePurposeType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$GSERefinancePurposeType == null?(class$org$commerce$mismo$GSERefinancePurposeType = class$("org.commerce.mismo.GSERefinancePurposeType")):class$org$commerce$mismo$GSERefinancePurposeType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
