package org.commerce.mismo;

import org.commerce.mismo.ApplicationMethodTakenType;

public interface InterviewerInformation {

   ApplicationMethodTakenType getApplicationMethodTakenType();

   void setApplicationMethodTakenType(ApplicationMethodTakenType var1);
}
