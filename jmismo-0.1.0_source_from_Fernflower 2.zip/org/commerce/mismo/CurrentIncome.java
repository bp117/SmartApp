package org.commerce.mismo;

import java.math.BigDecimal;
import org.commerce.mismo.IncomeType;
import org.commerce.mismo.Mismo;

public interface CurrentIncome extends Mismo {

   BigDecimal getMonthlyTotalAmount();

   void setMonthlyTotalAmount(BigDecimal var1);

   IncomeType getIncomeType();

   void setIncomeType(IncomeType var1);
}
