package org.commerce.mismo;

import java.util.List;
import org.commerce.mismo.GenderType;
import org.commerce.mismo.HMDAEthnicityType;

public interface GovernmentMonitoring {

   Boolean getRaceNationalOriginRefusalIndicator();

   void setRaceNationalOriginRefusalIndicator(Boolean var1);

   GenderType getGenderType();

   void setGenderType(GenderType var1);

   HMDAEthnicityType getEthnicityType();

   void setEthnicityType(HMDAEthnicityType var1);

   List getHMDARaces();

   void setHMDARaces(List var1);
}
