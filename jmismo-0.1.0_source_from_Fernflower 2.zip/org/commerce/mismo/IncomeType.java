package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class IncomeType extends Enum {

   public static final IncomeType ALIMONY_CHILD_SUPPORT = new IncomeType("AlimonyChildSupport");
   public static final IncomeType AUTOMOBILE_EXPENSE_ACCOUNT = new IncomeType("AutomobileExpenseAllowance");
   public static final IncomeType BASE = new IncomeType("Base");
   public static final IncomeType BONUS = new IncomeType("Bonus");
   public static final IncomeType COMMISSIONS = new IncomeType("Commissions");
   public static final IncomeType DIVIDENDS_INTEREST = new IncomeType("DividendsInterest");
   public static final IncomeType FOSTER_CARE = new IncomeType("FosterCare");
   public static final IncomeType NET_RENTAL_INCOME = new IncomeType("NetRentalIncome");
   public static final IncomeType NOTES_RECEIVABLE_INSTALLMENT = new IncomeType("NotesReceivableInstallment");
   public static final IncomeType OTHER_TYPES_OF_INCOME = new IncomeType("OtherTypesOfIncome");
   public static final IncomeType OVERTIME = new IncomeType("Overtime");
   public static final IncomeType PENSION = new IncomeType("Pension");
   public static final IncomeType SOCIAL_SECURITY = new IncomeType("SocialSecurity");
   public static final IncomeType SUBJECT_PROPERTY_NET_CASH_FLOW = new IncomeType("SubjectPropertyNetCashFlow");
   public static final IncomeType TRUST = new IncomeType("Trust");
   public static final IncomeType UNEMPLOYMENT = new IncomeType("Unemployment");
   public static final IncomeType PUBLIC_ASSISTANCE = new IncomeType("PublicAssistance");
   public static final IncomeType VA_BENEFITS_NON_EDUCATIONAL = new IncomeType("VABenefitsNonEducational");
   public static final IncomeType MORTGAGE_DIFFERENTIAL = new IncomeType("MortgageDifferential");
   public static final IncomeType MILITARY_BASE_PAY = new IncomeType("MilitaryBasePay");
   public static final IncomeType MILITARY_RATIONAL_ALLOWANCE = new IncomeType("MilitaryRationsAllowance");
   public static final IncomeType MILITARY_FLIGHT_PAY = new IncomeType("MilitaryFlightPay");
   public static final IncomeType MILITARY_HAZARD_PAY = new IncomeType("MilitaryHazardPay");
   public static final IncomeType MILITARY_CLOTHES_ALLOWANCE = new IncomeType("MilitaryClothesAllowance");
   public static final IncomeType MILITARY_QUARTERS_ALLOWANCE = new IncomeType("MilitaryQuartersAllowance");
   public static final IncomeType MILITARY_PROP_PAY = new IncomeType("MilitaryPropPay");
   public static final IncomeType MILITARY_OVERSEAS_PAY = new IncomeType("MilitaryOverseasPay");
   public static final IncomeType MILITARY_COMBAT_PAY = new IncomeType("MilitaryCombatPay");
   public static final IncomeType MILITARY_VARIABLE_HOUSING_ALLOWANCE = new IncomeType("MilitaryVariableHousingAllowance");
   public static final IncomeType[] OTHER_INCOME_TYPES = new IncomeType[]{ALIMONY_CHILD_SUPPORT, AUTOMOBILE_EXPENSE_ACCOUNT, FOSTER_CARE, MILITARY_BASE_PAY, MILITARY_CLOTHES_ALLOWANCE, MILITARY_COMBAT_PAY, MILITARY_FLIGHT_PAY, MILITARY_HAZARD_PAY, MILITARY_OVERSEAS_PAY, MILITARY_PROP_PAY, MILITARY_QUARTERS_ALLOWANCE, MILITARY_RATIONAL_ALLOWANCE, MILITARY_VARIABLE_HOUSING_ALLOWANCE, MORTGAGE_DIFFERENTIAL, NOTES_RECEIVABLE_INSTALLMENT, PENSION, PUBLIC_ASSISTANCE, SOCIAL_SECURITY, SUBJECT_PROPERTY_NET_CASH_FLOW, TRUST, UNEMPLOYMENT, VA_BENEFITS_NON_EDUCATIONAL};
   static Class class$org$commerce$mismo$IncomeType;


   private IncomeType(String name) {
      super(name);
   }

   public String getFormattedName() {
      String originalName = this.getName();
      StringBuffer formattedName = new StringBuffer(originalName.length());

      for(int i = 0; i < originalName.length(); ++i) {
         if(i > 0 && Character.isUpperCase(originalName.charAt(i))) {
            formattedName.append(' ').append(originalName.charAt(i));
         } else {
            formattedName.append(originalName.charAt(i));
         }
      }

      return formattedName.toString();
   }

   public static IncomeType getEnum(String type) {
      return (IncomeType)getEnum(class$org$commerce$mismo$IncomeType == null?(class$org$commerce$mismo$IncomeType = class$("org.commerce.mismo.IncomeType")):class$org$commerce$mismo$IncomeType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$IncomeType == null?(class$org$commerce$mismo$IncomeType = class$("org.commerce.mismo.IncomeType")):class$org$commerce$mismo$IncomeType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$IncomeType == null?(class$org$commerce$mismo$IncomeType = class$("org.commerce.mismo.IncomeType")):class$org$commerce$mismo$IncomeType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$IncomeType == null?(class$org$commerce$mismo$IncomeType = class$("org.commerce.mismo.IncomeType")):class$org$commerce$mismo$IncomeType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
