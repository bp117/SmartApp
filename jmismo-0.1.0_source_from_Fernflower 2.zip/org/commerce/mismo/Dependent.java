package org.commerce.mismo;


public interface Dependent {

   int getAgeYears();

   void setAgeYears(int var1);
}
