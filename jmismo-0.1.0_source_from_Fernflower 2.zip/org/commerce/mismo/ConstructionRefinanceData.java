package org.commerce.mismo;

import org.commerce.mismo.GSERefinancePurposeType;

public interface ConstructionRefinanceData {

   Float getPropertyOriginalCostAmount();

   void setPropertyOriginalCostAmount(Float var1);

   Float getPropertyExistingLienAmount();

   void setPropertyExistingLienAmount(Float var1);

   GSERefinancePurposeType getGSERefinancePurposeType();

   void setGSERefinancePurposeType(GSERefinancePurposeType var1);
}
