package org.commerce.mismo;

import org.commerce.mismo.LoanDocumentationType;

public interface LoanFeatures {

   LoanDocumentationType getLoanDocumentationType();

   void setLoanDocumentationType(LoanDocumentationType var1);

   String getProductDescription();

   void setProductDescription(String var1);

   String getProductName();

   void setProductName(String var1);

   Boolean getPrepaymentPenaltyIndicator();

   void setPrepaymentPenaltyIndicator(Boolean var1);
}
