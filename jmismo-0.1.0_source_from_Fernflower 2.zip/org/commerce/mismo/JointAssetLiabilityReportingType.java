package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class JointAssetLiabilityReportingType extends Enum {

   public static final JointAssetLiabilityReportingType JOINTLY = new JointAssetLiabilityReportingType("Jointly");
   public static final JointAssetLiabilityReportingType NOT_JOINTLY = new JointAssetLiabilityReportingType("NotJointly");
   static Class class$org$commerce$mismo$JointAssetLiabilityReportingType;


   private JointAssetLiabilityReportingType(String name) {
      super(name);
   }

   public static JointAssetLiabilityReportingType getEnum(String type) {
      return (JointAssetLiabilityReportingType)getEnum(class$org$commerce$mismo$JointAssetLiabilityReportingType == null?(class$org$commerce$mismo$JointAssetLiabilityReportingType = class$("org.commerce.mismo.JointAssetLiabilityReportingType")):class$org$commerce$mismo$JointAssetLiabilityReportingType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$JointAssetLiabilityReportingType == null?(class$org$commerce$mismo$JointAssetLiabilityReportingType = class$("org.commerce.mismo.JointAssetLiabilityReportingType")):class$org$commerce$mismo$JointAssetLiabilityReportingType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$JointAssetLiabilityReportingType == null?(class$org$commerce$mismo$JointAssetLiabilityReportingType = class$("org.commerce.mismo.JointAssetLiabilityReportingType")):class$org$commerce$mismo$JointAssetLiabilityReportingType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$JointAssetLiabilityReportingType == null?(class$org$commerce$mismo$JointAssetLiabilityReportingType = class$("org.commerce.mismo.JointAssetLiabilityReportingType")):class$org$commerce$mismo$JointAssetLiabilityReportingType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
