package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class DispositionStatusType extends Enum {

   public static final DispositionStatusType PENDING_SALE = new DispositionStatusType("PendingSale");
   public static final DispositionStatusType RETAIN_FOR_RENTAL = new DispositionStatusType("RetainForRental");
   public static final DispositionStatusType RETAIN_FOR_PRIMARY_OR_SECONDARY_RESIDENCE = new DispositionStatusType("RetainForPrimaryOrSecondaryResidence");
   public static final DispositionStatusType SOLD = new DispositionStatusType("Sold");
   static Class class$org$commerce$mismo$DispositionStatusType;


   private DispositionStatusType(String name) {
      super(name);
   }

   public static DispositionStatusType getEnum(String type) {
      return (DispositionStatusType)getEnum(class$org$commerce$mismo$DispositionStatusType == null?(class$org$commerce$mismo$DispositionStatusType = class$("org.commerce.mismo.DispositionStatusType")):class$org$commerce$mismo$DispositionStatusType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$DispositionStatusType == null?(class$org$commerce$mismo$DispositionStatusType = class$("org.commerce.mismo.DispositionStatusType")):class$org$commerce$mismo$DispositionStatusType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$DispositionStatusType == null?(class$org$commerce$mismo$DispositionStatusType = class$("org.commerce.mismo.DispositionStatusType")):class$org$commerce$mismo$DispositionStatusType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$DispositionStatusType == null?(class$org$commerce$mismo$DispositionStatusType = class$("org.commerce.mismo.DispositionStatusType")):class$org$commerce$mismo$DispositionStatusType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
