package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class MortgageType extends Enum {

   public static final MortgageType CONVENTIONAL = new MortgageType("Conventional");
   public static final MortgageType FARMERS_HOME_ADMINISTRATION = new MortgageType("FarmersHomeAdministration");
   public static final MortgageType FHA = new MortgageType("FHA");
   public static final MortgageType HELOC = new MortgageType("HELOC");
   public static final MortgageType OTHER = new MortgageType("Other");
   public static final MortgageType VA = new MortgageType("VA");
   static Class class$org$commerce$mismo$MortgageType;


   private MortgageType(String name) {
      super(name);
   }

   public static MortgageType getEnum(String type) {
      return (MortgageType)getEnum(class$org$commerce$mismo$MortgageType == null?(class$org$commerce$mismo$MortgageType = class$("org.commerce.mismo.MortgageType")):class$org$commerce$mismo$MortgageType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$MortgageType == null?(class$org$commerce$mismo$MortgageType = class$("org.commerce.mismo.MortgageType")):class$org$commerce$mismo$MortgageType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$MortgageType == null?(class$org$commerce$mismo$MortgageType = class$("org.commerce.mismo.MortgageType")):class$org$commerce$mismo$MortgageType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$MortgageType == null?(class$org$commerce$mismo$MortgageType = class$("org.commerce.mismo.MortgageType")):class$org$commerce$mismo$MortgageType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
