package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class MaritalStatus extends Enum {

   public static final MaritalStatus MARRIED = new MaritalStatus("Married");
   public static final MaritalStatus NOT_PROVIDED = new MaritalStatus("NotProvided");
   public static final MaritalStatus SEPARATED = new MaritalStatus("Separated");
   public static final MaritalStatus UNKNOWN = new MaritalStatus("Unknown");
   public static final MaritalStatus UNMARRIED = new MaritalStatus("Unmarried");
   static Class class$org$commerce$mismo$MaritalStatus;


   private MaritalStatus(String name) {
      super(name);
   }

   public static MaritalStatus getEnum(String type) {
      return (MaritalStatus)getEnum(class$org$commerce$mismo$MaritalStatus == null?(class$org$commerce$mismo$MaritalStatus = class$("org.commerce.mismo.MaritalStatus")):class$org$commerce$mismo$MaritalStatus, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$MaritalStatus == null?(class$org$commerce$mismo$MaritalStatus = class$("org.commerce.mismo.MaritalStatus")):class$org$commerce$mismo$MaritalStatus);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$MaritalStatus == null?(class$org$commerce$mismo$MaritalStatus = class$("org.commerce.mismo.MaritalStatus")):class$org$commerce$mismo$MaritalStatus);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$MaritalStatus == null?(class$org$commerce$mismo$MaritalStatus = class$("org.commerce.mismo.MaritalStatus")):class$org$commerce$mismo$MaritalStatus);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
