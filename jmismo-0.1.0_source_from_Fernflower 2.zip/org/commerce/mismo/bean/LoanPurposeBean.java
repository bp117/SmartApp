package org.commerce.mismo.bean;

import org.commerce.mismo.ConstructionRefinanceData;
import org.commerce.mismo.LoanPurpose;
import org.commerce.mismo.LoanPurposeType;
import org.commerce.mismo.PropertyRightsType;
import org.commerce.mismo.PropertyUsageType;
import org.commerce.mismo.RefinanceCashOutPurposeType;
import org.commerce.mismo.bean.ConstructionRefinanceDataBean;

public class LoanPurposeBean implements LoanPurpose {

   private Long loanPurposeId;
   private LoanPurposeType loanPurposeType = null;
   private String gseTitleMannerHeldDescription = null;
   private String otherLoanPurposeDescription = null;
   private PropertyUsageType propertyUsageType = null;
   private ConstructionRefinanceData constructionRefinanceData = new ConstructionRefinanceDataBean();
   private PropertyRightsType propertyRights = null;
   private RefinanceCashOutPurposeType refinanceCashOutPurposeType = null;


   public LoanPurposeType getLoanPurposeType() {
      return this.loanPurposeType;
   }

   public void setLoanPurposeType(LoanPurposeType type) {
      this.loanPurposeType = type;
   }

   public String getOtherLoanPurposeDescription() {
      return this.otherLoanPurposeDescription;
   }

   public void setOtherLoanPurposeDescription(String desc) {
      this.otherLoanPurposeDescription = desc;
   }

   public String getGSETitleMannerHeldDescription() {
      return this.gseTitleMannerHeldDescription;
   }

   public void setGSETitleMannerHeldDescription(String desc) {
      this.gseTitleMannerHeldDescription = desc;
   }

   public PropertyUsageType getPropertyUsageType() {
      return this.propertyUsageType;
   }

   public void setPropertyUsageType(PropertyUsageType type) {
      this.propertyUsageType = type;
   }

   public ConstructionRefinanceData getConstructionRefinanceData() {
      return this.constructionRefinanceData;
   }

   public void setConstructionRefinanceData(ConstructionRefinanceData constructionRefinanceData) {
      this.constructionRefinanceData = constructionRefinanceData;
   }

   public PropertyRightsType getPropertyRightsType() {
      return this.propertyRights;
   }

   public void setPropertyRightsType(PropertyRightsType type) {
      this.propertyRights = type;
   }

   public RefinanceCashOutPurposeType getRefinanceCashOutPurposeType() {
      return this.refinanceCashOutPurposeType;
   }

   public void setRefinanceCashOutPurposeType(RefinanceCashOutPurposeType type) {
      this.refinanceCashOutPurposeType = type;
   }

   public Long getLoanPurposeId() {
      return this.loanPurposeId;
   }

   public void setLoanPurposeId(Long loanPurposeId) {
      this.loanPurposeId = loanPurposeId;
   }
}
