package org.commerce.mismo.bean;

import org.commerce.mismo.ARM;
import org.commerce.mismo.LoanFeatures;
import org.commerce.mismo.LoanProductData;
import org.commerce.mismo.bean.ArmBean;
import org.commerce.mismo.bean.LoanFeaturesBean;

class LoanProductDataBean implements LoanProductData {

   private Long loanProductDataId;
   private LoanFeatures loanFeatures = new LoanFeaturesBean();
   private ARM arm = new ArmBean();


   public Long getLoanProductDataId() {
      return this.loanProductDataId;
   }

   public void setLoanProductDataId(Long loanProductDataId) {
      this.loanProductDataId = loanProductDataId;
   }

   public ARM getARM() {
      return this.arm;
   }

   public void setARM(ARM arm) {
      this.arm = arm;
   }

   public LoanFeatures getLoanFeatures() {
      return this.loanFeatures;
   }

   public void setLoanFeatures(LoanFeatures loanFeatures) {
      this.loanFeatures = loanFeatures;
   }
}
