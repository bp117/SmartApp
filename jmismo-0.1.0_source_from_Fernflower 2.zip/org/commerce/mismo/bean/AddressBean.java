package org.commerce.mismo.bean;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.commerce.mismo.Address;
import org.commerce.mismo.bean.MismoUtil;

public class AddressBean implements Address, Serializable {

   static final long serialVersionUID = -6205095102474555946L;
   private Long addressId;
   private String streetAddress = null;
   private String city = null;
   private String state = null;
   private String postalCode = null;
   private String country = null;
   private String streetAddress1;
   private String streetAddress2;


   public Long getAddressId() {
      return this.addressId;
   }

   public String getCity() {
      return this.city;
   }

   public String getCountry() {
      return this.country;
   }

   public String getPostalCode() {
      return this.postalCode;
   }

   public String getState() {
      return this.state;
   }

   public String getStreetAddress() {
      return this.streetAddress;
   }

   public void setAddressId(Long addressId) {
      this.addressId = addressId;
   }

   public void setCity(String city) {
      this.city = city;
   }

   public void setCountry(String country) {
      this.country = country;
   }

   public void setPostalCode(String code) {
      this.postalCode = MismoUtil.toAlphaNumericOnly(code);
   }

   public void setState(String state) {
      this.state = state;
   }

   public void setStreetAddress(String address) {
      this.streetAddress = address;
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }

   public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
   }

   public boolean equals(Object oth) {
      return EqualsBuilder.reflectionEquals(this, oth);
   }

   public String getStreetAddress1() {
      return this.streetAddress1;
   }

   public void setStreetAddress1(String address) {
      this.streetAddress1 = address;
   }

   public String getStreetAddress2() {
      return this.streetAddress2;
   }

   public void setStreetAddress2(String address) {
      this.streetAddress2 = address;
   }
}
