package org.commerce.mismo.bean;

import java.io.Serializable;
import java.util.Date;
import org.commerce.mismo.ResidentAlienCard;

public class ResidentAlienCardBean implements Serializable, ResidentAlienCard {

   static final long serialVersionUID = 3549279179971939743L;
   private Long residentAlienCardId;
   private String cardNumber;
   private Date issueDate;
   private Date expirationDate;


   public Long getResidentAlienCardId() {
      return this.residentAlienCardId;
   }

   public void setResidentAlienCardId(Long residentAlienCardId) {
      this.residentAlienCardId = residentAlienCardId;
   }

   public String getCardNumber() {
      return this.cardNumber;
   }

   public Date getExpirationDate() {
      return this.expirationDate;
   }

   public Date getIssueDate() {
      return this.issueDate;
   }

   public void setCardNumber(String cardNumber) {
      this.cardNumber = cardNumber;
   }

   public void setExpirationDate(Date date) {
      this.expirationDate = date;
   }

   public void setIssueDate(Date date) {
      this.issueDate = date;
   }
}
