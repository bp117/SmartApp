package org.commerce.mismo.bean;

import java.math.BigDecimal;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.enums.Enum;
import org.commerce.mismo.HousingExpenseType;
import org.commerce.mismo.PresentHousingExpense;

class PresentHousingExpenseBean implements PresentHousingExpense {

   private Long presentHousingExpenseId;
   private BigDecimal paymentAmount = null;
   private HousingExpenseType housingExpenseType;


   PresentHousingExpenseBean() {
      this.housingExpenseType = HousingExpenseType.OTHER_HOUSING_EXPENSE;
   }

   public BigDecimal getPaymentAmount() {
      return this.paymentAmount;
   }

   public BigDecimal getAmount() {
      return this.getPaymentAmount();
   }

   public Long getPresentHousingExpenseId() {
      return this.presentHousingExpenseId;
   }

   public void setPresentHousingExpenseId(Long presentHousingExpenseId) {
      this.presentHousingExpenseId = presentHousingExpenseId;
   }

   public void setPaymentAmount(BigDecimal amount) {
      this.paymentAmount = amount;
   }

   public HousingExpenseType getHousingExpenseType() {
      return this.housingExpenseType;
   }

   public Enum getType() {
      return this.getHousingExpenseType();
   }

   public void setHousingExpenseType(HousingExpenseType housingExpenseType) {
      this.housingExpenseType = housingExpenseType;
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }

   public boolean equals(Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
   }

   public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
   }
}
