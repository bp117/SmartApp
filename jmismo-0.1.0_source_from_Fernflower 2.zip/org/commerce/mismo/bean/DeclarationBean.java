package org.commerce.mismo.bean;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.commerce.mismo.CitizenshipResidencyType;
import org.commerce.mismo.Declaration;
import org.commerce.mismo.PriorPropertyTitleType;
import org.commerce.mismo.PriorPropertyUsageType;

public class DeclarationBean implements Declaration {

   private Long declarationId;
   private Boolean alimonyChildSupportObligation;
   private Boolean bankruptcy;
   private Boolean borrowedDownPayment;
   private Boolean borrowerFirstTimeHomebuyer;
   private CitizenshipResidencyType citizenshipResidencyType;
   private Boolean coMakerEndorserOfNote;
   private Boolean homeownerPastThreeYearsType;
   private Boolean intentToOccupyType;
   private Boolean loanForeclosureOrJudgement;
   private Boolean outstandingJudgements;
   private Boolean partyToLawsuit;
   private Boolean presentlyDelinquent;
   private PriorPropertyTitleType priorPropertyTitleType;
   private PriorPropertyUsageType priorPropertyUsageType;
   private Boolean propertyForeclosedPastSevenYears;


   public Long getDeclarationId() {
      return this.declarationId;
   }

   public void setDeclarationId(Long declarationId) {
      this.declarationId = declarationId;
   }

   public Boolean isAlimonyChildSupportObligation() {
      return this.alimonyChildSupportObligation;
   }

   public void setAlimonyChildSupportObligation(Boolean alimonyChildSupportObligation) {
      this.alimonyChildSupportObligation = alimonyChildSupportObligation;
   }

   public Boolean isBankruptcy() {
      return this.bankruptcy;
   }

   public void setBankruptcy(Boolean bankruptcy) {
      this.bankruptcy = bankruptcy;
   }

   public Boolean isBorrowedDownPayment() {
      return this.borrowedDownPayment;
   }

   public void setBorrowedDownPayment(Boolean borrowedDownPayment) {
      this.borrowedDownPayment = borrowedDownPayment;
   }

   public Boolean isBorrowerFirstTimeHomebuyer() {
      return this.borrowerFirstTimeHomebuyer;
   }

   public void setBorrowerFirstTimeHomebuyer(Boolean borrowerFirstTimeHomebuyer) {
      this.borrowerFirstTimeHomebuyer = borrowerFirstTimeHomebuyer;
   }

   public CitizenshipResidencyType getCitizenshipResidencyType() {
      return this.citizenshipResidencyType;
   }

   public void setCitizenshipResidencyType(CitizenshipResidencyType citizenshipResidencyType) {
      this.citizenshipResidencyType = citizenshipResidencyType;
   }

   public Boolean isCoMakerEndorserOfNote() {
      return this.coMakerEndorserOfNote;
   }

   public void setCoMakerEndorserOfNote(Boolean coMakerEndorserOfNote) {
      this.coMakerEndorserOfNote = coMakerEndorserOfNote;
   }

   public Boolean isHomeownerPastThreeYearsType() {
      return this.homeownerPastThreeYearsType;
   }

   public void setHomeownerPastThreeYearsType(Boolean homeownerPastThreeYearsType) {
      this.homeownerPastThreeYearsType = homeownerPastThreeYearsType;
   }

   public Boolean isIntentToOccupyType() {
      return this.intentToOccupyType;
   }

   public void setIntentToOccupyType(Boolean intentToOccupyType) {
      this.intentToOccupyType = intentToOccupyType;
   }

   public Boolean isLoanForeclosureOrJudgement() {
      return this.loanForeclosureOrJudgement;
   }

   public void setLoanForeclosureOrJudgement(Boolean loanForeclosureOrJudgement) {
      this.loanForeclosureOrJudgement = loanForeclosureOrJudgement;
   }

   public Boolean isOutstandingJudgements() {
      return this.outstandingJudgements;
   }

   public void setOutstandingJudgements(Boolean outstandingJudgements) {
      this.outstandingJudgements = outstandingJudgements;
   }

   public Boolean isPartyToLawsuit() {
      return this.partyToLawsuit;
   }

   public void setPartyToLawsuit(Boolean partyToLawsuit) {
      this.partyToLawsuit = partyToLawsuit;
   }

   public Boolean isPresentlyDelinquent() {
      return this.presentlyDelinquent;
   }

   public void setPresentlyDelinquent(Boolean presentlyDelinquent) {
      this.presentlyDelinquent = presentlyDelinquent;
   }

   public PriorPropertyTitleType getPriorPropertyTitleType() {
      return this.priorPropertyTitleType;
   }

   public void setPriorPropertyTitleType(PriorPropertyTitleType priorPropertyTitleType) {
      this.priorPropertyTitleType = priorPropertyTitleType;
   }

   public PriorPropertyUsageType getPriorPropertyUsageType() {
      return this.priorPropertyUsageType;
   }

   public void setPriorPropertyUsageType(PriorPropertyUsageType priorPropertyUsageType) {
      this.priorPropertyUsageType = priorPropertyUsageType;
   }

   public Boolean isPropertyForeclosedPastSevenYears() {
      return this.propertyForeclosedPastSevenYears;
   }

   public void setPropertyForeclosedPastSevenYears(Boolean propertyForeclosedPastSevenYears) {
      this.propertyForeclosedPastSevenYears = propertyForeclosedPastSevenYears;
   }

   public boolean equals(Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
   }

   public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }
}
