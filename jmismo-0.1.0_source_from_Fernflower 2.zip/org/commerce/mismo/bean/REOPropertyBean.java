package org.commerce.mismo.bean;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.apache.commons.lang.enums.Enum;
import org.commerce.mismo.Address;
import org.commerce.mismo.DispositionStatusType;
import org.commerce.mismo.GSEPropertyType;
import org.commerce.mismo.Liability;
import org.commerce.mismo.PropertyUsageType;
import org.commerce.mismo.REOProperty;
import org.commerce.mismo.bean.AddressBean;
import org.commerce.mismo.bean.MultiBorrowerAssociatedEntityBean;

class REOPropertyBean extends MultiBorrowerAssociatedEntityBean implements REOProperty {

   private Long reoPropertyId;
   private Address address = new AddressBean();
   private Set liabilities = new HashSet();
   private DispositionStatusType dispositionStatusType = null;
   private GSEPropertyType gSEPropertyType = null;
   private BigDecimal marketValueAmount = null;
   private BigDecimal lienUnpaidPrincipalBalanceAmount = null;
   private BigDecimal lienInstallmentAmount = null;
   private BigDecimal rentalIncomeGrossAmount = null;
   private BigDecimal rentalIncomeNetAmount = null;
   private BigDecimal maintenanceExpenseAmount = null;
   private boolean currentResidence = false;
   private boolean subject = false;
   private BigDecimal realEstateTaxAmount;
   private BigDecimal hazardInsuranceAmount;
   private BigDecimal otherMonthlyExpenseAmount;
   private Integer numberOfUnits;
   private PropertyUsageType propertyUsageType;


   public Liability[] getLiabilities() {
      Liability[] liabilityArray = new Liability[this.liabilities.size()];
      return (Liability[])this.liabilities.toArray(liabilityArray);
   }

   public Long getReoPropertyId() {
      return this.reoPropertyId;
   }

   public void setReoPropertyId(Long reoPropertyId) {
      this.reoPropertyId = reoPropertyId;
   }

   public void addLiability(Liability liability) {
      if(liability == null) {
         throw new IllegalArgumentException("liability cannot be null");
      } else {
         this.liabilities.add(liability);
      }
   }

   public void removeLiability(Liability liability) {
      if(liability != null) {
         this.liabilities.remove(liability);
      }

   }

   public void setLiabilities(Set liabilities) {
      this.liabilities = liabilities;
   }

   public Address getAddress() {
      return this.address;
   }

   public void setAddress(Address address) {
      this.address = address;
   }

   public DispositionStatusType getDispositionStatusType() {
      return this.dispositionStatusType;
   }

   public void setDispositionStatusType(DispositionStatusType type) {
      this.dispositionStatusType = type;
   }

   public GSEPropertyType getGSEPropertyType() {
      return this.gSEPropertyType;
   }

   public Enum getType() {
      return this.getGSEPropertyType();
   }

   public void setGSEPropertyType(GSEPropertyType type) {
      this.gSEPropertyType = type;
   }

   public BigDecimal getMarketValueAmount() {
      return this.marketValueAmount;
   }

   public void setMarketValueAmount(BigDecimal amount) {
      this.marketValueAmount = amount;
   }

   public BigDecimal getLienUnpaidPrincipalBalanceAmount() {
      return this.lienUnpaidPrincipalBalanceAmount;
   }

   public void setLienUnpaidPrincipalBalanceAmount(BigDecimal amount) {
      this.lienUnpaidPrincipalBalanceAmount = amount;
   }

   public BigDecimal getRentalIncomeGrossAmount() {
      return this.rentalIncomeGrossAmount;
   }

   public void setRentalIncomeGrossAmount(BigDecimal amount) {
      this.rentalIncomeGrossAmount = amount;
   }

   public BigDecimal getLienInstallmentAmount() {
      return this.lienInstallmentAmount;
   }

   public void setLienInstallmentAmount(BigDecimal amount) {
      this.lienInstallmentAmount = amount;
   }

   public BigDecimal getMaintenanceExpenseAmount() {
      return this.maintenanceExpenseAmount;
   }

   public void setMaintenanceExpenseAmount(BigDecimal amount) {
      this.maintenanceExpenseAmount = amount;
   }

   public BigDecimal getRentalIncomeNetAmount() {
      return this.rentalIncomeNetAmount;
   }

   public void setRentalIncomeNetAmount(BigDecimal amount) {
      this.rentalIncomeNetAmount = amount;
   }

   public boolean isCurrentResidence() {
      return this.currentResidence;
   }

   public void setCurrentResidence(boolean isCurrentResidence) {
      this.currentResidence = isCurrentResidence;
   }

   public boolean isSubject() {
      return this.subject;
   }

   public void setSubject(boolean isSubjectProperty) {
      this.subject = isSubjectProperty;
   }

   public BigDecimal getRealEstateTaxAmount() {
      return this.realEstateTaxAmount;
   }

   public void setRealEstateTaxAmount(BigDecimal amount) {
      this.realEstateTaxAmount = amount;
   }

   public BigDecimal getHazardInsuranceAmount() {
      return this.hazardInsuranceAmount;
   }

   public void setHazardInsuranceAmount(BigDecimal amount) {
      this.hazardInsuranceAmount = amount;
   }

   public BigDecimal getOtherMonthlyExpenseAmount() {
      return this.otherMonthlyExpenseAmount;
   }

   public void setOtherMonthlyExpenseAmount(BigDecimal amount) {
      this.otherMonthlyExpenseAmount = amount;
   }

   public Integer getNumberOfUnits() {
      return this.numberOfUnits;
   }

   public void setNumberOfUnits(Integer unitCount) {
      this.numberOfUnits = unitCount;
   }

   public String toString() {
      return (new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)).append("address", this.address).append("dispositionStatusType", this.dispositionStatusType).append("gsePropertyType", this.gSEPropertyType).append("marketValueAmount", this.marketValueAmount).append("lienUnpaidPrincipalBalanceAmount", this.lienUnpaidPrincipalBalanceAmount).append("lienInstallmentAmount", this.lienInstallmentAmount).append("rentalIncomeGrossAmount", this.rentalIncomeGrossAmount).append("rentalIncomeNetAmount", this.rentalIncomeNetAmount).append("maintenanceExpenseAmount", this.maintenanceExpenseAmount).append("realEstateTaxAmount", this.realEstateTaxAmount).append("hazardInsuranceAmount", this.hazardInsuranceAmount).append("otherMonthlyExpenseAmount", this.otherMonthlyExpenseAmount).append("isCurrentResidence", this.currentResidence).append("isSubjectProperty", this.subject).append("numberOfUnits", this.numberOfUnits).append("liabilities", this.getLiabilities(), false).toString();
   }

   public boolean equals(Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
   }

   public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
   }

   public PropertyUsageType getPropertyUsageType() {
      return this.propertyUsageType;
   }

   public void setPropertyUsageType(PropertyUsageType type) {
      this.propertyUsageType = type;
   }
}
