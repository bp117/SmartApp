package org.commerce.mismo.bean;

import java.math.BigDecimal;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.commerce.mismo.Address;
import org.commerce.mismo.Employer;
import org.commerce.mismo.bean.AddressBean;

public class EmployerBean implements Employer {

   private Long employerId;
   private Address address = new AddressBean();
   private String name = null;
   private boolean selfEmployed = false;
   private int yearsOnJob = 0;
   private int monthsOnJob = 0;
   private int timeInLineOfWork = 0;
   private BigDecimal monthlyIncome = null;
   private String employmentPositionDescription = null;
   private Date previousEmploymentStartDate = null;
   private Date previousEmploymentEndDate = null;
   private String telephoneNumber;
   private boolean current = false;
   private boolean employmentPrimaryIndicator;


   public Long getEmployerId() {
      return this.employerId;
   }

   public void setEmployerId(Long employerId) {
      this.employerId = employerId;
   }

   public String getName() {
      return this.name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public Address getAddress() {
      return this.address;
   }

   public void setAddress(Address address) {
      this.address = address;
   }

   public boolean isSelfEmployed() {
      return this.selfEmployed;
   }

   public void setSelfEmployed(boolean b) {
      this.selfEmployed = b;
   }

   public int getYearsOnJob() {
      return this.yearsOnJob;
   }

   public void setYearsOnJob(int yearsOnJob) {
      this.yearsOnJob = yearsOnJob;
   }

   public int getMonthsOnJob() {
      return this.monthsOnJob;
   }

   public void setMonthsOnJob(int monthsOnJob) {
      this.monthsOnJob = monthsOnJob;
   }

   public int getTimeInLineOfWork() {
      return this.timeInLineOfWork;
   }

   public void setTimeInLineOfWork(int years) {
      this.timeInLineOfWork = years;
   }

   public BigDecimal getMonthlyIncome() {
      return this.monthlyIncome;
   }

   public void setMonthlyIncome(BigDecimal amount) {
      this.monthlyIncome = amount;
   }

   public String getEmploymentPositionDescription() {
      return this.employmentPositionDescription;
   }

   public void setEmploymentPositionDescription(String description) {
      this.employmentPositionDescription = description;
   }

   public Date getPreviousEmploymentStartDate() {
      return this.previousEmploymentStartDate;
   }

   public void setPreviousEmploymentStartDate(Date startDate) {
      this.previousEmploymentStartDate = startDate;
   }

   public Date getPreviousEmploymentEndDate() {
      return this.previousEmploymentEndDate;
   }

   public void setPreviousEmploymentEndDate(Date endDate) {
      this.previousEmploymentEndDate = endDate;
   }

   public String getTelephoneNumber() {
      return this.telephoneNumber;
   }

   public void setTelephoneNumber(String number) {
      this.telephoneNumber = number;
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }

   public boolean equals(Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
   }

   public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
   }

   public boolean isCurrent() {
      return this.current;
   }

   public void setCurrent(boolean current) {
      this.current = current;
   }

   public boolean getEmploymentPrimaryIndicator() {
      return this.employmentPrimaryIndicator;
   }

   public void setEmploymentPrimaryIndicator(boolean isPrimary) {
      this.employmentPrimaryIndicator = isPrimary;
   }
}
