package org.commerce.mismo.bean;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.commerce.mismo.ARM;

class ArmBean implements ARM {

   private Long armId;
   private Float indexCurrentValuePercent;
   private Float indexMarginPercent;
   private Float paymentAdjustmentLifetimeCapAmount;
   private Float paymentAdjustmentLifetimeCapPercent;
   private Float qualifyingRatePercent;
   private Float rateAdjustmentLifetimeCapPercent;
   private Boolean conversionOptionIndicator;


   public Long getArmId() {
      return this.armId;
   }

   public void setArmId(Long armId) {
      this.armId = armId;
   }

   public Float getIndexCurrentValuePercent() {
      return this.indexCurrentValuePercent;
   }

   public void setIndexCurrentValuePercent(Float value) {
      this.indexCurrentValuePercent = value;
   }

   public Float getIndexMarginPercent() {
      return this.indexMarginPercent;
   }

   public void setIndexMarginPercent(Float value) {
      this.indexMarginPercent = value;
   }

   public Float getPaymentAdjustmentLifetimeCapAmount() {
      return this.paymentAdjustmentLifetimeCapAmount;
   }

   public void setPaymentAdjustmentLifetimeCapAmount(Float cap) {
      this.paymentAdjustmentLifetimeCapAmount = cap;
   }

   public Float getPaymentAdjustmentLifetimeCapPercent() {
      return this.paymentAdjustmentLifetimeCapPercent;
   }

   public void setPaymentAdjustmentLifetimeCapPercent(Float cap) {
      this.paymentAdjustmentLifetimeCapPercent = cap;
   }

   public Float getQualifyingRatePercent() {
      return this.qualifyingRatePercent;
   }

   public void setQualifyingRatePercent(Float rate) {
      this.qualifyingRatePercent = rate;
   }

   public Float getRateAdjustmentLifetimeCapPercent() {
      return this.rateAdjustmentLifetimeCapPercent;
   }

   public void setRateAdjustmentLifetimeCapPercent(Float cap) {
      this.rateAdjustmentLifetimeCapPercent = cap;
   }

   public Boolean getConversionOptionIndicator() {
      return this.conversionOptionIndicator;
   }

   public void setConversionOptionIndicator(Boolean conversionOptionIndicator) {
      this.conversionOptionIndicator = conversionOptionIndicator;
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }

   public boolean equals(Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
   }

   public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
   }
}
