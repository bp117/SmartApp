package org.commerce.mismo.bean;

import java.io.Serializable;
import org.commerce.mismo.HMDARace;
import org.commerce.mismo.HMDARaceType;

public class HMDARaceBean implements Serializable, HMDARace {

   private HMDARaceType type = null;


   public HMDARaceType getType() {
      return this.type;
   }

   public void setType(HMDARaceType hmdaRace) {
      this.type = hmdaRace;
   }
}
