package org.commerce.mismo.bean;

import java.math.BigDecimal;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.enums.Enum;
import org.commerce.mismo.Address;
import org.commerce.mismo.Asset;
import org.commerce.mismo.AssetType;
import org.commerce.mismo.bean.AddressBean;
import org.commerce.mismo.bean.MultiBorrowerAssociatedEntityBean;

public class AssetBean extends MultiBorrowerAssociatedEntityBean implements Asset {

   private Long assetId;
   private String accountIdentifier = null;
   private BigDecimal cashOrMarketValueAmount = null;
   private AssetType assetType = null;
   private String automobileMakeDescription = null;
   private String automobileModelYear = null;
   private BigDecimal lifeInsuranceFaceValueAmount = null;
   private String otherAssetTypeDescription = null;
   private String holder = null;
   private Address holderAddress = new AddressBean();
   private Boolean verifiedIndicator = null;


   public Long getAssetId() {
      return this.assetId;
   }

   public void setAssetId(Long assetId) {
      this.assetId = assetId;
   }

   public String getAccountIdentifier() {
      return this.accountIdentifier;
   }

   public void setAccountIdentifier(String identifier) {
      this.accountIdentifier = identifier;
   }

   public BigDecimal getCashOrMarketValueAmount() {
      return this.cashOrMarketValueAmount;
   }

   public BigDecimal getAmount() {
      return this.getCashOrMarketValueAmount();
   }

   public void setCashOrMarketValueAmount(BigDecimal amount) {
      this.cashOrMarketValueAmount = amount;
   }

   public AssetType getAssetType() {
      return this.assetType;
   }

   public void setAssetType(AssetType assetType) {
      this.assetType = assetType;
   }

   public Enum getType() {
      return this.getAssetType();
   }

   public void setType(AssetType assetType) {
      this.assetType = assetType;
   }

   public String getAutomobileMakeDescription() {
      return this.automobileMakeDescription;
   }

   public void setAutomobileMakeDescription(String make) {
      this.automobileMakeDescription = make;
   }

   public String getAutomobileModelYear() {
      return this.automobileModelYear;
   }

   public void setAutomobileModelYear(String year) {
      this.automobileModelYear = year;
   }

   public BigDecimal getLifeInsuranceFaceValueAmount() {
      return this.lifeInsuranceFaceValueAmount;
   }

   public void setLifeInsuranceFaceValueAmount(BigDecimal amount) {
      this.lifeInsuranceFaceValueAmount = amount;
   }

   public String getOtherAssetTypeDescription() {
      return this.otherAssetTypeDescription;
   }

   public void setOtherAssetTypeDescription(String description) {
      this.otherAssetTypeDescription = description;
   }

   public String getHolder() {
      return this.holder;
   }

   public void setHolder(String holder) {
      this.holder = holder;
   }

   public Address getHolderAddress() {
      return this.holderAddress;
   }

   public void setHolderAddress(Address address) {
      this.holderAddress = address;
   }

   public Boolean getVerifiedIndicator() {
      return this.verifiedIndicator;
   }

   public void setVerifiedIndicator(Boolean verifiedIndicator) {
      this.verifiedIndicator = verifiedIndicator;
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }
}
