package org.commerce.mismo.bean;

import java.util.HashSet;
import java.util.Set;
import org.commerce.mismo.Payment;
import org.commerce.mismo.RespaFee;
import org.commerce.mismo.RespaSectionClassificationType;
import org.commerce.mismo.RespaType;
import org.commerce.mismo.ResponsiblePartyType;
import org.commerce.mismo.bean.PaymentBean;

class RespaFeeBean implements RespaFee {

   private Long respaFeeId;
   private RespaSectionClassificationType respaSectionClassificationType;
   private String paidToName;
   private ResponsiblePartyType responsiblePartyType;
   private String specifiedHUDLineNumber;
   private RespaType type;
   private String otherTypeDescription;
   private Set payments = new HashSet();


   public RespaSectionClassificationType getRespaSectionClassificationType() {
      return this.respaSectionClassificationType;
   }

   public Long getRespaFeeId() {
      return this.respaFeeId;
   }

   public void setRespaFeeId(Long respaFeeId) {
      this.respaFeeId = respaFeeId;
   }

   public void setRespaSectionClassificationType(RespaSectionClassificationType type) {
      this.respaSectionClassificationType = type;
   }

   public String getPaidToName() {
      return this.paidToName;
   }

   public void setPaidToName(String name) {
      this.paidToName = name;
   }

   public ResponsiblePartyType getResponsiblePartyType() {
      return this.responsiblePartyType;
   }

   public void setResponsiblePartyType(ResponsiblePartyType type) {
      this.responsiblePartyType = type;
   }

   public String getSpecifiedHUDLineNumber() {
      return this.specifiedHUDLineNumber;
   }

   public void setSpecifiedHUDLineNumber(String lineNumber) {
      this.specifiedHUDLineNumber = lineNumber;
   }

   public RespaType getType() {
      return this.type;
   }

   public void setType(RespaType type) {
      this.type = type;
   }

   public String getOtherTypeDescription() {
      return this.otherTypeDescription;
   }

   public void setOtherTypeDescription(String otherDescription) {
      this.otherTypeDescription = otherDescription;
   }

   public Payment[] getPayments() {
      Payment[] paymentArray = new Payment[this.payments.size()];
      return (Payment[])this.payments.toArray(paymentArray);
   }

   public void addPayment(Payment payment) {
      if(payment == null) {
         throw new IllegalArgumentException("payment cannot be null");
      } else {
         this.payments.add(payment);
      }
   }

   public void removePayment(Payment payment) {
      this.payments.remove(payment);
   }

   public Payment createPayment() {
      return new PaymentBean();
   }

   public void setPayments(Set payments) {
      this.payments = payments;
   }
}
