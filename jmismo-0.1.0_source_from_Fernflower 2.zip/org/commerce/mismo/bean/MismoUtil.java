package org.commerce.mismo.bean;


class MismoUtil {

   public static String toAlphaNumericOnly(String s) {
      if(s == null) {
         return null;
      } else {
         StringBuffer out = new StringBuffer(s.length());

         for(int i = 0; i < s.length(); ++i) {
            char c = s.charAt(i);
            if(Character.isLetterOrDigit(c)) {
               out.append(c);
            }
         }

         return out.toString();
      }
   }
}
