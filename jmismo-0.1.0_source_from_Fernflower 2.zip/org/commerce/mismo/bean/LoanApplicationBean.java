package org.commerce.mismo.bean;

import java.util.HashSet;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.commerce.mismo.AdditionalCaseData;
import org.commerce.mismo.ApplicationMethodTakenType;
import org.commerce.mismo.Asset;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.DownPayment;
import org.commerce.mismo.GovernmentReporting;
import org.commerce.mismo.InterviewerInformation;
import org.commerce.mismo.Liability;
import org.commerce.mismo.LoanApplication;
import org.commerce.mismo.LoanProductData;
import org.commerce.mismo.LoanPurpose;
import org.commerce.mismo.MortgageTerms;
import org.commerce.mismo.Property;
import org.commerce.mismo.ProposedHousingExpense;
import org.commerce.mismo.REOProperty;
import org.commerce.mismo.RespaFee;
import org.commerce.mismo.TransactionDetail;
import org.commerce.mismo.bean.AdditionalCaseDataBean;
import org.commerce.mismo.bean.AssetBean;
import org.commerce.mismo.bean.BorrowerBean;
import org.commerce.mismo.bean.DownPaymentBean;
import org.commerce.mismo.bean.InterviewerInformationBean;
import org.commerce.mismo.bean.LiabilityBean;
import org.commerce.mismo.bean.LoanProductDataBean;
import org.commerce.mismo.bean.LoanPurposeBean;
import org.commerce.mismo.bean.MortgageTermsBean;
import org.commerce.mismo.bean.PropertyBean;
import org.commerce.mismo.bean.ProposedHousingExpenseBean;
import org.commerce.mismo.bean.REOPropertyBean;
import org.commerce.mismo.bean.RespaFeeBean;
import org.commerce.mismo.bean.TransactionDetailBean;

public class LoanApplicationBean implements LoanApplication {

   private Long loanApplicationId;
   private Set borrowers = new HashSet();
   private Set assets = new HashSet();
   private Set liabilities = new HashSet();
   private Set reoProperties = new HashSet();
   private Set downPayments = new HashSet();
   private AdditionalCaseData additionalCaseData = new AdditionalCaseDataBean();
   private LoanProductData loanProductData = new LoanProductDataBean();
   private MortgageTerms mortgageTerms = new MortgageTermsBean();
   private Property property = null;
   private LoanPurpose loanPurpose = null;
   private GovernmentReporting governmentReporting = null;
   private TransactionDetail transactionDetail = new TransactionDetailBean();
   private Set proposedHousingExpenses = new HashSet();
   private Set respaFees = new HashSet();
   private String mismoVersionId;


   public Long getLoanApplicationId() {
      return this.loanApplicationId;
   }

   public void setLoanApplicationId(Long loanApplicationId) {
      this.loanApplicationId = loanApplicationId;
   }

   public Borrower[] getBorrowers() {
      Borrower[] borrowerArray = new Borrower[this.borrowers.size()];
      return (Borrower[])this.borrowers.toArray(borrowerArray);
   }

   public void addBorrower(Borrower borrower) {
      if(borrower == null) {
         throw new IllegalArgumentException("borrower cannot be null");
      } else {
         this.borrowers.add(borrower);
      }
   }

   public void removeBorrower(Borrower borrower) {
      if(borrower != null) {
         this.borrowers.remove(borrower);
      }

   }

   public void addAsset(Asset asset) {
      if(asset == null) {
         throw new IllegalArgumentException("Asset cannot be null");
      } else {
         this.assets.add(asset);
      }
   }

   public Asset createAsset() {
      return new AssetBean();
   }

   public void addDownPayment(DownPayment payment) {
      if(payment == null) {
         throw new IllegalArgumentException("downPayment cannot be null");
      } else {
         this.downPayments.add(payment);
      }
   }

   public void addLiability(Liability liability) {
      if(liability == null) {
         throw new IllegalArgumentException("liability cannot be null");
      } else {
         this.liabilities.add(liability);
      }
   }

   public InterviewerInformation getInterviewerInformation() {
      InterviewerInformationBean ii = new InterviewerInformationBean();
      ii.setApplicationMethodTakenType(ApplicationMethodTakenType.INTERNET);
      return ii;
   }

   public Liability[] getLiabilities() {
      Liability[] liabilityArray = new Liability[this.liabilities.size()];
      return (Liability[])this.liabilities.toArray(liabilityArray);
   }

   public void removeLiability(Liability liability) {
      if(liability != null) {
         this.liabilities.remove(liability);
      }

   }

   public Liability createLiability() {
      return new LiabilityBean();
   }

   public Borrower createBorrower() {
      return new BorrowerBean();
   }

   public Asset[] getAssets() {
      Asset[] assetArray = new Asset[this.assets.size()];
      return (Asset[])this.assets.toArray(assetArray);
   }

   public DownPayment[] getDownPayments() {
      DownPayment[] downPaymentArray = new DownPayment[this.downPayments.size()];
      return (DownPayment[])this.downPayments.toArray(downPaymentArray);
   }

   public DownPayment createDownPayment() {
      return new DownPaymentBean();
   }

   public LoanPurpose getLoanPurpose() {
      return this.loanPurpose;
   }

   public MortgageTerms getMortgageTerms() {
      return this.mortgageTerms;
   }

   public Property getProperty() {
      return this.property;
   }

   public void addREOProperty(REOProperty property) {
      if(property == null) {
         throw new IllegalArgumentException("property cannot be null");
      } else {
         this.reoProperties.add(property);
      }
   }

   public REOProperty createREOProperty() {
      return new REOPropertyBean();
   }

   public REOProperty[] getReoProperties() {
      REOProperty[] propertyArray = new REOProperty[this.reoProperties.size()];
      return (REOProperty[])this.reoProperties.toArray(propertyArray);
   }

   public void removeREOProperty(REOProperty property) {
      if(property != null) {
         this.reoProperties.remove(property);
      }

   }

   public AdditionalCaseData getAdditionalCaseData() {
      return this.additionalCaseData;
   }

   public void setAdditionalCaseData(AdditionalCaseData additionalCaseData) {
      this.additionalCaseData = additionalCaseData;
   }

   public LoanProductData getLoanProductData() {
      return this.loanProductData;
   }

   public void setLoanProductData(LoanProductData loanProductData) {
      this.loanProductData = loanProductData;
   }

   public LoanPurpose createLoanPurpose() {
      return new LoanPurposeBean();
   }

   public Property createProperty() {
      return new PropertyBean();
   }

   public void setLiabilities(Set liabilities) {
      this.liabilities = liabilities;
   }

   public void setDownPayments(Set downPayments) {
      this.downPayments = downPayments;
   }

   public void setAssets(Set assets) {
      this.assets = assets;
   }

   public void setReoProperties(Set reoProperties) {
      this.reoProperties = reoProperties;
   }

   public void setRespaFees(Set respaFees) {
      this.respaFees = respaFees;
   }

   public void setProposedHousingExpenses(Set proposedHousingExpenses) {
      this.proposedHousingExpenses = proposedHousingExpenses;
   }

   public void setBorrowers(Set borrowers) {
      this.borrowers = borrowers;
   }

   public void setMortgageTerms(MortgageTerms mortgageTerms) {
      this.mortgageTerms = mortgageTerms;
   }

   public void setTransactionDetail(TransactionDetail transactionDetail) {
      this.transactionDetail = transactionDetail;
   }

   public void setLoanPurpose(LoanPurpose purpose) {
      this.loanPurpose = purpose;
   }

   public void setProperty(Property property) {
      this.property = property;
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }

   public boolean equals(Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
   }

   public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
   }

   public TransactionDetail getTransactionDetail() {
      return this.transactionDetail;
   }

   public void addProposedHousingExpense(ProposedHousingExpense expense) {
      if(expense == null) {
         throw new IllegalArgumentException("expense cannot be null");
      } else {
         this.proposedHousingExpenses.add(expense);
      }
   }

   public ProposedHousingExpense createProposedHousingExpense() {
      return new ProposedHousingExpenseBean();
   }

   public ProposedHousingExpense[] getProposedHousingExpenses() {
      ProposedHousingExpense[] expenseArray = new ProposedHousingExpense[this.proposedHousingExpenses.size()];
      return (ProposedHousingExpense[])this.proposedHousingExpenses.toArray(expenseArray);
   }

   public void addRespaFee(RespaFee fee) {
      if(fee == null) {
         throw new IllegalArgumentException("Fee cannot be null");
      } else {
         this.respaFees.add(fee);
      }
   }

   public RespaFee createRespaFee() {
      return new RespaFeeBean();
   }

   public RespaFee[] getRespaFees() {
      RespaFee[] fees = new RespaFee[this.respaFees.size()];
      return (RespaFee[])this.respaFees.toArray(fees);
   }

   public String getMismoVersionId() {
      return this.mismoVersionId;
   }

   public void setMismoVersionId(String mismoVersionId) {
      this.mismoVersionId = mismoVersionId;
   }

   public GovernmentReporting getGovernmentReporting() {
      return this.governmentReporting;
   }

   public void setGovernmentReporting(GovernmentReporting reporting) {
      this.governmentReporting = reporting;
   }
}
