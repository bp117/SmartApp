package org.commerce.mismo.bean;

import java.util.HashSet;
import java.util.Set;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.MultiBorrowerAssociatedEntity;

class MultiBorrowerAssociatedEntityBean implements MultiBorrowerAssociatedEntity {

   private Set borrowers = new HashSet();


   public Borrower[] getBorrowers() {
      Borrower[] borrowerArray = new Borrower[this.borrowers.size()];
      return (Borrower[])this.borrowers.toArray(borrowerArray);
   }

   public void addBorrower(Borrower borrower) {
      if(borrower == null) {
         throw new IllegalArgumentException("borrower cannot be null");
      } else {
         this.borrowers.add(borrower);
      }
   }

   public void removeBorrower(Borrower borrower) {
      if(borrower != null) {
         this.borrowers.remove(borrower);
      }

   }

   public void setBorrowers(Set borrowers) {
      this.borrowers = borrowers;
   }
}
