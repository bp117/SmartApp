package org.commerce.mismo.bean;

import org.commerce.mismo.Asset;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.Employer;
import org.commerce.mismo.Property;
import org.commerce.mismo.bean.AssetBean;
import org.commerce.mismo.bean.BorrowerBean;
import org.commerce.mismo.bean.EmployerBean;
import org.commerce.mismo.bean.PropertyBean;

public class WizardLoanAppFormBean {

   private Long LoanApplicationId;
   private Borrower borrower = new BorrowerBean();
   private Asset asset = null;
   private Property property = new PropertyBean();
   private Employer employer = new EmployerBean();
   private String propertyUsage;
   private String purposeType;
   private String accountType;
   private String propertyType;
   private String propertyState;


   public WizardLoanAppFormBean() {
      this.asset = new AssetBean();
   }

   public Property getProperty() {
      return this.property;
   }

   public void setPrperty(Property property) {
      this.property = property;
   }

   public Employer getEmployer() {
      return this.employer;
   }

   public void setEmployer(Employer employer) {
      this.employer = employer;
   }

   public Borrower getBorrower() {
      return this.borrower;
   }

   public void setBorrower(Borrower borrower) {
      this.borrower = borrower;
   }

   public Asset getAsset() {
      return this.asset;
   }

   public void setAsset(Asset asset) {
      this.asset = asset;
   }

   public Long getLoanApplicationId() {
      return this.LoanApplicationId;
   }

   public void setLoanApplicationId(Long loanApplicationId) {
      this.LoanApplicationId = loanApplicationId;
   }

   public String getPropertyUsage() {
      return this.propertyUsage;
   }

   public void setPropertyUsage(String propertyUsage) {
      this.propertyUsage = propertyUsage;
   }

   public String getPurposeType() {
      return this.purposeType;
   }

   public void setPurposeType(String purposeType) {
      this.purposeType = purposeType;
   }

   public String getPropertyType() {
      return this.propertyType;
   }

   public void setPropertyType(String propertyType) {
      this.propertyType = propertyType;
   }

   public String getAccountType() {
      return this.accountType;
   }

   public void setAccountType(String accountType) {
      this.accountType = accountType;
   }

   public String getPropertyState() {
      return this.propertyState;
   }

   public void setPropertyState(String propertyState) {
      this.propertyState = propertyState;
   }
}
