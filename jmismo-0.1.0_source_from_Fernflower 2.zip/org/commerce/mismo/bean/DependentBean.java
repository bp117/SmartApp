package org.commerce.mismo.bean;

import org.commerce.mismo.Dependent;

public class DependentBean implements Dependent {

   private Long dependentId;
   private int ageYears;


   public Long getDependentId() {
      return this.dependentId;
   }

   public int getAgeYears() {
      return this.ageYears;
   }

   public void setDependentId(Long dependentId) {
      this.dependentId = dependentId;
   }

   public void setAgeYears(int ageYears) {
      this.ageYears = ageYears;
   }
}
