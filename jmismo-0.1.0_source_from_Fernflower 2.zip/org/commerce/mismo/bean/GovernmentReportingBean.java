package org.commerce.mismo.bean;

import org.commerce.mismo.GovernmentReporting;
import org.commerce.mismo.HMDAPurposeOfLoanType;

public class GovernmentReportingBean implements GovernmentReporting {

   private Long governmentReportingId;
   private HMDAPurposeOfLoanType purpose = null;


   public Long getGovernmentReportingId() {
      return this.governmentReportingId;
   }

   public void setGovernmentReportingId(Long governmentReportingId) {
      this.governmentReportingId = governmentReportingId;
   }

   public void setHMDAPurposeOfLoanType(HMDAPurposeOfLoanType purpose) {
      this.purpose = purpose;
   }

   public HMDAPurposeOfLoanType getHMDAPurposeOfLoanType() {
      return this.purpose;
   }
}
