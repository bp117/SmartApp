package org.commerce.mismo.bean;

import java.math.BigDecimal;
import java.util.Date;
import org.commerce.mismo.LoanAmortizationType;
import org.commerce.mismo.MortgageTerms;
import org.commerce.mismo.MortgageType;

class MortgageTermsBean implements MortgageTerms {

   private Long mortgageTermsId;
   private BigDecimal baseLoanAmount = null;
   private BigDecimal borrowerRequestedLoanAmount = null;
   private int loanAmortizationTermMonths = 0;
   private LoanAmortizationType loanAmortizationType = null;
   private MortgageType mortgageType = null;
   private String agencyCaseIdentifier = null;
   private Float requestedInterestRatePercent = null;
   private Boolean hazardInsuranceImpoundIndicator;
   private Boolean realEstateTaxImpoundIndicator;
   private Date loanEstimatedClosingDate;


   public Long getMortgageTermsId() {
      return this.mortgageTermsId;
   }

   public void setMortgageTermsId(Long mortgageTermsId) {
      this.mortgageTermsId = mortgageTermsId;
   }

   public BigDecimal getBaseLoanAmount() {
      return this.baseLoanAmount;
   }

   public void setBaseLoanAmount(BigDecimal amount) {
      this.baseLoanAmount = amount;
   }

   public BigDecimal getBorrowerRequestedLoanAmount() {
      return this.borrowerRequestedLoanAmount;
   }

   public void setBorrowerRequestedLoanAmount(BigDecimal amount) {
      this.borrowerRequestedLoanAmount = amount;
   }

   public int getLoanAmortizationTermMonths() {
      return this.loanAmortizationTermMonths;
   }

   public void setLoanAmortizationTermMonths(int term) {
      this.loanAmortizationTermMonths = term;
   }

   public LoanAmortizationType getLoanAmortizationType() {
      return this.loanAmortizationType;
   }

   public void setLoanAmortizationType(LoanAmortizationType amortType) {
      this.loanAmortizationType = amortType;
   }

   public MortgageType getMortgageType() {
      return this.mortgageType;
   }

   public void setMortgageType(MortgageType type) {
      this.mortgageType = type;
   }

   public String getAgencyCaseIdentifier() {
      return this.agencyCaseIdentifier;
   }

   public void setAgencyCaseIdentifier(String applicationId) {
      this.agencyCaseIdentifier = applicationId;
   }

   public Float getRequestedInterestRatePercent() {
      return this.requestedInterestRatePercent;
   }

   public void setRequestedInterestRatePercent(Float value) {
      this.requestedInterestRatePercent = value;
   }

   public Boolean getHazardInsuranceImpoundIndicator() {
      return this.hazardInsuranceImpoundIndicator;
   }

   public void setHazardInsuranceImpoundIndicator(Boolean hazardInsuranceImpoundIndicator) {
      this.hazardInsuranceImpoundIndicator = hazardInsuranceImpoundIndicator;
   }

   public Boolean getRealEstateTaxImpoundIndicator() {
      return this.realEstateTaxImpoundIndicator;
   }

   public void setRealEstateTaxImpoundIndicator(Boolean realEstateTaxImpoundIndicator) {
      this.realEstateTaxImpoundIndicator = realEstateTaxImpoundIndicator;
   }

   public Date getLoanEstimatedClosingDate() {
      return this.loanEstimatedClosingDate;
   }

   public void setLoanEstimatedClosingDate(Date date) {
      this.loanEstimatedClosingDate = date;
   }
}
