package org.commerce.mismo.bean;

import org.commerce.mismo.Asset;
import org.commerce.mismo.Liability;
import org.commerce.mismo.LoanApplication;
import org.commerce.mismo.MismoFactory;
import org.commerce.mismo.bean.AssetBean;
import org.commerce.mismo.bean.LiabilityBean;
import org.commerce.mismo.bean.LoanApplicationBean;

public class BeanMismoFactory implements MismoFactory {

   public LoanApplication createLoanApplication() {
      return new LoanApplicationBean();
   }

   public Asset createAsset() {
      return new AssetBean();
   }

   public Liability createLiability() {
      return new LiabilityBean();
   }
}
