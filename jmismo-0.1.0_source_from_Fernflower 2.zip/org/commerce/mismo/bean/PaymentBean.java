package org.commerce.mismo.bean;

import java.math.BigDecimal;
import org.commerce.mismo.PaidByType;
import org.commerce.mismo.Payment;

class PaymentBean implements Payment {

   private Long paymentId;
   private BigDecimal amount;
   private PaidByType paidBy;
   private Float paymentPercent;


   public Long getPaymentId() {
      return this.paymentId;
   }

   public void setPaymentId(Long paymentId) {
      this.paymentId = paymentId;
   }

   public BigDecimal getAmount() {
      return this.amount;
   }

   public void setAmount(BigDecimal amount) {
      this.amount = amount;
   }

   public PaidByType getPaidBy() {
      return this.paidBy;
   }

   public void setPaidBy(PaidByType party) {
      this.paidBy = party;
   }

   public Float getPaymentPercent() {
      return this.paymentPercent;
   }

   public void setPaymentPercent(Float percent) {
      this.paymentPercent = percent;
   }
}
