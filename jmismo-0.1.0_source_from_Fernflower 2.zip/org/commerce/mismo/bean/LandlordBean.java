package org.commerce.mismo.bean;

import org.commerce.mismo.Address;
import org.commerce.mismo.ContactDetail;
import org.commerce.mismo.Landlord;
import org.commerce.mismo.bean.AddressBean;
import org.commerce.mismo.bean.BaseBean;
import org.commerce.mismo.bean.ContactDetailBean;

class LandlordBean extends BaseBean implements Landlord {

   private Long landlordId;
   private String name = null;
   private Address address = new AddressBean();
   private ContactDetail contactDetail = new ContactDetailBean();


   public Long getLandlordId() {
      return this.landlordId;
   }

   public void setLandlordId(Long landlordId) {
      this.landlordId = landlordId;
   }

   public String getName() {
      return this.name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public Address getAddress() {
      return this.address;
   }

   public void setAddress(Address address) {
      this.address = address;
   }

   public ContactDetail getContactDetail() {
      return this.contactDetail;
   }

   public void setContactDetail(ContactDetail contactDetail) {
      this.contactDetail = contactDetail;
   }
}
