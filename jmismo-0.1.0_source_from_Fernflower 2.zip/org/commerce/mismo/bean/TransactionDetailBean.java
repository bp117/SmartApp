package org.commerce.mismo.bean;

import java.math.BigDecimal;
import org.commerce.mismo.TransactionDetail;

class TransactionDetailBean implements TransactionDetail {

   private Long transactionDetailId;
   private Float estimatedClosingCostsAmount = null;
   private Float purchasePriceAmount = null;
   private BigDecimal refinanceIncludingDebtsToBePaidOffAmount;


   public Long getTransactionDetailId() {
      return this.transactionDetailId;
   }

   public void setTransactionDetailId(Long transactionDetailId) {
      this.transactionDetailId = transactionDetailId;
   }

   public Float getEstimatedClosingCostsAmount() {
      return this.estimatedClosingCostsAmount;
   }

   public void setEstimatedClosingCostsAmount(Float amount) {
      this.estimatedClosingCostsAmount = amount;
   }

   public Float getPurchasePriceAmount() {
      return this.purchasePriceAmount;
   }

   public void setPurchasePriceAmount(Float amount) {
      this.purchasePriceAmount = amount;
   }

   public BigDecimal getRefinanceIncludingDebtsToBePaidOffAmount() {
      return this.refinanceIncludingDebtsToBePaidOffAmount;
   }

   public void setRefinanceIncludingDebtsToBePaidOffAmount(BigDecimal amount) {
      this.refinanceIncludingDebtsToBePaidOffAmount = amount;
   }
}
