package org.commerce.mismo.bean;

import org.commerce.mismo.LoanDocumentationType;
import org.commerce.mismo.LoanFeatures;

class LoanFeaturesBean implements LoanFeatures {

   private Long loanFeaturesId;
   private LoanDocumentationType loanDocumentationType;
   private String productDescription;
   private String productName;
   private Boolean prepaymentPenaltyIndicator;


   public Long getLoanFeaturesId() {
      return this.loanFeaturesId;
   }

   public void setLoanFeaturesId(Long loanFeaturesId) {
      this.loanFeaturesId = loanFeaturesId;
   }

   public LoanDocumentationType getLoanDocumentationType() {
      return this.loanDocumentationType;
   }

   public void setLoanDocumentationType(LoanDocumentationType type) {
      this.loanDocumentationType = type;
   }

   public String getProductDescription() {
      return this.productDescription;
   }

   public void setProductDescription(String desc) {
      this.productDescription = desc;
   }

   public String getProductName() {
      return this.productName;
   }

   public void setProductName(String name) {
      this.productName = name;
   }

   public Boolean getPrepaymentPenaltyIndicator() {
      return this.prepaymentPenaltyIndicator;
   }

   public void setPrepaymentPenaltyIndicator(Boolean b) {
      this.prepaymentPenaltyIndicator = b;
   }
}
