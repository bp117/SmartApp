package org.commerce.mismo.bean;

import org.commerce.mismo.ConstructionRefinanceData;
import org.commerce.mismo.GSERefinancePurposeType;

public class ConstructionRefinanceDataBean implements ConstructionRefinanceData {

   private Long constructionRefinanceDataId;
   private Float propertyOriginalCostAmount = null;
   private Float propertyExistingLienAmount = null;
   private GSERefinancePurposeType refiType = null;


   public Long getConstructionRefinanceDataId() {
      return this.constructionRefinanceDataId;
   }

   public void setConstructionRefinanceDataId(Long constructionRefinanceDataId) {
      this.constructionRefinanceDataId = constructionRefinanceDataId;
   }

   public Float getPropertyOriginalCostAmount() {
      return this.propertyOriginalCostAmount;
   }

   public void setPropertyOriginalCostAmount(Float amount) {
      this.propertyOriginalCostAmount = amount;
   }

   public Float getPropertyExistingLienAmount() {
      return this.propertyExistingLienAmount;
   }

   public void setPropertyExistingLienAmount(Float amount) {
      this.propertyExistingLienAmount = amount;
   }

   public GSERefinancePurposeType getGSERefinancePurposeType() {
      return this.refiType;
   }

   public void setGSERefinancePurposeType(GSERefinancePurposeType type) {
      this.refiType = type;
   }
}
