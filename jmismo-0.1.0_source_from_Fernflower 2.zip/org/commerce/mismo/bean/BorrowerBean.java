package org.commerce.mismo.bean;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.CurrentIncome;
import org.commerce.mismo.Declaration;
import org.commerce.mismo.Dependent;
import org.commerce.mismo.Employer;
import org.commerce.mismo.GovernmentMonitoring;
import org.commerce.mismo.Identification;
import org.commerce.mismo.JointAssetLiabilityReportingType;
import org.commerce.mismo.MailTo;
import org.commerce.mismo.MaritalStatus;
import org.commerce.mismo.PresentHousingExpense;
import org.commerce.mismo.PrintPositionType;
import org.commerce.mismo.Residence;
import org.commerce.mismo.ResidentAlienCard;
import org.commerce.mismo.bean.CurrentIncomeBean;
import org.commerce.mismo.bean.DeclarationBean;
import org.commerce.mismo.bean.EmployerBean;
import org.commerce.mismo.bean.GovernmentMonitoringBean;
import org.commerce.mismo.bean.MailToBean;
import org.commerce.mismo.bean.PresentHousingExpenseBean;
import org.commerce.mismo.bean.ResidenceBean;

public class BorrowerBean implements Borrower {

   private Integer ageAtApplicationYears = null;
   private Date birthDate = null;
   private Long borrowerId;
   private Set currentIncomes = new HashSet();
   private Declaration declarations = new DeclarationBean();
   private int dependentCount = 0;
   private Set dependents = new HashSet();
   private String emailAddress;
   private Set employers = new HashSet();
   private String firstName = null;
   private GovernmentMonitoring governmentMonitoring = new GovernmentMonitoringBean();
   private String homeFaxNumber;
   private String homePhoneNumber = null;
   private Set housingExpenses = new HashSet();
   private Identification identification;
   private Borrower jointAssetBorrower = null;
   private String lastName = null;
   private JointAssetLiabilityReportingType liabilityReportingType;
   private MailTo mailTo;
   private MaritalStatus maritalStatus;
   private String middleName;
   private String mobilePhoneNumber;
   private String nameSuffix;
   private String pagerNumber;
   private PrintPositionType printPositionType;
   private Set residences;
   private ResidentAlienCard residentAlienCard;
   private Integer schoolingYears;
   private String SSN;
   private String workFaxNumber;
   private String workTelephoneNumber;


   public BorrowerBean() {
      this.liabilityReportingType = JointAssetLiabilityReportingType.NOT_JOINTLY;
      this.mailTo = null;
      this.maritalStatus = MaritalStatus.NOT_PROVIDED;
      this.middleName = null;
      this.nameSuffix = null;
      this.printPositionType = PrintPositionType.BORROWER;
      this.residences = new HashSet();
      this.schoolingYears = null;
      this.SSN = null;
   }

   public void addCurrentIncome(CurrentIncome income) {
      if(income == null) {
         throw new IllegalArgumentException("income cannot be null");
      } else {
         this.currentIncomes.add(income);
      }
   }

   public void addDependent(Dependent d) {
      this.dependents.add(d);
   }

   public void addEmployer(Employer employer) {
      if(employer == null) {
         throw new IllegalArgumentException("employer cannot be null");
      } else {
         this.employers.add(employer);
      }
   }

   public void addHousingExpense(PresentHousingExpense expense) {
      if(expense == null) {
         throw new IllegalArgumentException("expense cannot be null");
      } else {
         this.housingExpenses.add(expense);
      }
   }

   public void addResidence(Residence residence) {
      if(residence == null) {
         throw new IllegalArgumentException("residence cannot be null");
      } else {
         this.residences.add(residence);
      }
   }

   public CurrentIncome createCurrentIncome() {
      return new CurrentIncomeBean();
   }

   public Employer createEmployer() {
      return new EmployerBean();
   }

   public PresentHousingExpense createHousingExpense() {
      return new PresentHousingExpenseBean();
   }

   public MailTo createMailTo() {
      return new MailToBean();
   }

   public Residence createResidence() {
      return new ResidenceBean();
   }

   public boolean equals(Object obj) {
      if(obj != null && obj instanceof BorrowerBean) {
         BorrowerBean borrower = (BorrowerBean)obj;
         return (new EqualsBuilder()).append(borrower.firstName, this.firstName).append(borrower.middleName, this.middleName).append(borrower.lastName, this.lastName).append(borrower.nameSuffix, this.nameSuffix).append(borrower.ageAtApplicationYears, this.ageAtApplicationYears).append(borrower.printPositionType, this.printPositionType).append(borrower.SSN, this.SSN).append(borrower.dependentCount, this.dependentCount).append(borrower.birthDate, this.birthDate).append(borrower.maritalStatus, this.maritalStatus).append(borrower.homePhoneNumber, this.homePhoneNumber).append(borrower.liabilityReportingType, this.liabilityReportingType).append(borrower.residences, this.residences).append(borrower.employers, this.employers).append(borrower.currentIncomes, this.currentIncomes).append(borrower.housingExpenses, this.housingExpenses).append(borrower.declarations, this.declarations).append(borrower.schoolingYears, this.schoolingYears).append(borrower.governmentMonitoring, this.governmentMonitoring).isEquals();
      } else {
         return false;
      }
   }

   public Integer getAgeAtApplicationYears() {
      return this.ageAtApplicationYears;
   }

   public Date getBirthDate() {
      return this.birthDate;
   }

   public Long getBorrowerId() {
      return this.borrowerId;
   }

   public CurrentIncome[] getCurrentIncomes() {
      CurrentIncome[] incomeArray = new CurrentIncome[this.currentIncomes.size()];
      return (CurrentIncome[])this.currentIncomes.toArray(incomeArray);
   }

   public Declaration getDeclarations() {
      return this.declarations;
   }

   public int getDependentCount() {
      return this.dependentCount;
   }

   public Dependent[] getDependents() {
      Dependent[] dependentsArray = new Dependent[this.dependents.size()];
      return (Dependent[])this.dependents.toArray(dependentsArray);
   }

   public String getEmailAddress() {
      return this.emailAddress;
   }

   public Employer[] getEmployers() {
      Employer[] employerArray = new Employer[this.employers.size()];
      return (Employer[])this.employers.toArray(employerArray);
   }

   public String getFirstName() {
      return this.firstName;
   }

   public GovernmentMonitoring getGovernmentMonitoring() {
      return this.governmentMonitoring;
   }

   public String getHomeFaxNumber() {
      return this.homeFaxNumber;
   }

   public String getHomePhoneNumber() {
      return this.homePhoneNumber;
   }

   public PresentHousingExpense[] getHousingExpenses() {
      PresentHousingExpense[] expenseArray = new PresentHousingExpense[this.housingExpenses.size()];
      return (PresentHousingExpense[])this.housingExpenses.toArray(expenseArray);
   }

   public Identification getIdentification() {
      return this.identification;
   }

   public Borrower getJointAssetBorrower() {
      return this.jointAssetBorrower;
   }

   public JointAssetLiabilityReportingType getJointAssetResidenceReportingType() {
      return this.liabilityReportingType;
   }

   public String getLastName() {
      return this.lastName;
   }

   public MailTo getMailTo() {
      return this.mailTo;
   }

   public MaritalStatus getMaritalStatus() {
      return this.maritalStatus;
   }

   public String getMiddleName() {
      return this.middleName;
   }

   public String getMobilePhoneNumber() {
      return this.mobilePhoneNumber;
   }

   public String getNameSuffix() {
      return this.nameSuffix;
   }

   public String getPagerNumber() {
      return this.pagerNumber;
   }

   public PrintPositionType getPrintPositionType() {
      return this.printPositionType;
   }

   public Residence[] getResidences() {
      Residence[] residenceArray = new Residence[this.residences.size()];
      return (Residence[])this.residences.toArray(residenceArray);
   }

   public ResidentAlienCard getResidentAlienCard() {
      return this.residentAlienCard;
   }

   public Integer getSchoolingYears() {
      return this.schoolingYears;
   }

   public String getSSN() {
      return this.SSN;
   }

   public String getUnparsedName() {
      StringBuffer name = new StringBuffer(this.getUnparsedNameExcludingNameSuffix());
      if(this.nameSuffix != null && this.nameSuffix.length() > 0) {
         if(name.length() > 0) {
            name.append(' ');
         }

         name.append(this.nameSuffix.trim());
      }

      return name.toString();
   }

   public String getUnparsedNameExcludingNameSuffix() {
      StringBuffer name = new StringBuffer();
      if(this.firstName != null && this.firstName.length() > 0) {
         name.append(this.firstName.trim());
      }

      if(this.middleName != null && this.middleName.length() > 0) {
         if(name.length() > 0) {
            name.append(' ');
         }

         name.append(this.middleName.trim());
      }

      if(this.lastName != null && this.lastName.length() > 0) {
         if(name.length() > 0) {
            name.append(' ');
         }

         name.append(this.lastName.trim());
      }

      return name.toString();
   }

   public String getWorkFaxNumber() {
      return this.workFaxNumber;
   }

   public String getWorkTelephoneNumber() {
      return this.workTelephoneNumber;
   }

   public int hashCode() {
      return (new HashCodeBuilder(13, 39)).append(this.firstName).append(this.middleName).append(this.lastName).append(this.nameSuffix).append(this.ageAtApplicationYears).append(this.printPositionType).append(this.SSN).append(this.dependentCount).append(this.birthDate).append(this.maritalStatus).append(this.homePhoneNumber).append(this.liabilityReportingType).append(this.residences).append(this.employers).append(this.currentIncomes).append(this.housingExpenses).append(this.declarations).append(this.schoolingYears).append(this.governmentMonitoring).toHashCode();
   }

   public void setAgeAtApplicationYears(Integer age) {
      this.ageAtApplicationYears = age;
   }

   public void setBirthDate(Date date) {
      this.birthDate = date;
   }

   public void setBorrowerId(Long borrowerId) {
      this.borrowerId = borrowerId;
   }

   public void setDependentCount(int count) {
      if(count < 0) {
         throw new IllegalArgumentException("dependentCount cannot be less than 0");
      } else {
         this.dependentCount = count;
      }
   }

   public void setDependents(Set dependents) {
      this.dependents = dependents;
   }

   public void setEmployers(Set employers) {
      this.employers = employers;
   }

   public void setCurrentIncomes(Set currentIncomes) {
      this.currentIncomes = currentIncomes;
   }

   public void setResidences(Set residences) {
      this.residences = residences;
   }

   public void setHousingExpenses(Set housingExpenses) {
      this.housingExpenses = housingExpenses;
   }

   public void setDeclarations(Declaration declaration) {
      this.declarations = declaration;
   }

   public void setEmailAddress(String email) {
      this.emailAddress = email;
   }

   public void setFirstName(String name) {
      this.firstName = name;
   }

   public void setGovernmentMonitoring(GovernmentMonitoring hmda) {
      this.governmentMonitoring = hmda;
   }

   public void setHomeFaxNumber(String number) {
      this.homeFaxNumber = number;
   }

   public void setHomePhoneNumber(String number) {
      this.homePhoneNumber = number;
   }

   public void setIdentification(Identification identification) {
      this.identification = identification;
   }

   public void setJointAssetBorrower(Borrower borrower) {
      this.jointAssetBorrower = borrower;
   }

   public void setJointAssetLiabilityReportingType(JointAssetLiabilityReportingType type) {
      if(type == null) {
         throw new IllegalArgumentException("jointAssetLiabilityReportingType cannot be null");
      } else {
         this.liabilityReportingType = type;
      }
   }

   public void setLastName(String name) {
      this.lastName = name;
   }

   public void setMailTo(MailTo mailTo) {
      this.mailTo = mailTo;
   }

   public void setMaritalStatus(MaritalStatus status) {
      if(status == null) {
         throw new IllegalArgumentException("maritalStatus cannot be null");
      } else {
         this.maritalStatus = status;
      }
   }

   public void setMiddleName(String name) {
      this.middleName = name;
   }

   public void setMobilePhoneNumber(String phoneNumber) {
      this.mobilePhoneNumber = phoneNumber;
   }

   public void setNameSuffix(String suffix) {
      this.nameSuffix = suffix;
   }

   public void setPagerNumber(String number) {
      this.pagerNumber = number;
   }

   public void setPrintPositionType(PrintPositionType type) {
      if(type == null) {
         throw new IllegalArgumentException("printPositionType cannot be null");
      } else {
         this.printPositionType = type;
      }
   }

   public void setResidentAlienCard(ResidentAlienCard residentAlienCard) {
      this.residentAlienCard = residentAlienCard;
   }

   public void setSchoolingYears(Integer years) {
      this.schoolingYears = years;
   }

   public void setSSN(String ssn) {
      this.SSN = ssn;
   }

   public void setWorkFaxNumber(String number) {
      this.workFaxNumber = number;
   }

   public void setWorkTelephoneNumber(String phoneNumber) {
      this.workTelephoneNumber = phoneNumber;
   }

   public String toString() {
      return (new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)).append("firstName", this.firstName).append("middleName", this.middleName).append("lastName", this.lastName).append("nameSuffix", this.nameSuffix).append("ageAtApplicationYears", this.ageAtApplicationYears).append("printPositionType", this.printPositionType).append("ssn", this.SSN).append("dependentCount", this.dependentCount).append("birthDate", this.birthDate).append("maritalStatus", this.maritalStatus).append("homePhoneNumber", this.homePhoneNumber).append("liabilityReportingType", this.liabilityReportingType).append("residences", this.residences).append("employers", this.employers).append("currentIncomes", this.currentIncomes).append("housingExpenses", this.housingExpenses).append("declarations", this.declarations).append("schoolingYears", this.schoolingYears).append("governmentMonitoring", this.governmentMonitoring).toString();
   }
}
