package org.commerce.mismo.bean;

import java.math.BigDecimal;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.enums.Enum;
import org.commerce.mismo.CurrentIncome;
import org.commerce.mismo.IncomeType;

class CurrentIncomeBean implements CurrentIncome {

   private Long currentIncomeId;
   private BigDecimal monthlyTotalAmount = null;
   private IncomeType incomeType = null;


   public Long getCurrentIncomeId() {
      return this.currentIncomeId;
   }

   public void setCurrentIncomeId(Long currentIncomeId) {
      this.currentIncomeId = currentIncomeId;
   }

   public BigDecimal getMonthlyTotalAmount() {
      return this.monthlyTotalAmount;
   }

   public BigDecimal getAmount() {
      return this.getMonthlyTotalAmount();
   }

   public void setMonthlyTotalAmount(BigDecimal amount) {
      this.monthlyTotalAmount = amount;
   }

   public IncomeType getIncomeType() {
      return this.incomeType;
   }

   public Enum getType() {
      return this.getIncomeType();
   }

   public void setIncomeType(IncomeType type) {
      this.incomeType = type;
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }

   public boolean equals(Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
   }

   public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
   }
}
