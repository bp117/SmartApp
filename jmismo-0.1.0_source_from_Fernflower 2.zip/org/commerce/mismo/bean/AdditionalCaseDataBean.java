package org.commerce.mismo.bean;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.commerce.mismo.AdditionalCaseData;
import org.commerce.mismo.TransmittalData;
import org.commerce.mismo.bean.TransmittalDataBean;

class AdditionalCaseDataBean implements AdditionalCaseData {

   private Long addtionalCaseDataId;
   private TransmittalData transmittalData = new TransmittalDataBean();


   public Long getAddtionalCaseDataId() {
      return this.addtionalCaseDataId;
   }

   public void setAddtionalCaseDataId(Long addtionalCaseDataId) {
      this.addtionalCaseDataId = addtionalCaseDataId;
   }

   public TransmittalData getTransmittalData() {
      return this.transmittalData;
   }

   public void setTransmittalData(TransmittalData transmittalData) {
      this.transmittalData = transmittalData;
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }
}
