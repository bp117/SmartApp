package org.commerce.mismo.bean;

import org.commerce.mismo.Address;
import org.commerce.mismo.BorrowerResidencyBasisType;
import org.commerce.mismo.BorrowerResidencyType;
import org.commerce.mismo.Landlord;
import org.commerce.mismo.Residence;
import org.commerce.mismo.bean.AddressBean;
import org.commerce.mismo.bean.BaseBean;
import org.commerce.mismo.bean.LandlordBean;

public class ResidenceBean extends BaseBean implements Residence {

   private Long residenceId;
   private Address address = new AddressBean();
   private int borrowerResidencyDurationMonths = 0;
   private int borrowerResidencyDurationYears = 0;
   private BorrowerResidencyBasisType residencyBasisType = null;
   private BorrowerResidencyType residencyType = null;
   private Landlord landlord = new LandlordBean();


   public Address getAddress() {
      return this.address;
   }

   public Long getResidenceId() {
      return this.residenceId;
   }

   public void setResidenceId(Long residenceId) {
      this.residenceId = residenceId;
   }

   public int getBorrowerResidencyDurationMonths() {
      return this.borrowerResidencyDurationMonths;
   }

   public int getBorrowerResidencyDurationYears() {
      return this.borrowerResidencyDurationYears;
   }

   public BorrowerResidencyBasisType getResidencyBasisType() {
      return this.residencyBasisType;
   }

   public BorrowerResidencyType getResidencyType() {
      return this.residencyType;
   }

   public void setAddress(Address address) {
      this.address = address;
   }

   public void setBorrowerResidencyDurationMonths(int months) {
      this.borrowerResidencyDurationMonths = months;
   }

   public void setBorrowerResidencyDurationYears(int years) {
      this.borrowerResidencyDurationYears = years;
   }

   public void setResidencyBasisType(BorrowerResidencyBasisType type) {
      this.residencyBasisType = type;
   }

   public void setResidencyType(BorrowerResidencyType type) {
      this.residencyType = type;
   }

   public Landlord getLandlord() {
      return this.landlord;
   }

   public void setLandlord(Landlord landlord) {
      this.landlord = landlord;
   }
}
