package org.commerce.mismo.bean;

import java.io.Serializable;
import org.commerce.mismo.MailTo;

public class MailToBean implements MailTo, Serializable {

   private Long mailId;
   private String city;
   private String country;
   private String postalCode;
   private String state;
   private String streetAddress1;
   private String streetAddress2;
   private Boolean isSameAddress;


   public String getCity() {
      return this.city;
   }

   public Long getMailId() {
      return this.mailId;
   }

   public String getCountry() {
      return this.country;
   }

   public String getPostalCode() {
      return this.postalCode;
   }

   public String getState() {
      return this.state;
   }

   public String getStreetAddress1() {
      return this.streetAddress1;
   }

   public String getStreetAddress2() {
      return this.streetAddress2;
   }

   public void setCity(String string) {
      this.city = string;
   }

   public void setMailId(Long mailId) {
      this.mailId = mailId;
   }

   public void setCountry(String string) {
      this.country = string;
   }

   public void setPostalCode(String string) {
      this.postalCode = string;
   }

   public void setState(String string) {
      this.state = string;
   }

   public void setStreetAddress1(String string) {
      this.streetAddress1 = string;
   }

   public void setStreetAddress2(String string) {
      this.streetAddress2 = string;
   }

   public void setIsSameAddress(Boolean isSameAsResidenceAddress) {
      this.isSameAddress = isSameAsResidenceAddress;
   }

   public Boolean getIsSameAddress() {
      return this.isSameAddress;
   }
}
