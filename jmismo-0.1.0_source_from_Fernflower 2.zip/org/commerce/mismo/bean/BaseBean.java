package org.commerce.mismo.bean;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

class BaseBean {

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }

   public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
   }

   public boolean equals(Object o) {
      return EqualsBuilder.reflectionEquals(this, o);
   }
}
