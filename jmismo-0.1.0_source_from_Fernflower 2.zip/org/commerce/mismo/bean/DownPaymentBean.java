package org.commerce.mismo.bean;

import java.math.BigDecimal;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.enums.Enum;
import org.commerce.mismo.DownPayment;
import org.commerce.mismo.DownPaymentType;

class DownPaymentBean implements DownPayment {

   private Long downPaymentId;
   private BigDecimal amount = null;
   private DownPaymentType downPaymentType;
   private String sourceDescription;


   DownPaymentBean() {
      this.downPaymentType = DownPaymentType.OTHER_TYPE_OF_DOWN_PAYMENT;
      this.sourceDescription = null;
   }

   public Long getDownPaymentId() {
      return this.downPaymentId;
   }

   public void setDownPaymentId(Long downPaymentId) {
      this.downPaymentId = downPaymentId;
   }

   public BigDecimal getAmount() {
      return this.amount;
   }

   public void setAmount(BigDecimal amount) {
      this.amount = amount;
   }

   public String getSourceDescription() {
      return this.sourceDescription;
   }

   public void setSourceDescription(String description) {
      this.sourceDescription = description;
   }

   public DownPaymentType getDownPaymentType() {
      return this.downPaymentType;
   }

   public Enum getType() {
      return this.getDownPaymentType();
   }

   public void setDownPaymentType(DownPaymentType type) {
      if(type == null) {
         throw new IllegalArgumentException("downPaymentType cannot be null");
      } else {
         this.downPaymentType = type;
      }
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }
}
