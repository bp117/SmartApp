package org.commerce.mismo.bean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.commerce.mismo.Address;
import org.commerce.mismo.BuildingStatusType;
import org.commerce.mismo.Property;
import org.commerce.mismo.bean.AddressBean;

class PropertyBean implements Property {

   private Long propertyId;
   private Address address = new AddressBean();
   private BuildingStatusType buildingStatusType = null;
   private Integer structureBuiltYear = null;
   private Integer financedNumberOfUnits = null;
   private List legalDescriptions = new ArrayList();
   private String county;
   private String homeOwnersAssociationName;
   private String homeOwnersAssociationTelephoneNumber;
   private String propertySellerFirstName;
   private String propertySellerLastName;
   private Address propertySellerAddress = new AddressBean();
   private BigDecimal proposedGrossRent;
   private Date acquiredDate;
   private int squareFootage;


   public Address getAddress() {
      return this.address;
   }

   public void setAddress(Address address) {
      this.address = address;
   }

   public Long getPropertyId() {
      return this.propertyId;
   }

   public void setPropertyId(Long propertyId) {
      this.propertyId = propertyId;
   }

   public String getCounty() {
      return this.county;
   }

   public void setCounty(String county) {
      this.county = county;
   }

   public BuildingStatusType getBuildingStatusType() {
      return this.buildingStatusType;
   }

   public void setBuildingStatusType(BuildingStatusType buildingStatusType) {
      this.buildingStatusType = buildingStatusType;
   }

   public Integer getStructureBuiltYear() {
      return this.structureBuiltYear;
   }

   public void setStructureBuiltYear(Integer year) {
      this.structureBuiltYear = year;
   }

   public Integer getFinancedNumberOfUnits() {
      return this.financedNumberOfUnits;
   }

   public void setFinancedNumberOfUnits(Integer unitCount) {
      this.financedNumberOfUnits = unitCount;
   }

   public boolean equals(Object obj) {
      return EqualsBuilder.reflectionEquals(this, obj);
   }

   public int hashCode() {
      return HashCodeBuilder.reflectionHashCode(this);
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }

   public void addLegalDescription(String description) {
      if(description == null) {
         throw new IllegalArgumentException("description cannot be null");
      } else {
         this.legalDescriptions.add(description);
      }
   }

   public String[] getLegalDescriptions() {
      String[] descriptions = new String[this.legalDescriptions.size()];
      return (String[])this.legalDescriptions.toArray(descriptions);
   }

   public String getHomeOwnersAssociationName() {
      return this.homeOwnersAssociationName;
   }

   public void setHomeOwnersAssociationName(String name) {
      this.homeOwnersAssociationName = name;
   }

   public String getHomeOwnersAssociationTelephoneNumber() {
      return this.homeOwnersAssociationTelephoneNumber;
   }

   public void setHomeOwnersAssociationTelephoneNumber(String number) {
      this.homeOwnersAssociationTelephoneNumber = number;
   }

   public String getPropertySellerFirstName() {
      return this.propertySellerFirstName;
   }

   public void setPropertySellerFirstName(String name) {
      this.propertySellerFirstName = name;
   }

   public String getPropertySellerLastName() {
      return this.propertySellerLastName;
   }

   public void setPropertySellerLastName(String name) {
      this.propertySellerLastName = name;
   }

   public Address getPropertySellerAddress() {
      return this.propertySellerAddress;
   }

   public void setPropertySellerAddress(Address propertySellerAddress) {
      this.propertySellerAddress = propertySellerAddress;
   }

   public BigDecimal getProposedGrossRent() {
      return this.proposedGrossRent;
   }

   public void setProposedGrossRent(BigDecimal amount) {
      this.proposedGrossRent = amount;
   }

   public Date getAcquiredDate() {
      return this.acquiredDate;
   }

   public void setAcquiredDate(Date acquiredDate) {
      this.acquiredDate = acquiredDate;
   }

   public void setSquareFootage(int squareFootage) {
      this.squareFootage = squareFootage;
   }

   public int getSquareFootage() {
      return this.squareFootage;
   }
}
