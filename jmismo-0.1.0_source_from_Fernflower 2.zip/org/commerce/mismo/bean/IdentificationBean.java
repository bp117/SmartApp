package org.commerce.mismo.bean;

import java.io.Serializable;
import java.util.Date;
import org.commerce.mismo.Identification;
import org.commerce.mismo.IdentificationType;

public class IdentificationBean implements Identification, Serializable {

   static final long serialVersionUID = 4262560592320583378L;
   private Long identificationId;
   private IdentificationType type;
   private Date issueDate;
   private Date expirationDate;
   private String issuingState;
   private String issuingCountry;


   public Long getIdentificationId() {
      return this.identificationId;
   }

   public void setIdentificationId(Long identificationId) {
      this.identificationId = identificationId;
   }

   public Date getExpirationDate() {
      return this.expirationDate;
   }

   public Date getIssueDate() {
      return this.issueDate;
   }

   public String getIssuingCountry() {
      return this.issuingCountry;
   }

   public String getIssuingState() {
      return this.issuingState;
   }

   public IdentificationType getType() {
      return this.type;
   }

   public void setExpirationDate(Date date) {
      this.expirationDate = date;
   }

   public void setIssueDate(Date date) {
      this.issueDate = date;
   }

   public void setIssuingCountry(String string) {
      this.issuingCountry = string;
   }

   public void setIssuingState(String string) {
      this.issuingState = string;
   }

   public void setType(IdentificationType type) {
      this.type = type;
   }
}
