package org.commerce.mismo.bean;

import java.util.HashSet;
import java.util.Set;
import org.commerce.mismo.ContactDetail;
import org.commerce.mismo.ContactPoint;
import org.commerce.mismo.bean.BaseBean;
import org.commerce.mismo.bean.ContactPointBean;

public class ContactDetailBean extends BaseBean implements ContactDetail {

   private Long contactDetailId;
   private String name;
   private Set contactPoints = new HashSet();


   public Long getContactDetailId() {
      return this.contactDetailId;
   }

   public void setContactDetailId(Long contactDetailId) {
      this.contactDetailId = contactDetailId;
   }

   public String getName() {
      return this.name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public ContactPoint[] getContactPoints() {
      ContactPoint[] points = new ContactPoint[this.contactPoints.size()];
      return (ContactPoint[])this.contactPoints.toArray(points);
   }

   public void setContactPoints(Set contactPoints) {
      this.contactPoints = contactPoints;
   }

   public void addContactPoint(ContactPoint contactPoint) {
      this.contactPoints.add(contactPoint);
   }

   public void removeContactPoint(ContactPoint contactPoint) {
      if(contactPoint != null) {
         this.contactPoints.remove(contactPoint);
      }

   }

   public ContactPoint createContactPoint() {
      return new ContactPointBean();
   }
}
