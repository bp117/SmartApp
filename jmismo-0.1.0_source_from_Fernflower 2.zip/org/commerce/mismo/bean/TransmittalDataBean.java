package org.commerce.mismo.bean;

import java.math.BigDecimal;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.commerce.mismo.CaseStateType;
import org.commerce.mismo.TransmittalData;

class TransmittalDataBean implements TransmittalData {

   private Long transmittalDataId;
   private String lendersBranchIdentifier = null;
   private BigDecimal propertyAppraisedValueAmount;
   private CaseStateType caseStateType;
   private String loanOriginationSystemLoanIdentifier;
   private Boolean armsLengthIndicator;
   private Boolean creditReportAuthorizationIndicator;


   public Long getTransmittalDataId() {
      return this.transmittalDataId;
   }

   public void setTransmittalDataId(Long transmittalDataId) {
      this.transmittalDataId = transmittalDataId;
   }

   public String getLendersBranchIdentifier() {
      return this.lendersBranchIdentifier;
   }

   public void setLendersBranchIdentifier(String identifier) {
      this.lendersBranchIdentifier = identifier;
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }

   public BigDecimal getPropertyAppraisedValueAmount() {
      return this.propertyAppraisedValueAmount;
   }

   public void setPropertyAppraisedValueAmount(BigDecimal amount) {
      this.propertyAppraisedValueAmount = amount;
   }

   public CaseStateType getCaseStateType() {
      return this.caseStateType;
   }

   public void setCaseStateType(CaseStateType type) {
      this.caseStateType = type;
   }

   public String getLoanOriginationSystemLoanIdentifier() {
      return this.loanOriginationSystemLoanIdentifier;
   }

   public void setLoanOriginationSystemLoanIdentifier(String id) {
      this.loanOriginationSystemLoanIdentifier = id;
   }

   public Boolean getArmsLengthIndicator() {
      return this.armsLengthIndicator;
   }

   public void setArmsLengthIndicator(Boolean armsLengthIndicator) {
      this.armsLengthIndicator = armsLengthIndicator;
   }

   public Boolean getCreditReportAuthorizationIndicator() {
      return this.creditReportAuthorizationIndicator;
   }

   public void setCreditReportAuthorizationIndicator(Boolean creditReportAuthorizationIndicator) {
      this.creditReportAuthorizationIndicator = creditReportAuthorizationIndicator;
   }
}
