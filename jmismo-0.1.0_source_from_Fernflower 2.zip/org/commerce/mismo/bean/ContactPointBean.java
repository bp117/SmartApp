package org.commerce.mismo.bean;

import org.commerce.mismo.ContactPoint;
import org.commerce.mismo.ContactPointRoleType;
import org.commerce.mismo.ContactPointType;
import org.commerce.mismo.bean.BaseBean;

public class ContactPointBean extends BaseBean implements ContactPoint {

   private Long contactPointId;
   private ContactPointRoleType role;
   private ContactPointType type;
   private String typeOtherDescription;
   private String value;
   private Boolean preferenceIndicator;


   public Long getContactPointId() {
      return this.contactPointId;
   }

   public void setContactPointId(Long contactPointId) {
      this.contactPointId = contactPointId;
   }

   public ContactPointRoleType getRoleType() {
      return this.role;
   }

   public void setRoleType(ContactPointRoleType type) {
      this.role = type;
   }

   public ContactPointType getType() {
      return this.type;
   }

   public void setType(ContactPointType type) {
      this.type = type;
   }

   public String getTypeOtherDescription() {
      return this.typeOtherDescription;
   }

   public void setTypeOtherDescription(String desc) {
      this.typeOtherDescription = desc;
   }

   public String getValue() {
      return this.value;
   }

   public void setValue(String value) {
      this.value = value;
   }

   public Boolean getPreferenceIndicator() {
      return this.preferenceIndicator;
   }

   public void setPreferenceIndicator(Boolean b) {
      this.preferenceIndicator = b;
   }
}
