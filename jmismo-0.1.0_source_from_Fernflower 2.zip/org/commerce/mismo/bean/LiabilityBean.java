package org.commerce.mismo.bean;

import java.math.BigDecimal;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.enums.Enum;
import org.commerce.mismo.Liability;
import org.commerce.mismo.LiabilityType;
import org.commerce.mismo.REOProperty;
import org.commerce.mismo.bean.MultiBorrowerAssociatedEntityBean;

class LiabilityBean extends MultiBorrowerAssociatedEntityBean implements Liability {

   private Long liabilityId;
   private REOProperty rEOProperty = null;
   private String holderName = null;
   private LiabilityType liabilityType = null;
   private BigDecimal monthlyPaymentAmount = null;
   private BigDecimal unpaidBalanceAmount = null;
   private String accountIdentifier;
   private Boolean payoffStatusIndicator;


   public REOProperty getREOProperty() {
      return this.rEOProperty;
   }

   public Long getLiabilityId() {
      return this.liabilityId;
   }

   public void setLiabilityId(Long liabilityId) {
      this.liabilityId = liabilityId;
   }

   public void setREOProperty(REOProperty reoProperty) {
      this.rEOProperty = reoProperty;
   }

   public LiabilityType getLiabilityType() {
      return this.liabilityType;
   }

   public Enum getType() {
      return this.getLiabilityType();
   }

   public void setLiabilityType(LiabilityType type) {
      this.liabilityType = type;
   }

   public String getHolderName() {
      return this.holderName;
   }

   public void setHolderName(String name) {
      this.holderName = name;
   }

   public BigDecimal getMonthlyPaymentAmount() {
      return this.monthlyPaymentAmount;
   }

   public BigDecimal getAmount() {
      return this.getMonthlyPaymentAmount();
   }

   public void setMonthlyPaymentAmount(BigDecimal amount) {
      this.monthlyPaymentAmount = amount;
   }

   public BigDecimal getUnpaidBalanceAmount() {
      return this.unpaidBalanceAmount;
   }

   public void setUnpaidBalanceAmount(BigDecimal amount) {
      this.unpaidBalanceAmount = amount;
   }

   public String toString() {
      return ToStringBuilder.reflectionToString(this);
   }

   public String getAccountIdentifier() {
      return this.accountIdentifier;
   }

   public void setAccountIdentifier(String accountId) {
      this.accountIdentifier = accountId;
   }

   public Boolean getPayoffStatusIndicator() {
      return this.payoffStatusIndicator;
   }

   public void setPayoffStatusIndicator(Boolean b) {
      this.payoffStatusIndicator = b;
   }
}
