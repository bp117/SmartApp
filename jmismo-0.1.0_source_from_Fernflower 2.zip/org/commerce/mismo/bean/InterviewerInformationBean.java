package org.commerce.mismo.bean;

import org.commerce.mismo.ApplicationMethodTakenType;
import org.commerce.mismo.InterviewerInformation;

public class InterviewerInformationBean implements InterviewerInformation {

   private ApplicationMethodTakenType applicationMethodTakenType = null;


   public ApplicationMethodTakenType getApplicationMethodTakenType() {
      return this.applicationMethodTakenType;
   }

   public void setApplicationMethodTakenType(ApplicationMethodTakenType type) {
      this.applicationMethodTakenType = type;
   }
}
