package org.commerce.mismo.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.commerce.mismo.GenderType;
import org.commerce.mismo.GovernmentMonitoring;
import org.commerce.mismo.HMDAEthnicityType;

public class GovernmentMonitoringBean implements GovernmentMonitoring, Serializable {

   static final long serialVersionUID = -3387762114570499879L;
   private Long governmentMonitoringId;
   private HMDAEthnicityType ethnicityType = null;
   private GenderType genderType = null;
   private Boolean raceNationalOriginRefusalIndicator = null;
   private List hmdaRaces = new ArrayList();


   public Long getGovernmentMonitoringId() {
      return this.governmentMonitoringId;
   }

   public void setGovernmentMonitoringId(Long governmentMonitoringId) {
      this.governmentMonitoringId = governmentMonitoringId;
   }

   public HMDAEthnicityType getEthnicityType() {
      return this.ethnicityType;
   }

   public void setEthnicityType(HMDAEthnicityType ethnicityType) {
      this.ethnicityType = ethnicityType;
   }

   public GenderType getGenderType() {
      return this.genderType;
   }

   public void setGenderType(GenderType type) {
      if(type == null) {
         type = GenderType.NOT_PROVIDED;
      }

      this.genderType = type;
   }

   public List getHMDARaces() {
      return this.hmdaRaces;
   }

   public void setHMDARaces(List hdmaRaces) {
      this.hmdaRaces = hdmaRaces;
   }

   public Boolean getRaceNationalOriginRefusalIndicator() {
      return this.raceNationalOriginRefusalIndicator;
   }

   public void setRaceNationalOriginRefusalIndicator(Boolean isRefuse) {
      this.raceNationalOriginRefusalIndicator = isRefuse;
   }
}
