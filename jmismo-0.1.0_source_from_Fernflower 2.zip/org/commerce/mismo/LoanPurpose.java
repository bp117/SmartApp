package org.commerce.mismo;

import org.commerce.mismo.ConstructionRefinanceData;
import org.commerce.mismo.LoanPurposeType;
import org.commerce.mismo.PropertyRightsType;
import org.commerce.mismo.PropertyUsageType;
import org.commerce.mismo.RefinanceCashOutPurposeType;

public interface LoanPurpose {

   LoanPurposeType getLoanPurposeType();

   void setLoanPurposeType(LoanPurposeType var1);

   RefinanceCashOutPurposeType getRefinanceCashOutPurposeType();

   void setRefinanceCashOutPurposeType(RefinanceCashOutPurposeType var1);

   String getOtherLoanPurposeDescription();

   void setOtherLoanPurposeDescription(String var1);

   String getGSETitleMannerHeldDescription();

   void setGSETitleMannerHeldDescription(String var1);

   PropertyUsageType getPropertyUsageType();

   void setPropertyUsageType(PropertyUsageType var1);

   ConstructionRefinanceData getConstructionRefinanceData();

   PropertyRightsType getPropertyRightsType();

   void setPropertyRightsType(PropertyRightsType var1);
}
