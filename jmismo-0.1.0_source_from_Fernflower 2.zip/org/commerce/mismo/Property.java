package org.commerce.mismo;

import java.util.Date;
import org.commerce.mismo.Address;
import org.commerce.mismo.BuildingStatusType;

public interface Property {

   Address getAddress();

   void setAddress(Address var1);

   String getCounty();

   void setCounty(String var1);

   BuildingStatusType getBuildingStatusType();

   void setBuildingStatusType(BuildingStatusType var1);

   Integer getStructureBuiltYear();

   void setStructureBuiltYear(Integer var1);

   Integer getFinancedNumberOfUnits();

   void setFinancedNumberOfUnits(Integer var1);

   String[] getLegalDescriptions();

   void addLegalDescription(String var1);

   Date getAcquiredDate();

   void setAcquiredDate(Date var1);
}
