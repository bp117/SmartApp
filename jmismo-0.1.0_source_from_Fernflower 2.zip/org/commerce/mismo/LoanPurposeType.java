package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class LoanPurposeType extends Enum {

   public static final LoanPurposeType CONSTRUCTION_ONLY = new LoanPurposeType("ConstructionOnly");
   public static final LoanPurposeType CONSTRUCTION_TO_PERMANENT = new LoanPurposeType("ConstructionToPermanent");
   public static final LoanPurposeType OTHER = new LoanPurposeType("Other");
   public static final LoanPurposeType PURCHASE = new LoanPurposeType("Purchase");
   public static final LoanPurposeType REFINANCE = new LoanPurposeType("Refinance");
   static Class class$org$commerce$mismo$LoanPurposeType;


   private LoanPurposeType(String name) {
      super(name);
   }

   public static LoanPurposeType getEnum(String type) {
      return (LoanPurposeType)getEnum(class$org$commerce$mismo$LoanPurposeType == null?(class$org$commerce$mismo$LoanPurposeType = class$("org.commerce.mismo.LoanPurposeType")):class$org$commerce$mismo$LoanPurposeType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$LoanPurposeType == null?(class$org$commerce$mismo$LoanPurposeType = class$("org.commerce.mismo.LoanPurposeType")):class$org$commerce$mismo$LoanPurposeType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$LoanPurposeType == null?(class$org$commerce$mismo$LoanPurposeType = class$("org.commerce.mismo.LoanPurposeType")):class$org$commerce$mismo$LoanPurposeType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$LoanPurposeType == null?(class$org$commerce$mismo$LoanPurposeType = class$("org.commerce.mismo.LoanPurposeType")):class$org$commerce$mismo$LoanPurposeType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
