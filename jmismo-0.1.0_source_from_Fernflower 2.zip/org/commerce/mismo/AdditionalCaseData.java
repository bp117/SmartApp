package org.commerce.mismo;

import org.commerce.mismo.TransmittalData;

public interface AdditionalCaseData {

   TransmittalData getTransmittalData();
}
