package org.commerce.mismo;

import java.math.BigDecimal;
import org.commerce.mismo.Address;
import org.commerce.mismo.AssetType;
import org.commerce.mismo.MultiBorrowerAssociatedEntity;
import org.commerce.mismo.util.EnumObject;

public interface Asset extends MultiBorrowerAssociatedEntity, EnumObject {

   String getAccountIdentifier();

   void setAccountIdentifier(String var1);

   BigDecimal getCashOrMarketValueAmount();

   void setCashOrMarketValueAmount(BigDecimal var1);

   AssetType getAssetType();

   void setType(AssetType var1);

   String getAutomobileMakeDescription();

   void setAutomobileMakeDescription(String var1);

   String getAutomobileModelYear();

   void setAutomobileModelYear(String var1);

   BigDecimal getLifeInsuranceFaceValueAmount();

   void setLifeInsuranceFaceValueAmount(BigDecimal var1);

   String getOtherAssetTypeDescription();

   void setOtherAssetTypeDescription(String var1);

   String getHolder();

   void setHolder(String var1);

   Address getHolderAddress();

   void setHolderAddress(Address var1);

   Boolean getVerifiedIndicator();

   void setVerifiedIndicator(Boolean var1);
}
