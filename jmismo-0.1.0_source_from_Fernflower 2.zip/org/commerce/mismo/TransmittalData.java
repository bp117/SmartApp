package org.commerce.mismo;

import java.math.BigDecimal;
import org.commerce.mismo.CaseStateType;

public interface TransmittalData {

   String getLendersBranchIdentifier();

   void setLendersBranchIdentifier(String var1);

   BigDecimal getPropertyAppraisedValueAmount();

   void setPropertyAppraisedValueAmount(BigDecimal var1);

   CaseStateType getCaseStateType();

   void setCaseStateType(CaseStateType var1);

   String getLoanOriginationSystemLoanIdentifier();

   void setLoanOriginationSystemLoanIdentifier(String var1);

   Boolean getArmsLengthIndicator();

   void setArmsLengthIndicator(Boolean var1);

   Boolean getCreditReportAuthorizationIndicator();

   void setCreditReportAuthorizationIndicator(Boolean var1);
}
