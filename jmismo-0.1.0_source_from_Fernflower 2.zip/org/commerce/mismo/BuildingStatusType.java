package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class BuildingStatusType extends Enum {

   public static final BuildingStatusType EXISTING = new BuildingStatusType("Existing");
   public static final BuildingStatusType PROPOSED = new BuildingStatusType("Proposed");
   public static final BuildingStatusType SUBJECT_TO_ALTERATION = new BuildingStatusType("SubjectToAlterationImprovementRepairAndRehabilitation");
   public static final BuildingStatusType SUBSTANTIALLY_REHABILITATED = new BuildingStatusType("SubstantiallyRehabilitated");
   public static final BuildingStatusType UNDER_CONSTRUCTION = new BuildingStatusType("UnderConstruction");
   static Class class$org$commerce$mismo$BuildingStatusType;


   private BuildingStatusType(String name) {
      super(name);
   }

   public static BuildingStatusType getEnum(String type) {
      return (BuildingStatusType)getEnum(class$org$commerce$mismo$BuildingStatusType == null?(class$org$commerce$mismo$BuildingStatusType = class$("org.commerce.mismo.BuildingStatusType")):class$org$commerce$mismo$BuildingStatusType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$BuildingStatusType == null?(class$org$commerce$mismo$BuildingStatusType = class$("org.commerce.mismo.BuildingStatusType")):class$org$commerce$mismo$BuildingStatusType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$BuildingStatusType == null?(class$org$commerce$mismo$BuildingStatusType = class$("org.commerce.mismo.BuildingStatusType")):class$org$commerce$mismo$BuildingStatusType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$BuildingStatusType == null?(class$org$commerce$mismo$BuildingStatusType = class$("org.commerce.mismo.BuildingStatusType")):class$org$commerce$mismo$BuildingStatusType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
