package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class BorrowerResidencyBasisType extends Enum {

   public static final BorrowerResidencyBasisType LIVING_RENT_FREE = new BorrowerResidencyBasisType("LivingRentFree");
   public static final BorrowerResidencyBasisType OWN = new BorrowerResidencyBasisType("Own");
   public static final BorrowerResidencyBasisType RENT = new BorrowerResidencyBasisType("Rent");
   static Class class$org$commerce$mismo$BorrowerResidencyBasisType;


   private BorrowerResidencyBasisType(String name) {
      super(name);
   }

   public static BorrowerResidencyBasisType getEnum(String type) {
      return (BorrowerResidencyBasisType)getEnum(class$org$commerce$mismo$BorrowerResidencyBasisType == null?(class$org$commerce$mismo$BorrowerResidencyBasisType = class$("org.commerce.mismo.BorrowerResidencyBasisType")):class$org$commerce$mismo$BorrowerResidencyBasisType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$BorrowerResidencyBasisType == null?(class$org$commerce$mismo$BorrowerResidencyBasisType = class$("org.commerce.mismo.BorrowerResidencyBasisType")):class$org$commerce$mismo$BorrowerResidencyBasisType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$BorrowerResidencyBasisType == null?(class$org$commerce$mismo$BorrowerResidencyBasisType = class$("org.commerce.mismo.BorrowerResidencyBasisType")):class$org$commerce$mismo$BorrowerResidencyBasisType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$BorrowerResidencyBasisType == null?(class$org$commerce$mismo$BorrowerResidencyBasisType = class$("org.commerce.mismo.BorrowerResidencyBasisType")):class$org$commerce$mismo$BorrowerResidencyBasisType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
