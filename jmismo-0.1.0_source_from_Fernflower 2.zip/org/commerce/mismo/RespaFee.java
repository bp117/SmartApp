package org.commerce.mismo;

import org.commerce.mismo.Payment;
import org.commerce.mismo.RespaSectionClassificationType;
import org.commerce.mismo.RespaType;
import org.commerce.mismo.ResponsiblePartyType;

public interface RespaFee {

   RespaSectionClassificationType getRespaSectionClassificationType();

   void setRespaSectionClassificationType(RespaSectionClassificationType var1);

   String getPaidToName();

   void setPaidToName(String var1);

   ResponsiblePartyType getResponsiblePartyType();

   void setResponsiblePartyType(ResponsiblePartyType var1);

   String getSpecifiedHUDLineNumber();

   void setSpecifiedHUDLineNumber(String var1);

   RespaType getType();

   void setType(RespaType var1);

   String getOtherTypeDescription();

   void setOtherTypeDescription(String var1);

   Payment[] getPayments();

   void addPayment(Payment var1);

   void removePayment(Payment var1);

   Payment createPayment();
}
