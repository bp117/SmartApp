package org.commerce.mismo;

import java.io.Serializable;
import java.util.Date;
import org.commerce.mismo.IdentificationType;

public interface Identification extends Serializable {

   Date getExpirationDate();

   Date getIssueDate();

   String getIssuingCountry();

   String getIssuingState();

   IdentificationType getType();

   void setExpirationDate(Date var1);

   void setIssueDate(Date var1);

   void setIssuingCountry(String var1);

   void setIssuingState(String var1);

   void setType(IdentificationType var1);
}
