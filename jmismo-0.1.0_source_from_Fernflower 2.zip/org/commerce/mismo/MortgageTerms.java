package org.commerce.mismo;

import java.math.BigDecimal;
import java.util.Date;
import org.commerce.mismo.LoanAmortizationType;
import org.commerce.mismo.MortgageType;

public interface MortgageTerms {

   BigDecimal getBaseLoanAmount();

   void setBaseLoanAmount(BigDecimal var1);

   BigDecimal getBorrowerRequestedLoanAmount();

   void setBorrowerRequestedLoanAmount(BigDecimal var1);

   int getLoanAmortizationTermMonths();

   void setLoanAmortizationTermMonths(int var1);

   LoanAmortizationType getLoanAmortizationType();

   void setLoanAmortizationType(LoanAmortizationType var1);

   MortgageType getMortgageType();

   void setMortgageType(MortgageType var1);

   String getAgencyCaseIdentifier();

   void setAgencyCaseIdentifier(String var1);

   Float getRequestedInterestRatePercent();

   void setRequestedInterestRatePercent(Float var1);

   Date getLoanEstimatedClosingDate();

   void setLoanEstimatedClosingDate(Date var1);
}
