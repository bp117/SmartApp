package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class CitizenshipResidencyType extends Enum {

   public static final CitizenshipResidencyType US_CITIZEN = new CitizenshipResidencyType("USCitizen");
   public static final CitizenshipResidencyType PERMANENT_RESIDENT_ALIEN = new CitizenshipResidencyType("PermanentResidentAlien");
   public static final CitizenshipResidencyType NON_PERMANENT_RESIDENT_ALIEN = new CitizenshipResidencyType("NonPermanentResidentAlien");
   static Class class$org$commerce$mismo$CitizenshipResidencyType;


   private CitizenshipResidencyType(String name) {
      super(name);
   }

   public static CitizenshipResidencyType getEnum(String type) {
      return (CitizenshipResidencyType)getEnum(class$org$commerce$mismo$CitizenshipResidencyType == null?(class$org$commerce$mismo$CitizenshipResidencyType = class$("org.commerce.mismo.CitizenshipResidencyType")):class$org$commerce$mismo$CitizenshipResidencyType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$CitizenshipResidencyType == null?(class$org$commerce$mismo$CitizenshipResidencyType = class$("org.commerce.mismo.CitizenshipResidencyType")):class$org$commerce$mismo$CitizenshipResidencyType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$CitizenshipResidencyType == null?(class$org$commerce$mismo$CitizenshipResidencyType = class$("org.commerce.mismo.CitizenshipResidencyType")):class$org$commerce$mismo$CitizenshipResidencyType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$CitizenshipResidencyType == null?(class$org$commerce$mismo$CitizenshipResidencyType = class$("org.commerce.mismo.CitizenshipResidencyType")):class$org$commerce$mismo$CitizenshipResidencyType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
