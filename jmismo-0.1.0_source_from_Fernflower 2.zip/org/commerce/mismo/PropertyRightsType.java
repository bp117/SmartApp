package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class PropertyRightsType extends Enum {

   public static final PropertyRightsType FEE_SIMPLE = new PropertyRightsType("FeeSimple");
   public static final PropertyRightsType LEASEHOLD = new PropertyRightsType("Leasehold");
   static Class class$org$commerce$mismo$PropertyRightsType;


   private PropertyRightsType(String name) {
      super(name);
   }

   public static PropertyRightsType getEnum(String type) {
      return (PropertyRightsType)getEnum(class$org$commerce$mismo$PropertyRightsType == null?(class$org$commerce$mismo$PropertyRightsType = class$("org.commerce.mismo.PropertyRightsType")):class$org$commerce$mismo$PropertyRightsType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$PropertyRightsType == null?(class$org$commerce$mismo$PropertyRightsType = class$("org.commerce.mismo.PropertyRightsType")):class$org$commerce$mismo$PropertyRightsType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$PropertyRightsType == null?(class$org$commerce$mismo$PropertyRightsType = class$("org.commerce.mismo.PropertyRightsType")):class$org$commerce$mismo$PropertyRightsType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$PropertyRightsType == null?(class$org$commerce$mismo$PropertyRightsType = class$("org.commerce.mismo.PropertyRightsType")):class$org$commerce$mismo$PropertyRightsType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
