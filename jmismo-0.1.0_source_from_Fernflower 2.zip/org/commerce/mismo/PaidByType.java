package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class PaidByType extends Enum {

   public static final PaidByType BUYER = new PaidByType("Buyer");
   public static final PaidByType LENDER = new PaidByType("Lender");
   public static final PaidByType SELLER = new PaidByType("Seller");
   public static final PaidByType THIRD_PARTY = new PaidByType("ThirdParty");
   static Class class$org$commerce$mismo$PaidByType;


   private PaidByType(String name) {
      super(name);
   }

   public static PaidByType getEnum(String type) {
      return (PaidByType)getEnum(class$org$commerce$mismo$PaidByType == null?(class$org$commerce$mismo$PaidByType = class$("org.commerce.mismo.PaidByType")):class$org$commerce$mismo$PaidByType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$PaidByType == null?(class$org$commerce$mismo$PaidByType = class$("org.commerce.mismo.PaidByType")):class$org$commerce$mismo$PaidByType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$PaidByType == null?(class$org$commerce$mismo$PaidByType = class$("org.commerce.mismo.PaidByType")):class$org$commerce$mismo$PaidByType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$PaidByType == null?(class$org$commerce$mismo$PaidByType = class$("org.commerce.mismo.PaidByType")):class$org$commerce$mismo$PaidByType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
