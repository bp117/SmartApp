package org.commerce.mismo;

import java.math.BigDecimal;
import org.commerce.mismo.DownPaymentType;
import org.commerce.mismo.Mismo;

public interface DownPayment extends Mismo {

   BigDecimal getAmount();

   void setAmount(BigDecimal var1);

   String getSourceDescription();

   void setSourceDescription(String var1);

   DownPaymentType getDownPaymentType();

   void setDownPaymentType(DownPaymentType var1);
}
