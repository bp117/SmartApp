package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class PriorPropertyTitleType extends Enum {

   public static final PriorPropertyTitleType SOLE = new PriorPropertyTitleType("Sole");
   public static final PriorPropertyTitleType JOINT_WITH_SPOUSE = new PriorPropertyTitleType("JointWithSpouse");
   public static final PriorPropertyTitleType JOINT_WITH_OTHER_THAN_SPOUSE = new PriorPropertyTitleType("JointWithOtherThanSpouse");
   static Class class$org$commerce$mismo$PriorPropertyTitleType;


   private PriorPropertyTitleType(String name) {
      super(name);
   }

   public static PriorPropertyTitleType getEnum(String type) {
      return (PriorPropertyTitleType)getEnum(class$org$commerce$mismo$PriorPropertyTitleType == null?(class$org$commerce$mismo$PriorPropertyTitleType = class$("org.commerce.mismo.PriorPropertyTitleType")):class$org$commerce$mismo$PriorPropertyTitleType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$PriorPropertyTitleType == null?(class$org$commerce$mismo$PriorPropertyTitleType = class$("org.commerce.mismo.PriorPropertyTitleType")):class$org$commerce$mismo$PriorPropertyTitleType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$PriorPropertyTitleType == null?(class$org$commerce$mismo$PriorPropertyTitleType = class$("org.commerce.mismo.PriorPropertyTitleType")):class$org$commerce$mismo$PriorPropertyTitleType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$PriorPropertyTitleType == null?(class$org$commerce$mismo$PriorPropertyTitleType = class$("org.commerce.mismo.PriorPropertyTitleType")):class$org$commerce$mismo$PriorPropertyTitleType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
