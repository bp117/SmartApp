package org.commerce.mismo;

import org.commerce.mismo.ContactPoint;

public interface ContactDetail {

   String getName();

   void setName(String var1);

   ContactPoint[] getContactPoints();

   void addContactPoint(ContactPoint var1);

   void removeContactPoint(ContactPoint var1);

   ContactPoint createContactPoint();
}
