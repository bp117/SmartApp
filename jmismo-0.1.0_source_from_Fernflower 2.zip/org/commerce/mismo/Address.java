package org.commerce.mismo;

import java.io.Serializable;

public interface Address extends Serializable {

   String getStreetAddress();

   void setStreetAddress(String var1);

   String getStreetAddress2();

   void setStreetAddress2(String var1);

   String getCity();

   void setCity(String var1);

   String getState();

   void setState(String var1);

   String getPostalCode();

   void setPostalCode(String var1);

   String getCountry();

   void setCountry(String var1);
}
