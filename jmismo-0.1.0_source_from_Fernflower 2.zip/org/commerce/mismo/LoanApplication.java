package org.commerce.mismo;

import org.commerce.mismo.AdditionalCaseData;
import org.commerce.mismo.Asset;
import org.commerce.mismo.Borrower;
import org.commerce.mismo.DownPayment;
import org.commerce.mismo.GovernmentReporting;
import org.commerce.mismo.InterviewerInformation;
import org.commerce.mismo.Liability;
import org.commerce.mismo.LoanProductData;
import org.commerce.mismo.LoanPurpose;
import org.commerce.mismo.MortgageTerms;
import org.commerce.mismo.MultiBorrowerAssociatedEntity;
import org.commerce.mismo.Property;
import org.commerce.mismo.ProposedHousingExpense;
import org.commerce.mismo.REOProperty;
import org.commerce.mismo.RespaFee;
import org.commerce.mismo.TransactionDetail;

public interface LoanApplication extends MultiBorrowerAssociatedEntity {

   Long getLoanApplicationId();

   void setLoanApplicationId(Long var1);

   Borrower createBorrower();

   void addDownPayment(DownPayment var1);

   DownPayment[] getDownPayments();

   DownPayment createDownPayment();

   LoanPurpose getLoanPurpose();

   void setLoanPurpose(LoanPurpose var1);

   GovernmentReporting getGovernmentReporting();

   void setGovernmentReporting(GovernmentReporting var1);

   LoanPurpose createLoanPurpose();

   MortgageTerms getMortgageTerms();

   Property getProperty();

   void setProperty(Property var1);

   Property createProperty();

   void addAsset(Asset var1);

   Asset[] getAssets();

   Asset createAsset();

   void addLiability(Liability var1);

   InterviewerInformation getInterviewerInformation();

   Liability[] getLiabilities();

   void removeLiability(Liability var1);

   Liability createLiability();

   void addREOProperty(REOProperty var1);

   REOProperty[] getReoProperties();

   void removeREOProperty(REOProperty var1);

   REOProperty createREOProperty();

   AdditionalCaseData getAdditionalCaseData();

   LoanProductData getLoanProductData();

   TransactionDetail getTransactionDetail();

   ProposedHousingExpense[] getProposedHousingExpenses();

   void addProposedHousingExpense(ProposedHousingExpense var1);

   ProposedHousingExpense createProposedHousingExpense();

   RespaFee[] getRespaFees();

   void addRespaFee(RespaFee var1);

   RespaFee createRespaFee();

   void setMismoVersionId(String var1);

   String getMismoVersionId();
}
