package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class RateLockType extends Enum {

   public static final RateLockType FLOAT = new RateLockType("Float");
   public static final RateLockType LOCK = new RateLockType("Lock");
   public static final RateLockType CAP = new RateLockType("Cap");
   static Class class$org$commerce$mismo$RateLockType;


   private RateLockType(String name) {
      super(name);
   }

   public static RateLockType getEnum(String type) {
      return (RateLockType)getEnum(class$org$commerce$mismo$RateLockType == null?(class$org$commerce$mismo$RateLockType = class$("org.commerce.mismo.RateLockType")):class$org$commerce$mismo$RateLockType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$RateLockType == null?(class$org$commerce$mismo$RateLockType = class$("org.commerce.mismo.RateLockType")):class$org$commerce$mismo$RateLockType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$RateLockType == null?(class$org$commerce$mismo$RateLockType = class$("org.commerce.mismo.RateLockType")):class$org$commerce$mismo$RateLockType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$RateLockType == null?(class$org$commerce$mismo$RateLockType = class$("org.commerce.mismo.RateLockType")):class$org$commerce$mismo$RateLockType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
