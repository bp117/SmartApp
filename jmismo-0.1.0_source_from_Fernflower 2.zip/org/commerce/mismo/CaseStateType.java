package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public final class CaseStateType extends Enum {

   public static final CaseStateType APPLICATION = new CaseStateType("Application");
   public static final CaseStateType FINAL_DISPOSITION = new CaseStateType("FinalDisposition");
   public static final CaseStateType POST_CLOSING_QUALITY_CONTROL = new CaseStateType("PostClosingQualityControl");
   public static final CaseStateType PREQUALIFICATION = new CaseStateType("Prequalification");
   public static final CaseStateType UNDERWRITING = new CaseStateType("Underwriting");
   static Class class$org$commerce$mismo$CaseStateType;


   private CaseStateType(String name) {
      super(name);
   }

   public static CaseStateType getEnum(String type) {
      return (CaseStateType)getEnum(class$org$commerce$mismo$CaseStateType == null?(class$org$commerce$mismo$CaseStateType = class$("org.commerce.mismo.CaseStateType")):class$org$commerce$mismo$CaseStateType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$CaseStateType == null?(class$org$commerce$mismo$CaseStateType = class$("org.commerce.mismo.CaseStateType")):class$org$commerce$mismo$CaseStateType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$CaseStateType == null?(class$org$commerce$mismo$CaseStateType = class$("org.commerce.mismo.CaseStateType")):class$org$commerce$mismo$CaseStateType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$CaseStateType == null?(class$org$commerce$mismo$CaseStateType = class$("org.commerce.mismo.CaseStateType")):class$org$commerce$mismo$CaseStateType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
