package org.commerce.mismo;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.enums.Enum;

public class HMDAPurposeOfLoanType extends Enum {

   public static final HMDAPurposeOfLoanType HOME_PURCHASE = new HMDAPurposeOfLoanType("HomePurchase");
   public static final HMDAPurposeOfLoanType HOME_IMPROVEMENT = new HMDAPurposeOfLoanType("HomeImprovement");
   public static final HMDAPurposeOfLoanType REFINANCING = new HMDAPurposeOfLoanType("Refinancing");
   static Class class$org$commerce$mismo$HMDAPurposeOfLoanType;


   private HMDAPurposeOfLoanType(String name) {
      super(name);
   }

   public static HMDAPurposeOfLoanType getEnum(String type) {
      return (HMDAPurposeOfLoanType)getEnum(class$org$commerce$mismo$HMDAPurposeOfLoanType == null?(class$org$commerce$mismo$HMDAPurposeOfLoanType = class$("org.commerce.mismo.HMDAPurposeOfLoanType")):class$org$commerce$mismo$HMDAPurposeOfLoanType, type);
   }

   public static Map getEnumMap() {
      return getEnumMap(class$org$commerce$mismo$HMDAPurposeOfLoanType == null?(class$org$commerce$mismo$HMDAPurposeOfLoanType = class$("org.commerce.mismo.HMDAPurposeOfLoanType")):class$org$commerce$mismo$HMDAPurposeOfLoanType);
   }

   public static List getEnumList() {
      return getEnumList(class$org$commerce$mismo$HMDAPurposeOfLoanType == null?(class$org$commerce$mismo$HMDAPurposeOfLoanType = class$("org.commerce.mismo.HMDAPurposeOfLoanType")):class$org$commerce$mismo$HMDAPurposeOfLoanType);
   }

   public static Iterator iterator() {
      return iterator(class$org$commerce$mismo$HMDAPurposeOfLoanType == null?(class$org$commerce$mismo$HMDAPurposeOfLoanType = class$("org.commerce.mismo.HMDAPurposeOfLoanType")):class$org$commerce$mismo$HMDAPurposeOfLoanType);
   }

   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

}
