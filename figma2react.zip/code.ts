// code.ts


figma.showUI(__html__, { width: 400, height: 400 });


figma.ui.onmessage = (msg) => {
  console.log("Message received:", msg.type);
  if (msg.type === 'convert-to-react') {
      const nodes = figma.currentPage.selection;
      if (nodes.length === 0) {
        figma.notify('Please select a node');
        return;
      }

      const node = nodes[0];
      const reactCode = convertNodeToReact(node);
      const reactProject = generateReactProjectStructure(reactCode);
      figma.ui.postMessage({ type: 'react-project', project: reactProject });
      
  } 
};

function generateReactProjectStructure(reactCode) {
  const packageJson = {
    "name": "react-project",
    "version": "0.1.0",
    "private": true,
    "dependencies": {
      "react": "^17.0.2",
      "react-dom": "^17.0.2",
      "react-scripts": "4.0.3",
      "@material-ui/core": "^4.11.3" // Adding Material-UI core
    },
    "scripts": {
      "start": "react-scripts start",
      "build": "react-scripts build",
      "test": "react-scripts test",
      "eject": "react-scripts eject"
    }
  };
  
  return {
    'public/index.html': `...`, // Keep as before
    'src/index.js': `
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './index.css';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);
`,
    'src/App.js': `
import React from 'react';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import Card from '@material-ui/core/Card';
// You can import more MUI components as needed

function App() {
  return (
    ${reactCode}
  );
}

export default App;
`,
    'src/index.css': `
/* Add any global styles here */
`, 
    'package.json': JSON.stringify(packageJson, null, 2) // Pretty print the package.json
  };
}


function generateReactProject(reactCode) {
  const indexJs = `
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(
<React.StrictMode>
  <App />
</React.StrictMode>,
document.getElementById('root')
);
`;

  const appJs = `
import React from 'react';

function App() {
return (
  ${reactCode}
);
}

export default App;
`;

  return {
      'src/index.js': indexJs,
      'src/App.js': appJs
  };
}
function convertNodeToReact(node) {
  let reactCode = "";
  console.log("node:", node.type, node.name);

  if (!node) return reactCode;

  // Extract common styles for most nodes
  const styles = {
      position: 'absolute',
      left: `${node.x}px`,
      top: `${node.y}px`,
      width: `${node.width}px`,
      height: `${node.height}px`
  };

  switch (node.type) {
      case 'TEXT':
          const textColor = (node.fills && node.fills.length > 0) ? node.fills[0].color : null;
          const rgbColor = textColor ? colorToRgb(textColor) : 'rgba(0, 0, 0, 1)';
          reactCode = `<span style={${JSON.stringify(styles)}}>${node.characters}</span>`;
          break;

      case 'RECTANGLE':
      case 'VECTOR':
      case 'ELLIPSE':
          const nodeColor = (node.fills && node.fills.length > 0) ? node.fills[0].color : null;
          const nodeRgbColor = nodeColor ? colorToRgb(nodeColor) : 'transparent';
          reactCode = `<div style={${JSON.stringify(styles)}}></div>`;
          break;

      case 'INSTANCE':
      case 'COMPONENT':
          if (['BtnPrimary', 'Button 1', 'Button'].includes(node.name)) {
              reactCode = `<Button variant="contained" color="primary">${node.children.map(child => child.type === 'TEXT' ? child.characters : '').join('')}</Button>`;
          } else if (['BtnSecondary', 'Button 2'].includes(node.name)) {
              reactCode = `<Button variant="contained" color="secondary">${node.children.map(child => child.type === 'TEXT' ? child.characters : '').join('')}</Button>`;
          } else if (node.name === 'Card') {
              const cardContent = node.children.map(convertNodeToReact).join('');
              reactCode = `<Card>${cardContent}</Card>`;
          } else {
              reactCode = `<!-- Unmapped component: ${node.name} -->`;
          }
          break;

      case 'FRAME':
      case 'GROUP':
        const childrenReactCode = node.children.map(convertNodeToReact).join('');

        if (node.name === 'Button') {
            reactCode = `<Button style={${JSON.stringify(styles)}}>${childrenReactCode}</Button>`;
        } else if (node.name === 'Password' || node.name === 'Email') {
            const textChild = node.children.find(child => child.type === 'TEXT');
            const placeholderText = textChild ? textChild.characters : '';
            const inputType = node.name === 'Password' ? 'password' : 'text';
            reactCode = `<input type="${inputType}" placeholder="${placeholderText}" style={${JSON.stringify(styles)}} />`;
        } else {
            reactCode = `<div style={${JSON.stringify(styles)}}>${childrenReactCode}</div>`;
        }
        break;

      default:
          reactCode = `<!-- Unsupported node type: ${node.type} -->`;
  }

  return reactCode;
}


function colorToRgb(color) {
  return `rgba(${Math.round(color.r * 255)}, ${Math.round(color.g * 255)}, ${Math.round(color.b * 255)}, ${color.a})`;
}

function getTypographyVariant(fontSize) {
  if (fontSize >= 40) return "h1";
  if (fontSize >= 32) return "h2";
  if (fontSize >= 24) return "h3";
  if (fontSize >= 20) return "h4";
  if (fontSize >= 16) return "h5";
  return "h6";
}
function wrapInReactProject(componentCode) {
    console.log("in wrap");
    return {
      "package.json": JSON.stringify({
        "name": "react-project",
        "version": "1.0.0",
        "dependencies": {
          "react": "^17.0.1",
          "react-dom": "^17.0.1",
          "@material-ui/core": "^4.11.0"
        }
      }, null, 2),
      "index.html": `
  <!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="utf-8" />
      <title>React Project</title>
    </head>
    <body>
      <div id="root"></div>
      <script src="src/index.js"></script>
    </body>
  </html>
      `,
      "src/index.js": `
  import React from 'react';
  import ReactDOM from 'react-dom';

  function App() {
    return (
        <div>Hello World</div>
    );
  }

  ReactDOM.render(<App />, document.getElementById('root'));
      `
    };
}

  
  function fetchToCodeSandbox(project) {
    console.log("In codesand");

    fetch("https://codesandbox.io/api/v1/sandboxes/define", {
        headers: {
            'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify({ files: project })
    })
    .then(response => {
        if (!response.ok) {
            // If the server returns an error response, try to get its text
            return response.text().then(text => {
                throw new Error(`Server returned ${response.status}: ${text}`);
            });
        }
        return response.json();
    })
    .then(data => {
        const sandboxUrl = `https://codesandbox.io/s/${data.sandbox_id}`;
        figma.ui.postMessage({ type: 'open-sandbox', url: sandboxUrl });
    })
    .catch(error => {
        console.error("Error posting to CodeSandbox:", error);
        figma.notify("Error opening in CodeSandbox. Check the console for details.");
    });
}


